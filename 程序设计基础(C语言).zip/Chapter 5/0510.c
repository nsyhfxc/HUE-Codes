#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    double sum = 0.0;
    double numerator = 2.0, denominator = 1.0;
    int i = 0;
    for (i = 0; i < n; i++) {
        sum += numerator / denominator;
        double temp = numerator;
        numerator = numerator + denominator;
        denominator = temp;
    }

    printf("%.2f\n", sum);
    return 0;
}