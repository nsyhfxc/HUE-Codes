#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    // 斐波那契数列前两项
    double a = 1, b = 1, temp;
    int i = 2;
    for (i = 2; i <= n; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }
    // a为第n项，b为第n+1项
    printf("%.5lf\n", a / b);
    return 0;
}