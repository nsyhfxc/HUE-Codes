#include <stdio.h>
#include <math.h>

int main() {
    int n;
    double h = 100.0, sum = 100.0, rebound = 100.0;
    scanf("%d", &n);
    int i = 1;
    for (i = 1; i < n; i++) {
        rebound /= 2.0;
        sum += 2 * rebound;
    }
    rebound /= 2.0;

    printf("sum=%.2f,h=%.2f\n", sum, rebound);
    return 0;
}