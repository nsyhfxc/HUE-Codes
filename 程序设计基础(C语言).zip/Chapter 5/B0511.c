#include <stdio.h>

int main() {
    int day;
    double h;

    scanf("%d", &day);

    if (day <= 1460) {
        // 前四年（1460天），总共长3cm，匀速
        h = 3.0 * day / 1460;
    } else {
        // 1460天后，每天长30cm
        h = 3.0 + (day - 1460) * 30.0;
    }

    printf("h=%.5lfcm\n", h);

    return 0;
}