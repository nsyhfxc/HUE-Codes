#include <stdio.h>

int main() {
    int n, a, b;
    scanf("%d", &n);

    for (a = 1; a < n; a++) {
        for (b = a; b < n; b++) {
            if (a + 2 * b == n) {
                printf("%d+2*%d=%d\n", a, b, n);
            }
        }
    }

    return 0;
}