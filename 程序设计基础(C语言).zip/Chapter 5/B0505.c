#include <stdio.h>

int main() {
    int i = 1, sum = 0, n;
    while (i <= 100) {
        scanf("%d", &n);
        sum = sum + 2 * n;
        if (sum > 20) {
            break;
        }
        i++;
    }
    printf("%d\n", sum);
    return 0;
}