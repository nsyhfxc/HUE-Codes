#include <stdio.h>

int main() {
    char a, b, c;
    // 甲队：A, B, C；乙队：X, Y, Z
    for (a = 'X'; a <= 'Z'; a++) {
        for (b = 'X'; b <= 'Z'; b++) {
            if (b == a) continue;
            for (c = 'X'; c <= 'Z'; c++) {
                if (c == a || c == b) continue;
                // A不和X比，C不和X,Z比
                if (a != 'X' && c != 'X' && c != 'Z') {
                    printf("A<-->%c,B<-->%c,C<-->%c,", a, b, c);
                }
            }
        }
    }
    return 0;
}