#include <stdio.h>

int main() {
    int m = 100, n = 200;
    int i = m;
    for (i = m; i <= n; i++) {
        if (i % 2 != 0 && i % 3 != 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
    return 0;
}