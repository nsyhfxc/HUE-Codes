#include <stdio.h>

// 辗转相除法求最大公约数
int gcd(int a, int b) {
    int temp;
    while (b != 0) {
        temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}

// 求最小公倍数
int lcm(int a, int b) {
    return a * b / gcd(a, b);
}

int main() {
    int m, n;
    scanf("%d,%d", &m, &n);

    int g = gcd(m, n);
    int l = lcm(m, n);

    printf("%d,%d\n", g, l);

    return 0;
}