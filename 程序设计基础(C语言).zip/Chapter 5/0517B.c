#include <stdio.h>

int main() {
    char teamA[3] = {'A', 'B', 'C'};
    char teamB[3] = {'X', 'Y', 'Z'};
    int i, j, k;

    // i, j, k 分别表示A, B, C对应的对手在teamB中的下标
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            if (j == i) continue; // 不能和同一个人比
            for (k = 0; k < 3; k++) {
                if (k == i || k == j) continue;
                // A不和Y比，C不和Z比
                if (teamB[i] != 'Y' && teamB[k] != 'Z') {
                    printf("A<-->%c,B<-->%c,C<-->%c\n", teamB[i], teamB[j], teamB[k]);
                    
                }
            }
        }
    }
    return 0;
}