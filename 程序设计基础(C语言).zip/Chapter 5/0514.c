#include <stdio.h>
#include <math.h>

#define EPS 1e-6  // 精度要求

int main() {
    double a, b, c, d;
    double x0 = 1.5, x1;
    scanf("%lf,%lf,%lf,%lf", &a, &b, &c, &d);

    while (1) {
        double fx = a*x0*x0*x0 + b*x0*x0 + c*x0 + d;
        double fpx = 3*a*x0*x0 + 2*b*x0 + c;
        if (fabs(fpx) < EPS) { // 防止除以0
            return 1;
        }
        x1 = x0 - fx / fpx;
        if (fabs(x1 - x0) < EPS) break;
        x0 = x1;
    }
    printf("x=%.2f\n", x1);
    return 0;
}