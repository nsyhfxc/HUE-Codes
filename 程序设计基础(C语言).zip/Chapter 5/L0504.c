#include <stdio.h>

int main() {
    int num = 1;
    double total = 0, amount, aver;

    while (num <= 1000) {
        scanf("%lf", &amount);
        total += amount;
        if (total >= 100000) {
            break;
        }
        num++;
    }
    aver = total / num;
    printf("num=%d,aver=%10.2f\n", num, aver);
    return 0;
}