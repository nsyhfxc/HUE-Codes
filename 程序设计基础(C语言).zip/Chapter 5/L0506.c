#include <stdio.h>

int main() {
    int n = 1;
    int i,j = 0;
    for (i = 0; i < 4; i++) { // 4 rows
        for (j = 0; j < 5; j++) { // 5 columns
            printf("%5d", n);
            n++;
        }
        printf("\n");
    }
    return 0;
}