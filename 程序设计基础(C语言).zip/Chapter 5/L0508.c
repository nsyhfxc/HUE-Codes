#include <stdio.h>

int main() {
    long long fib[40];
    fib[0] = 1;
    fib[1] = 1;
    int i = 0;
    for (i = 2; i < 40; i++) {
        fib[i] = fib[i - 1] + fib[i - 2];
    }
    for (i = 0; i < 40; i++) {
        printf("%12lld", fib[i]);
        if ((i + 1) % 4 == 0)
            printf("\n");
    }
    return 0;
}