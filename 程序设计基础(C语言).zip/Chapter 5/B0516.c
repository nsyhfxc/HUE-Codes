#include <stdio.h>

int main() {
    int n = 1;
    int a,b,c;
    // 5本书编号为1~5，A、B、C分别借走不同的书
    for (a = 1; a <= 5; a++) {
        for (b = 1; b <= 5; b++) {
            if (b == a) continue;
            for (c = 1; c <= 5; c++) {
                if (c == a || c == b) continue;
                printf("n=%d:%d,%d,%d\n", n, a, b, c);
                n++;
            }
        }
    }
    return 0;
}