#include <stdio.h>

int main() {
    int i;
    int sum1 = 0;
    int sum2 = 0;
    double sum3 = 0.0, sum;

    // (1+2+3+...+100)
    for(i = 1; i <= 100; i++) {
        sum1 += i;
    }

    // (1*1+2*2+...+50*50)
    for(i = 1; i <= 50; i++) {
        sum2 += i * i;
    }

    // (1+1/2+...+1/10)
    for(i = 1; i <= 10; i++) {
        sum3 += 1.0 / i;
    }

    sum = sum1 + sum2 + sum3;
    printf("sum=%.2f\n", sum);

    return 0;
}