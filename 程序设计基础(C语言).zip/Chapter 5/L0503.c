#include <stdio.h>

int main() {
    int m, n, sum = 0;
    scanf("%d,%d", &m, &n);

    if (m > n || m <= 0 || n <= 0) {
        return 1;
    }
    int i = m;
    for (i = m; i <= n; i++) {
        sum += i;
    }

    printf("sum=%d\n", sum);
    return 0;
}