#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

int main() {
    uint64_t f, n, s;
    scanf("%" SCNu64 ",%" SCNu64, &f, &n);
    s = f << (n - 1); // 相当于 f * 2^(n-1)
    printf("s=%" PRIu64 "\n", s);
    return 0;
}