#include <stdio.h>

int main() {
    int cocks, hens, chickens;
    int count = 0;
    for (cocks = 0; cocks <= 20; cocks++) { // 5元一只，最多20只
        for (hens = 0; hens <= 33; hens++) { // 3元一只，最多33只
            chickens = 100 - cocks - hens;
            if (chickens % 3 == 0 && chickens >= 0) {
                if (5 * cocks + 3 * hens + chickens / 3 == 100) {
                    printf("cocks:%d,hens:%d,chickens:%d\n", cocks, hens, chickens);
                    count++;
                }
            }
        }
    }
    return 0;
}