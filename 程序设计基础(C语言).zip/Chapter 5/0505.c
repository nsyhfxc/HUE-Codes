#include <stdio.h>

int main() {
    int a, n;
    scanf("%d %d", &a, &n);

    int sum = 0;
    int term = 0;
    int i = 0;
    for (i = 0; i < n; i++) {
        term = term * 10 + a;
        sum += term;
    }
    printf("%d\n", sum);
    return 0;
}