#include <stdio.h>

int main() {
    int n, i, sum, count = 0;
    for (n = 2; n <= 1000; n++) {
        sum = 0;
        // 计算真因子之和
        for (i = 1; i <= n / 2; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }
        if (sum == n) {
            count++;
            printf("%d its factors are ", n);
            int first = 1;
            for (i = 1; i <= n / 2; i++) {
                if (n % i == 0) {
                    if (!first) {
                        printf(",");
                    }
                    printf("%d", i);
                    first = 0;
                }
            }
            printf("\n");
        }
    }
    return 0;
}