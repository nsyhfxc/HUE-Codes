#include <stdio.h>
#include <math.h>

int main() {
    double h = 100.0;
    double sum = h;
    int n = 10;
    double rebound = h;
    int i = 1; 
    for ( i = 1; i < n; i++) {
        rebound /= 2;
        sum += 2 * rebound;
    }
    rebound /= 2; // 第10次反弹高度

    printf("sum=%.2f,h=%.2f\n", sum, rebound);
    return 0;
}