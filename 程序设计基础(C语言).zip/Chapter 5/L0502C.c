#include <stdio.h>
#include <math.h>

int main() {
    long long sum = 0;
    long long roses = 1;
    int day = 1;
    for (day = 1; day <= 30; day++) {
        sum += roses;
        roses *= 2;
    }
    printf("sum=%lld\n", sum);
    return 0;
}