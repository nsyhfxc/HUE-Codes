#include <stdio.h>
#include <math.h>

int main() {
    int n;
    while (1) {
        scanf("%d", &n);
        if (n > 0 && n < 1001) {
            break;
        } else {
            printf("Please reinput(0<n<1001):");
        }
    }
    printf("%d\n", (int)sqrt(n));
    return 0;
}