#include <stdio.h>

int main() {
    int sum = 0;
    int i = 2;
    for (i = 2; i <= 100; i += 2) {
        sum += i;
    }
    printf("%d\n", sum);
    return 0;
}