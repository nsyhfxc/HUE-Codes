#include <stdio.h>

int main() {
    int n, i, peaches = 1;
    scanf("%d", &n);
    // 从第n天往前推算
    for (i = 1; i < n; i++) {
        peaches = (peaches + 1) * 2;
    }
    printf("%d\n", peaches);
    return 0;
}