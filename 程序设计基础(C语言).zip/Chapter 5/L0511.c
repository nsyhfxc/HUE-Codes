#include <stdio.h>
#include <ctype.h>

int main() {
    char ch;
    while ((ch = getchar()) != '\n') {
        if (ch >= 'a' && ch <= 'v') {
            putchar(ch + 4);
        } else if (ch >= 'A' && ch <= 'V') {
            putchar(ch + 4);
        } else if (ch == 'w') {
            putchar('a');
        } else if (ch == 'x') {
            putchar('b');
        } else if (ch == 'y') {
            putchar('c');
        } else if (ch == 'z') {
            putchar('d');
        } else if (ch == 'W') {
            putchar('A');
        } else if (ch == 'X') {
            putchar('B');
        } else if (ch == 'Y') {
            putchar('C');
        } else if (ch == 'Z') {
            putchar('D');
        } else {
            putchar(ch);
        }
    }
    putchar('\n');
    return 0;
}