#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    int a = 1;
    for (a = 1; a < n; a++) {
        int b = n / a;
        if (a < b && a * b == n) {
            printf("%d*%d=%d\n", a, b, n);
        }
    }
    return 0;
}