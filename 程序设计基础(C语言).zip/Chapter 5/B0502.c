#include <stdio.h>

int main() {
    int n, count = 0, temp;
    scanf("%d", &n);
    temp = n;
    while (temp >= 5) {
        count += temp / 5;
        temp /= 5;
    }
    printf("%d\n", count);
    return 0;
}