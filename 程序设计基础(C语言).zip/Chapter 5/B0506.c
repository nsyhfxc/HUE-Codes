#include <stdio.h>

int main() {
    int n, i = 1, sum = 0;
    scanf("%d", &n);
    while (i <= n) {
        if (i % 3 != 0) {
            sum = sum + 2 * i;
        }
        i++;
    }
    printf("%d\n", sum);
    return 0;
}