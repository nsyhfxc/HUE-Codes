#include <stdio.h>

int main() {
    int n;
    double sum = 0.0;
    scanf("%d", &n);
    int i = 1;
    for (i = 1; i <= n; i++) {
        double term = (double)(2 * i - 1) / (2 * i);
        if (i % 2 == 1)
            sum += term;
        else
            sum -= term;
    }
    printf("%.2f\n", sum);
    return 0;
}