#include <stdio.h>

int main() {
    int man, woman, children;
    for (man = 0; man <= 15; man++) {
        for (woman = 0; woman <= 45 - man; woman++) {
            children = 45 - man - woman;
            if (children % 2 == 0) {
                if (man * 3 + woman * 2 + children / 2 == 45) {
                    printf("man:%d,woman:%d,children:%d\n", man, woman, children);
                }
            }
        }
    }
    return 0;
}