#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    unsigned long long sum = 0;
    unsigned long long fact = 1;
    int i = 1;
    for (i = 1; i <= n; i++) {
        fact *= i;
        sum += fact;
    }

    printf("sum=%llu\n", sum);
    return 0;
}