#include <stdio.h>

int main() {
    char ch;
    int character = 0, space = 0, digit = 0, others = 0;
    while ((ch = getchar()) != '\n') {
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
            character++;
        else if (ch == ' ')
            space++;
        else if (ch >= '0' && ch <= '9')
            digit++;
        else
            others++;
    }
    printf("character:%d,space:%d,digit:%d,others:%d\n", character, space, digit, others);
    return 0;
}