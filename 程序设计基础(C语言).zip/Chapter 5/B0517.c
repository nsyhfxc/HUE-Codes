#include <stdio.h>

int main() {
    int a, b, c; // a: Zhangsan, b: Lisi, c: Wangwu

    // 枚举所有可能的真假组合
    for (a = 0; a <= 1; a++) {
        for (b = 0; b <= 1; b++) {
            for (c = 0; c <= 1; c++) {
                // 张三说李四在说谎
                int cond1 = (a == 1 && b == 0) || (a == 0 && b == 1);
                // 李四说王五在说谎
                int cond2 = (b == 1 && c == 0) || (b == 0 && c == 1);
                // 王五说张三和李四都在说谎
                int cond3 = (c == 1 && (a + b == 0)) || (c == 0 && (a + b != 0));
                if (cond1 && cond2 && cond3) {
                    printf("Zhangsan told a %s.\n", a ? "truth" : "lie");
                    printf("Lisi told a %s.\n", b ? "truth" : "lie");
                    printf("Wangwu told a %s.\n", c ? "truth" : "lie");
                }
            }
        }
    }
    return 0;
}