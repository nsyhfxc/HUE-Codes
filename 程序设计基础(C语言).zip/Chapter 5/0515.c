#include <stdio.h>
#include <math.h>
double f(double x, double a, double b, double c, double d) {
    return a*x*x*x + b*x*x + c*x + d;
}
int main() {
    double a, b, c, d;
    double left = -10.0, right = 10.0, mid;
    double fleft, fright, fmid;
    const double eps = 1e-5;
    scanf("%lf,%lf,%lf,%lf", &a, &b, &c, &d);
    fleft = f(left, a, b, c, d);
    fright = f(right, a, b, c, d);
    if (fleft * fright > 0) {
        return 0;
    }
    while (1) {
        mid = (left + right) / 2.0;
        fmid = f(mid, a, b, c, d);

        if (fabs(fmid) < eps) {
            printf("x=%.2f\n", mid);
            break;
        }

        if (fleft * fmid < 0) {
            right = mid;
            fright = fmid;
        } else {
            left = mid;
            fleft = fmid;
        }
    }

    return 0;
}