#include <stdio.h>

int main() {
    int sum = 0;
    int n;
    int i = 1;
    scanf("%d",&n);
    while (i <= n) {
        sum += i;
        i++;
    }
    printf("sum=%d\n", sum);
    return 0;
}