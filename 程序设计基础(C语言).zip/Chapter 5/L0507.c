#include <stdio.h>
#include <math.h>
#include<stdbool.h>
int main() {
    double pi = 0.0;
    double term;
    int n = 0;
    int sign = 1;

    while(true){
        term = sign * 1.0 / (2 * n + 1);
        if (fabs(term) < 1e-6) break;
        pi += term;
        sign = -sign;
        n++;
    }

    pi *= 4;
    printf("PI:%.8f\n", pi);
    return 0;
}