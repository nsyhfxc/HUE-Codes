#include <stdio.h>
#include <math.h>

int main() {
    double a, x0, x1;
    scanf("%lf", &a);
    x0 = a / 2.0;
    do {
        x1 = (x0 + a / x0) / 2.0;
        if (fabs(x1 - x0) < 1e-5)
            break;
        x0 = x1;
    } while (1);
    printf("%.2f\n", x1);
    return 0;
}