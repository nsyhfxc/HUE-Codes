#include <stdio.h>

int main() {
    int n, sum = 0;
    scanf("%d", &n);
    int i = 1;
    for (i = 1; i <= n; i += 2) {
        sum += i;
    }

    printf("sum=%d\n", sum);
    return 0;
}