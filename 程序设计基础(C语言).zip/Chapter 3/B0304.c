#include <stdio.h>

int main() {
    int a;
    float b;
    // 输入int和float类型的变量
    scanf("%d,%f", &a, &b);

    // 按不同格式输出int变量a
    printf("a=%d,%i,%o,%x,%u\n", a, a, a, a, a);

    // 按不同格式输出float变量b
    printf("b=%d,%i,%o,%x,%u,%f,%e\n",b,b,b,b,b,b,b);

    return 0;
}