#include <stdio.h>

int main() {
    char ch;
    int i;
    for (i = 0; i < 5; i++) {
        ch = getchar();
        putchar(ch + 4);
    }
    putchar('\n');
    return 0;
}