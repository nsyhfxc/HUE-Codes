#include <stdio.h>

int main() {
    float fahrenheit, celsius;
    scanf("%f", &fahrenheit);
    celsius = 5.0f / 9.0f * (fahrenheit - 32.0f);
    printf("%.2f\n", celsius);
    return 0;
}