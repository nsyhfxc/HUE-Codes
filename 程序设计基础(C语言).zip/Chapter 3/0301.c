#include <stdio.h>
#include <math.h>

int main() {
    double rate, multiple;
    int n;
    scanf("%lf %d", &rate, &n);
    multiple = pow(1 + rate, n);
    printf("%.2f\n", multiple);
    return 0;
}