#include <stdio.h>

#define PI 3.1415926

int main() {
    double r, h;
    // 输入半径和高
    scanf("%lf,%lf", &r, &h);

    // 计算
    double circumference = 2 * PI * r;
    double area = PI * r * r;
    double sphere_surface = 4 * PI * r * r;
    double sphere_volume = (4.0 / 3.0) * PI * r * r * r;
    double cylinder_volume = PI * r * r * h;

    // 输出
    printf("%.2f,%.2f\n", circumference, area);
    printf("%.2f,%.2f,%.2f\n", sphere_surface, sphere_volume, cylinder_volume);

    return 0;
}