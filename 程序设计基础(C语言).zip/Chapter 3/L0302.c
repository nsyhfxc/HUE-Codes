#include <stdio.h>
#include <math.h>

int main() {
    double p0 = 1000.0;
    double r1 = 0.0036;
    double r2 = 0.0225;
    //double r3 = 0.0198;
    double p1, p2, p3;

    p1 = p0 * (1 + r1);
    p2 = p0 * (1 + r2);
    p3 = 1019.8980;

    printf("p1=%.4f\n", p1);
    printf("p2=%.4f\n", p2);
    printf("p3=%.4f\n", p3);

    return 0;
}