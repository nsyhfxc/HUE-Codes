#include <stdio.h>

int main() {
    int a;
    double b;
    scanf("%d,%lf", &a, &b);
    printf("a=%6d\n", a);
    printf("b=%8.3f\n", b);
    return 0;
}