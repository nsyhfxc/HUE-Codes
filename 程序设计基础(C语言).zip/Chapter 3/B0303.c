#include <stdio.h>
#include <math.h>

int main() {
    double x, y, z;
    scanf("%lf,%lf", &x, &y);
    z = fabs(sin(2 * x) - 3 * cos(y)) + exp(2 * x - 5 * y);
    printf("%.2f\n", z);
    return 0;
}