#include <stdio.h>
#include <math.h>

int main() {
    double d, p, r;
    double n;

    // 输入贷款总额d、每月还款额p、月利率r
    scanf("%lf %lf %lf", &d, &p, &r);

    // 判断是否可以还清
    if (p <= d * r) {
        printf("无法还清贷款\n");
        return 0;
    }

    // 计算还清贷款所需月数
    n = log(p / (p - d * r)) / log(1 + r);

    // 输出月数，保留1位小数，四舍五入
    printf("%.1f\n", n);

    // 如果需要对小数点后第2位四舍五入，可以这样处理：
    // double rounded = floor(n * 10 + 0.5) / 10;
    // printf("%.1f\n", rounded);

    return 0;
}