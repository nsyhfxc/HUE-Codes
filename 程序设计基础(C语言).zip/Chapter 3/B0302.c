#include <stdio.h>

int main() {
    double r, c, s;
    const double pi = 3.14159;

    scanf("%lf", &r);
    c = 2 * pi * r;
    s = pi * r * r;
    printf("%.2lf,%.2lf\n", c, s);

    return 0;
}