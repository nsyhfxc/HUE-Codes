#include <stdio.h>

int main() {
    char c1, c2, c3;
    c1 = getchar();
    c2 = getchar();
    c3 = getchar();

    printf("%c%c%c\n", c1, c2, c3);
    printf("%d %d %d\n", c1, c2, c3);

    return 0;
}