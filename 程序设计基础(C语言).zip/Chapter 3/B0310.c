#include <stdio.h>

int main() {
    double r = 5.0;
    double pi = 3.14159;
    double S = pi * r * r;
    printf("S=%.1f\n", S);
    return 0;
}