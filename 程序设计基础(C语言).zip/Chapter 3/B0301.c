#include <stdio.h>

int main() {
    double x, y, temp;
    scanf("%lf %lf", &x, &y);
    // 交换x和y的值
    temp = x;
    x = y;
    y = temp;
    // 按要求输出
    printf("x=%7.2f,y=%7.2f\n", x, y);
    return 0;
}