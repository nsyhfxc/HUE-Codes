#include <stdio.h>

int main() {
    char ch;
    scanf("%c", &ch);
    if (ch >= 'a' && ch <= 'z') {
        char upper = ch - ('a' - 'A');
        printf("%c %d\n", upper, upper);
    } 
    return 0;
}