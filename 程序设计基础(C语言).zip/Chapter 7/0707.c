#include <stdio.h>
#include <string.h>

void tiqu(char s1[], char yy[], char s2[]) {
    int i, j = 0;
    
    for (i = 0; s1[i] != '\0'; i++) {
        if (strchr(yy, s1[i]) != NULL) {
            s2[j] = s1[i];
            j++;
        }
    }
    s2[j] = '\0';
}

int main() {
    void tiqu(char s1[], char yy[], char s2[]);
    char yueyin[] = "aoeiuAOEIU";
    char str1[81];
    char str2[82];

    gets(str1);
    tiqu(str1, yueyin, str2);
    puts(str2);

    return 0;
}