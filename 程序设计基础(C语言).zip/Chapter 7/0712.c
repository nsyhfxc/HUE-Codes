#include <stdio.h>
#include <math.h>

float f(float a, float b, float c, float d, float x) {
    return a * pow(x, 3) + b * pow(x, 2) + c * x + d;
}

float f_prime(float a, float b, float c, float x) {
    return 3 * a * pow(x, 2) + 2 * b * x + c;
}

float newton(float a, float b, float c, float d) {
    float x0 = 1.5;
    float x1;
    
    do {
        x1 = x0 - f(a, b, c, d, x0) / f_prime(a, b, c, x0);
        if (fabs(x1 - x0) < 1e-5) {
            return x1;
        }
        x0 = x1;
    } while (1);
}

int main() {
    float a, b, c, d, x;
    
    scanf("%f,%f,%f,%f", &a, &b, &c, &d);
    x = newton(a, b, c, d);
    
    printf("x=%.2f\n", x);
    
    return 0;
}