#include <stdio.h>
#include <math.h>

double calc(double a, double b, double c) {
    return sqrt(a + b + c);
}

int main() {
    double a, b, c;
    scanf("%lf,%lf,%lf", &a, &b, &c);
    printf("%.2lf\n", calc(a, b, c));
    return 0;
}