#include <stdio.h>

#define N 5
int i;
void input(int scores[], int n) {
    for (i = 0; i < n; i++) {
        scanf("%d", &scores[i]);
    }
}

double average(int scores[], int n) {
    int sum = 0;
    for (i = 0; i < n; i++) {
        sum += scores[i];
    }
    return (double)sum / n;
}

int main() {
    int scores[N];
    input(scores, N);
    double avg = average(scores, N);
    printf("average=%.2lf\n", avg);
    return 0;
}