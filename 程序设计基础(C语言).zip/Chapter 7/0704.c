#include <stdio.h>
#define N 11

void input(int a[N][N], int n) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }
}

void output(int a[N][N], int n) {
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%5d", a[i][j]);
        }
        printf("\n");
    }
}

void convert(int a[N][N], int n) {
    int i, j, temp;
    for (i = 0; i < n; i++) {
        for (j = i + 1; j < n; j++) {
            temp = a[i][j];
            a[i][j] = a[j][i];
            a[j][i] = temp;
        }
    }
}

int main() {
    int n;
    int a[N][N];
    
    scanf("%d", &n);

    input(a, n);
    output(a, n);
    convert(a, n);
    printf("Afer transposation:\n");
    output(a, n);

    return 0;
}