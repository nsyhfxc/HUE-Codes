#include <stdio.h>

int main() {
    int n, age;
    scanf("%d", &n);
    age = 10 + (n - 1) * 2;
    printf("%d\n", age);
    return 0;
}