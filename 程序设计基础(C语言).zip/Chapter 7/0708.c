#include <stdio.h>
#include <string.h>

void insertspace(char str[]) {
    char new_str[162];
    int i, j;
    
    j = 0;
    for (i = 0; str[i] != '\0'; i++) {
        new_str[j++] = str[i];
        if (str[i + 1] != '\0') {
            new_str[j++] = ' ';
        }
    }
    new_str[j] = '\0';
    
    strcpy(str, new_str);
}

int main() {
    void insertspace(char str[]);
    char str[81];
    
    gets(str);
    insertspace(str);
    puts(str);
    
    return 0;
}