#include <stdio.h>

int main() {
    int n, i;
    unsigned long long dp[21];
    dp[0] = 1;
    for (i = 1; i <= 20; i++) {
        dp[i] = dp[i - 1] * i;
    }
    scanf("%d", &n);
    if (n >= 0 && n <= 20) {
        printf("%lld\n", dp[n]);
    }
    return 0;
}