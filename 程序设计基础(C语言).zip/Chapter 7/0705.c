#include <stdio.h>
#include <string.h>

void inverse(char s[]) {
    int len = strlen(s);
    int i;
    char temp;

    for (i = 0; i < len / 2; i++) {
        temp = s[i];
        s[i] = s[len - 1 - i];
        s[len - 1 - i] = temp;
    }
}

int main() {
    void inverse(char s[]);
    char str[81];

    gets(str);
    inverse(str);
    puts(str);
    return 0;
}