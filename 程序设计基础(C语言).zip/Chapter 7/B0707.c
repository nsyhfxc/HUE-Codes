#include <stdio.h>
#include <math.h>

int is_prime(int num) {
    if (num <= 1) {
        return 0;
    }
    int i = 2;
    for (i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) {
            return 0;
        }
    }
    return 1;
}

void gdbh(int n) {
    int a, b;
    for (a = 2; a <= n / 2; a++) {
        if (is_prime(a) && is_prime(n - a)) {
            b = n - a;
            printf("%d=%d+%d\n", n, a, b);
            return;
        }
    }
    printf("False\n");
}

int main() {
    int n;
    void gdbh(int n);
    scanf("%d", &n);
    gdbh(n);
    return 0;
}