#include <stdio.h>

double average(double scores[], int n) {
    double sum = 0;
    int i;
    for (i = 0; i < n; i++) {
        sum += scores[i];
    }
    return sum / n;
}

int main() {
    double scores1[] = {98.5, 97, 91.5, 60, 55};
    double scores2[] = {67.5, 89.5, 99, 69.5, 77, 89.5, 76.5, 54, 60, 99.5};
    
    double aver1 = average(scores1, 5);
    double aver2 = average(scores2, 10);
    
    printf("aver1=%.2f,aver2=%.2f\n", aver1, aver2);
    
    return 0;
}