#include <stdio.h>

int sum_day(int year, int month, int day) {
    int mdays[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int total_days = 0;
    int i;

    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
        mdays[2] = 29;
    }

    for (i = 1; i < month; i++) {
        total_days += mdays[i];
    }
    total_days += day;

    return total_days;
}

int main() {
    int year, month, day;

    scanf("%d,%d,%d", &year, &month, &day);
    printf("%d\n", sum_day(year, month, day));

    return 0;
}