#include <stdio.h>

int main() {
    int n, i;
    long long dp[21];
    dp[0] = 1;

    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        dp[i] = dp[i - 1] * i;
    }

    for (i = 1; i <= n; i++) {
        printf("%d!=%lld\n", i, dp[i]);
    }

    return 0;
}