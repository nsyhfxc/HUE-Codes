#include <stdio.h>
#include <string.h>
#include <ctype.h>

void extract(char s1[], char s2[]) {
    int i, j = 0;
    for (i = 0; s1[i] != '\0'; i++) {
        if (islower(s1[i]) || isdigit(s1[i])) {
            s2[j++] = s1[i];
        }
    }
    s2[j] = '\0';
}

void reverse(char str[]) {
    int i, j;
    char t;
    for (i = 0, j = strlen(str) - 1; i < j; i++, j--) {
        t = str[i];
        str[i] = str[j];
        str[j] = t;
    }
}

int main() {
    char s1[81], s2[81];
    void extract(char s1[], char s2[]);
    void reverse(char str[]);

    gets(s1);
    extract(s1, s2);
    puts(s2);
    reverse(s2);
    puts(s2);

    return 0;
}