#include <stdio.h>
#include <stdbool.h>

int isPrime(int xxx) {
    if (xxx <= 1) {
        return 0; 
    }
    int i = 2;
    for (i = 2; i * i <= xxx; i++) {
        if (xxx % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    int n;

    do {
        scanf("%d", &n);
    } while (n < 2);

    if (isPrime(n)) {
        printf("Yes\n");
    } else {
        printf("No\n");
    }

    return 0;
}