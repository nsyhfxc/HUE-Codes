#include <stdio.h>

long long days_between_dates(int year1, int month1, int day1, int year2, int month2, int day2);
int is_leap(int year);
int days_in_month(int year, int month);
long long date_to_days(int year, int month, int day);

int is_leap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int days_in_month(int year, int month) {
    if (month == 2) {
        return is_leap(year) ? 29 : 28;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        return 30;
    } else {
        return 31;
    }
}

long long date_to_days(int year, int month, int day) {
    long long total_days = 0;
    int i;
    for (i = 1; i < year; i++) {
        total_days += is_leap(i) ? 366 : 365;
    }
    for (i = 1; i < month; i++) {
        total_days += days_in_month(year, i);
    }
    total_days += day;
    return total_days;
}

long long days(int year1, int month1, int day1, int year2, int month2, int day2) {
    return date_to_days(year2, month2, day2) - date_to_days(year1, month1, day1);
}

int main() {
    int year1, month1, day1, year2, month2, day2;

    scanf("%d%d%d%d%d%d", &year1, &month1, &day1, &year2, &month2, &day2);
    printf("%lld\n", days(year1, month1, day1, year2, month2, day2));
    
    return 0;
}