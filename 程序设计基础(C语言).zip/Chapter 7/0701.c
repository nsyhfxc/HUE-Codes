#include <stdio.h>

int gy(int m, int n) {
    int r;
    while (n != 0) {
        r = m % n;
        m = n;
        n = r;
    }
    return m;
}

int main() {
    int m, n;
    int max, min;
    int r;

    scanf("%d,%d", &m, &n);
    max = gy(m, n);
    min = m * n / max;
    printf("%d,%d\n", max, min);

    return 0;
}