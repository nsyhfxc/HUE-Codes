#include <stdio.h>
#include <string.h>

#define N 5

void input(char str[][81], int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%s", str[i]);
    }
}

void output(char str[][81], int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%s\n", str[i]);
    }
}

void seleSort(char str[][81], int n) {
    int i, j;
    char t[81];
    for (i = 0; i < n - 1; i++) {
        int m = i;
        for (j = i + 1; j < n; j++) {
            if (strcmp(str[j], str[m]) < 0) {
                m = j;
            }
        }
        if (m != i) {
            strcpy(t, str[i]);
            strcpy(str[i], str[m]);
            strcpy(str[m], t);
        }
    }
}

int main() {
    void input(char str[][81], int n);
    void output(char str[][81], int n);
    void seleSort(char str[][81], int n);
    char str[N][81];

    input(str, N);
    seleSort(str, N);
    printf("After sorting:\n");
    output(str, N);

    return 0;
}