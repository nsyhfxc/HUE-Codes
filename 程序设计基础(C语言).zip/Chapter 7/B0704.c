#include <stdio.h>

double add(double a, double b) {
    return a + b;
}

int main() {
    double a, b, c;
    scanf("%lf,%lf", &a, &b);
    c = add(a, b);
    printf("%.3lf\n", c);
    return 0;
}