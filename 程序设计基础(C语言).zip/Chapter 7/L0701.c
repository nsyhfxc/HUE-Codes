#include<stdio.h>
int main(){
    printf("********************\n  How do you do!\n********************");
    return 0;
}