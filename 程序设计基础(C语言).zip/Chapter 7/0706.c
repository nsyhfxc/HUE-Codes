#include <stdio.h>

void link(char str1[], char str2[], char str3[]) {
    int i = 0, j = 0;

    while (str1[i] != '\0') {
        str3[j] = str1[i];
        i++;
        j++;
    }

    i = 0;
    while (str2[i] != '\0') {
        str3[j] = str2[i];
        i++;
        j++;
    }
    str3[j] = '\0';
}

int main() {
    void link(char str1[], char str2[], char str3[]);
    char str1[81];
    char str2[81];
    char str3[162];

    gets(str1);
    gets(str2);
    link(str1, str2, str3);
    puts(str3);
    return 0;
}