#include <stdio.h>

int main() {
    long long count = 1;
    int a, b;
    int i,j;
    for (i = 0; i < (1 << 14); i++) {
        int wine = 2;
        a = 0;
        b = 0;
        int flag = 1;
        for (j = 0; j < 15; j++) {
            if ((i >> j) & 1) {
                b++;
                if (wine == 0) {
                    flag = 0;
                    break;
                }
                wine--;
            } else {
                a++;
                wine *= 2;
            }
        }
        if (flag && a == 5 && b == 10 && wine == 0) {
            count++;
        }
    }
    printf("%lld\n", count);
    return 0;
}