#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool isCharacter(char c) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) {
        return true;
    }
    return false;
}

int longest(char s[]) {
    int max_len = 0, current_len = 0;
    int max_index = -1, current_index = 0;
    int i;
    
    for (i = 0; s[i] != '\0'; i++) {
        if (isCharacter(s[i])) {
            if (current_len == 0) {
                current_index = i;
            }
            current_len++;
        } else {
            if (current_len > max_len) {
                max_len = current_len;
                max_index = current_index;
            }
            current_len = 0;
        }
    }
    
    if (current_len > max_len) {
        max_index = current_index;
    }
    
    return max_index;
}

int main() {
    bool isCharacter(char c);
    int longest(char s[]);
    char str[81];
    int i;

    gets(str);

    for (i = longest(str); isCharacter(str[i]); i++) {
        putchar(str[i]);
    }
    putchar('\n');

    return 0;
}