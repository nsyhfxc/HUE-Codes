#include <stdio.h>

int main() {
    int matrix[3][4];
    int max = -2147483648;
    int i, j;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            scanf("%d", &matrix[i][j]);
            if (matrix[i][j] > max) {
                max = matrix[i][j];
            }
        }
    }

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            printf("%5d", matrix[i][j]);
        }
        printf("\n");
    }

    printf("max=%d\n", max);

    return 0;
}