#include <stdio.h>

double f(int n, double x) {
    if (n == 0) {
        return x + 1.1;
    } else if (n == 1) {
        return x * 2.3;
    } else {
        return f(n - 1, x) + 2 * f(n - 2, x);
    }
}

int main() {
    int n;
    double x;
    scanf("%d,%lf", &n, &x);
    printf("%.2lf\n", f(n, x));
    return 0;
}