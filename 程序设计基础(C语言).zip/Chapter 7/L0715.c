#include <stdio.h>

int a = 3, b = 5;

int max(int a, int b) {
    return a > b ? a : b;
}

int main() {
    int a;
    scanf("%d", &a);
    printf("max=%d", max(a, b));
    return 0;
}