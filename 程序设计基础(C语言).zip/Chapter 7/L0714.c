#include <stdio.h>
int i,j;
void analyze(double scores[], int n, double *max, double *min, double *avg) {
    *max = scores[0];
    *min = scores[0];
    double sum = 0;
    for (i = 0; i < n; i++) {
        sum += scores[i];
        if (scores[i] > *max) {
            *max = scores[i];
        }
        if (scores[i] < *min) {
            *min = scores[i];
        }
    }
    *avg = sum / n;
}

int main() {
    double scores[10];
    double max, min, avg;

    for (i = 0; i < 10; i++) {
        scanf("%lf", &scores[i]);
    }

    analyze(scores, 10, &max, &min, &avg);

    printf("max=%.2f,min=%.2f,average=%.2f\n", max, min, avg);

    return 0;
}