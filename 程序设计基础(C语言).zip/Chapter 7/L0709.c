#include <stdio.h>

int main() {
    int n, i, m = -2147483648, l;
    scanf("%d", &n);
    int a[n];
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (a[i] > m) {
            m = a[i];
            l = i + 1;
        }
    }
    printf("max=%d,loc=%d\n", m, l);
    return 0;
}