#include <stdio.h>
#define N 6

void input(float a[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%f", &a[i]);
    }
}

void output(float a[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%.2f ", a[i]);
    }
    printf("\n");
}

void bubbleSort(float a[], int n) {
    int i, j;
    float temp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (a[j] > a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

int main() {
    void input(float a[], int n);
    void output(float a[], int n);
    void bubbleSort(float a[], int n);
    
    float a[N];
    
    intput(a, N);
    bubbleSort(a, N);
    output(a, N);
    
    return 0;
}