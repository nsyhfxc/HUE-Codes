#include <stdio.h>

int mul(int x, int y) {
    return x * y;
}

int main() {
    int n1, n2, sum;
    scanf("%d%d", &n1, &n2);
    sum = mul(n1, n2);
    printf("%d", sum);
    return 0;
}