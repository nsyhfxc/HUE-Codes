#include <stdio.h>

void convert(int n) {
    if (n / 10 != 0) {
        convert(n / 10);
    }
    putchar(n % 10 + '0');
}

int main() {
    void convert(int n);
    int n;

    scanf("%d", &n);
    if (n < 0) {
        putchar('-');
        n = -n;
    }
    convert(n);
    putchar('\n');

    return 0;
}