#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

long long hex_to_dec_recursive(char s[], int len) {
    if (len == 0) {
        return 0;
    }
    
    char c = s[len - 1];
    long long value;
    if (isdigit(c)) {
        value = c - '0';
    } else if (islower(c)) {
        value = c - 'a' + 10;
    } else {
        value = c - 'A' + 10;
    }
    
    return value + 16 * hex_to_dec_recursive(s, len - 1);
}

int main() {
    char hex_str[100];
    long long dec_num;
    
    scanf("%s", hex_str);
    
    dec_num = hex_to_dec_recursive(hex_str, strlen(hex_str));
    
    printf("%lld\n", dec_num);
    
    return 0;
}