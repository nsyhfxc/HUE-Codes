#include<stdio.h>
int main()
{
    float lei(float x,int n);
    int n;
    float x;
    scanf("%f%d",&x,&n);
    printf("%.4f",lei(x,n));
    return 0;
}
float lei(float x,int n)
{
    float z;
    if(n==0)
        z=1.0;
    else if(n==1)
        z=x;
    else
        z=(float)(((2*n-1)*x-lei(x,n-1)-(n-1)*lei(x,n-2))/n);
    return z;
}