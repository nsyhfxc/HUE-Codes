#include <stdio.h>

#define N 6
int i,j;
void input(int a[], int n) {
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
}

void output(int a[], int n) {
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void sort(int a[], int n) {
    for (i = 0; i < n - 1; i++) {
        int m = i;
        for (j = i + 1; j < n; j++) {
            if (a[j] < a[m]) {
                m = j;
            }
        }
        if (m != i) {
            int t = a[i];
            a[i] = a[m];
            a[m] = t;
        }
    }
}

int main() {
    int a[N];
    input(a, N);
    sort(a, N);
    output(a, N);
    return 0;
}