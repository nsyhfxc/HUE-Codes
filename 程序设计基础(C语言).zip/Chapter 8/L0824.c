#include <stdio.h>

int add(int a, int b) {
    return a + b;
}

int sub(int a, int b) {
    return a - b;
}

int mul(int a, int b) {
    return a * b;
}

int div(int a, int b) {
    if (b != 0) {
        return a / b;
    } else {
        return 0;
    }
}

int main() {
    int a, b;
    char op;
    int (*p)(int, int);

    scanf("%d,%d\n", &a, &b);
    scanf("%c", &op);

    switch (op) {
        case '+':
            p = add;
            printf("%d+%d=%d\n", a, b, (*p)(a, b));
            break;
        case '-':
            p = sub;
            printf("%d-%d=%d\n", a, b, (*p)(a, b));
            break;
        case '*':
            p = mul;
            printf("%d*%d=%d\n", a, b, (*p)(a, b));
            break;
        case '/':
            p = div;
            printf("%d/%d=%d\n", a, b, (*p)(a, b));
            break;
    }

    return 0;
}