#include <stdio.h>
#include <string.h>
#include <ctype.h>

void extract(char *p1, char *p2) {
    int i, j = 0;
    for (i = 0; p1[i] != '\0'; i++) {
        if (isupper(p1[i]) || isdigit(p1[i])) {
            p2[j++] = p1[i];
        }
    }
    p2[j] = '\0';
}

void reverse(char *p) {
    int i, j;
    char t;
    j = strlen(p) - 1;
    for (i = 0; i < j; i++, j--) {
        t = p[i];
        p[i] = p[j];
        p[j] = t;
    }
}

int main() {
    char s1[81], s2[81];
    void extract(char *p1, char *p2);
    void reverse(char *p);

    gets(s1);
    extract(s1, s2);
    puts(s2);
    reverse(s2);
    puts(s2);

    return 0;
}