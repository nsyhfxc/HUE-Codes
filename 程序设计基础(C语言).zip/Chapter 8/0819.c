#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void bubbleSort(char **p, int n) {
    int i, j;
    char *t;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (strcmp(p[j], p[j + 1]) < 0) {
                t = p[j];
                p[j] = p[j + 1];
                p[j + 1] = t;
            }
        }
    }
}

int main() {
    int n;
    int i;
    char *s[20];
    char buf[100];

    scanf("%d", &n);
    getchar(); 

    for (i = 0; i < n; i++) {
        fgets(buf, 100, stdin);
        buf[strcspn(buf, "\n")] = 0; 
        s[i] = (char *)malloc(strlen(buf) + 1);
        strcpy(s[i], buf);
    }

    bubbleSort(s, n);

    printf("Ordered strings:\n");
    for (i = 0; i < n; i++) {
        printf("%s\n", s[i]);
        free(s[i]);
    }

    return 0;
}