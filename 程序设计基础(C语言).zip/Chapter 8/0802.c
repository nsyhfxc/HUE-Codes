#include <stdio.h>
#include <string.h>

void swap(char *p1, char *p2) {
    char temp[81];
    strcpy(temp, p1);
    strcpy(p1, p2);
    strcpy(p2, temp);
}

int main() {
    void swap(char *p1, char *p2);
    char str1[81], str2[81], str3[81];

    gets(str1);
    gets(str2);
    gets(str3);

    if (strcmp(str1, str2) > 0) {
        swap(str1, str2);
    }
    if (strcmp(str1, str3) > 0) {
        swap(str1, str3);
    }
    if (strcmp(str2, str3) > 0) {
        swap(str2, str3);
    }

    puts(str1);
    puts(str2);
    puts(str3);

    return 0;
}