#include <stdio.h>

int main() {
    int n, i, count, left, p = 0;
    int a[100] = {0};

    scanf("%d", &n);

    left = n;
    count = 0;
    while (left > 1) {
        if (a[p] == 0) {
            count++;
            if (count == 3) {
                a[p] = 1;
                left--;
                count = 0;
            }
        }
        p++;
        if (p == n) {
            p = 0;
        }
    }

    for (i = 0; i < n; i++) {
        if (a[i] == 0) {
            printf("%d\n", i + 1);
            break;
        }
    }

    return 0;
}