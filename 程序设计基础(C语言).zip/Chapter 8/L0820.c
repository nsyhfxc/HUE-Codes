#include <stdio.h>

void cpy(char *from, char *to) {
    while ((*to++ = *from++) != '\0');
}

int main() {
    char a[80], b[80];

    gets(a);
    cpy(a, b);
    puts(b);

    return 0;
}