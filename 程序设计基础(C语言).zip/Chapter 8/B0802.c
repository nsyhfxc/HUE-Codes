#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

bool huiwen(char *p) {
    int i, j;
    char s[100];
    int len, k = 0;

    for (i = 0; p[i] != '\0'; i++) {
        if (isalnum(p[i])) {
            s[k++] = tolower(p[i]);
        }
    }
    s[k] = '\0';
    len = strlen(s);
    j = len - 1;
    for (i = 0; i < len / 2; i++, j--) {
        if (s[i] != s[j]) {
            return false;
        }
    }
    return true;
}

int main() {
    bool huiwen(char *p);
    char str[100];

    gets(str);
    if (huiwen(str)) {
        printf("True\n");
    } else {
        printf("False\n");
    }

    return 0;
}