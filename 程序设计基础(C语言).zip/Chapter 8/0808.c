#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str[1000];
    int upper = 0, lower = 0, space = 0, digit = 0, others = 0;
    int i;

    // 从标准输入读取一行字符串
    // gets() 函数不安全，在实际开发中应避免使用
    // 这里为了简单起见，且题目未涉及复杂输入，故使用它
    gets(str);

    // 遍历字符串
    for (i = 0; str[i] != '\0'; i++) {
        // 使用 ctype.h 库中的函数进行判断
        if (isupper(str[i])) {
            upper++;
        } else if (islower(str[i])) {
            lower++;
        } else if (isspace(str[i])) {
            space++;
        } else if (isdigit(str[i])) {
            digit++;
        } else {
            others++;
        }
    }

    // 打印结果
    printf("upper case:%d,lower case:%d,space:%d,digit:%d,others:%d\n", upper, lower, space, digit, others);

    return 0;
}