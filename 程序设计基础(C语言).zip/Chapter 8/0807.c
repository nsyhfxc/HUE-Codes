#include <stdio.h>
#include <string.h>

void copystr(char *p1, char *p2, int m) {
    int i = 0;
    while (*(p1 + m - 1) != '\0') {
        *(p2 + i) = *(p1 + m - 1);
        m++;
        i++;
    }
    *(p2 + i) = '\0';
}

int main() {
    void copystr(char *p1, char *p2, int m);
    char str1[81], str2[81];
    int m;

    gets(str1);
    scanf("%d", &m);

    if (strlen(str1) < m) {
        printf("Input error!\n");
    } else {
        copystr(str1, str2, m);
        printf("%s\n", str2);
    }

    return 0;
}