#include <stdio.h>

int max(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

int main() {
    int a, b;
    int (*p)(int, int);

    scanf("%d,%d", &a, &b);

    p = max;
    printf("max=%d\n", (*p)(a, b));

    return 0;
}