#include <stdio.h>

int STRCMP(char *p1, char *p2) {
    int i = 0;
    while (p1[i] != '\0' && p2[i] != '\0') {
        if (p1[i] != p2[i]) {
            return p1[i] - p2[i];
        }
        i++;
    }
    return p1[i] - p2[i];
}

int main() {
    char str1[81], str2[81];
    int STRCMP(char *p1, char *p2);

    int n;

    printf("Please input two strings:\n");
    fgets(str1, 81, stdin);
    fgets(str2, 81, stdin);

    n = STRCMP(str1, str2);
    printf("%d\n", n);

    return 0;
}