#include <stdio.h>
#define N 50
int i;
void input(int *p, int n) {
    for (i = 0; i < n; i++) {
        scanf("%d", &p[i]);
    }
}

void output(int *p, int n) {
    for (i = 0; i < n; i++) {
        printf("%8d", p[i]);
    }
    printf("\n");
}

void sort(int *p, int n) {
    int t;
    for (i = 0; i < n / 2; i++) {
        t = p[i];
        p[i] = p[n - 1 - i];
        p[n - 1 - i] = t;
    }
}

int main() {
    int n;
    int num[50];

    printf("Please input the nubers of the data(n):\n");
    scanf("%d", &n);

    input(num, n);
    output(num, n);
    sort(num, n);
    output(num, n);

    return 0;
}