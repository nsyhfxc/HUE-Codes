#include <stdio.h>

#define N 10
int i;

void input(int *p, int n) {
    for (i = 0; i < n; i++) {
        scanf("%d", p + i);
    }
}

void max_array(int *p, int n) {
    int max = *p;
    int max_i = 0;
    int *last = p + n - 1;
    for (i = 1; i < n; i++) {
        if (*(p + i) > max) {
            max = *(p + i);
            max_i = i;
        }
    }
    int temp = *last;
    *last = *(p + max_i);
    *(p + max_i) = temp;
}

void min_array(int *p, int n) {
    int min = *p;
    int min_i = 0;
    int *first = p;
    for (i = 1; i < n; i++) {
        if (*(p + i) < min) {
            min = *(p + i);
            min_i = i;
        }
    }
    int temp = *first;
    *first = *(p + min_i);
    *(p + min_i) = temp;
}

void output(int *p, int n) {
    for (i = 0; i < n; i++) {
        printf("%6d", *(p + i));
    }
    printf("\n");
}

int main() {
    void input(int *p, int n);
    void move(int num[], int n, int m);
    void output(int *p, int n);
    int num[50], n, m;

    scanf("%d", &n);
    input(num, n);
    scanf("%d", &m);

    move(num, n, m);
    output(num, n);

    return 0;
}