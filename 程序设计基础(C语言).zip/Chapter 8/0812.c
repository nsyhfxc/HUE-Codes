#include <stdio.h>
#include <string.h>

#define N 5

void input(char *s[]) {
    int i;
    for (i = 0; i < N; i++) {
        gets(s[i]);
    }
}

void sort(char *s[]) {
    int i, j;
    char *temp;
    for (i = 0; i < N - 1; i++) {
        for (j = i + 1; j < N; j++) {
            if (strcmp(s[i], s[j]) > 0) {
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }
        }
    }
}

void output(char *s[]) {
    int i;
    for (i = 0; i < N; i++) {
        puts(s[i]);
    }
}

int main() {
    void sort(char *s[]);
    void input(char *s[]);
    void output(char *s[]);

    char *p[N];
    char str[N][81];
    int i;

    for (i = 0; i < N; i++) {
        p[i] = str[i];
    }

    input(p);
    sort(p);
    printf("After sorting:\n");
    output(p);

    return 0;
}