#include <stdio.h>

int length(char *p) {
    int len = 0;
    while (*(p + len) != '\0') {
        len++;
    }
    return len;
}

int main() {
    int length(char *p);
    int len;
    char str[81];

    gets(str);
    len = length(str);
    printf("len=%d\n", len);

    return 0;
}