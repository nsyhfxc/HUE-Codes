#include <stdio.h>

void cpy(char *s1, char *s2) {
    int i;
    for (i = 0; s1[i] != '\0'; i++) {
        s2[i] = s1[i];
    }
    s2[i] = '\0';
}

int main() {
    char a[80], b[80];

    gets(a);
    cpy(a, b);
    puts(b);

    return 0;
}