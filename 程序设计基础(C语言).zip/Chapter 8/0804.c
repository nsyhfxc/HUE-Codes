#include <stdio.h>
#define N 50

// 输入函数
int i = 0;
void input(int *p, int n) {
    for (i = 0; i < n; i++) {
        scanf("%d", p + i);
    }
}

// 移动函数（循环右移 m 位）
void move(int num[], int n, int m) {
    int temp[N];
    m = m % n; // 防止 m >= n
    for (i = 0; i < n; i++) {
        temp[(i + m) % n] = num[i];
    }
    for (i = 0; i < n; i++) {
        num[i] = temp[i];
    }
}

// 输出函数（每个元素宽度至少 6）
void output(int *p, int n) {
    for (i = 0; i < n; i++) {
        printf("%6d", *(p + i));
    }
}

int main() {
    void input(int *p, int n);
    void move(int num[], int n, int m);
    void output(int *p, int n);
    int num[N], n, m;

    scanf("%d", &n);
    input(num, n);
    scanf("%d", &m);

    move(num, n, m);
    output(num, n);

    return 0;
}
