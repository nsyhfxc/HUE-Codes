#include <stdio.h>

#define N 5

int main() {
    int a[N];
    int *p, i;

    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }

    p = a;
    for (i = 0; i < N; i++) {
        printf("%5d", *(p + i));
    }
    printf("\n");

    return 0;
}