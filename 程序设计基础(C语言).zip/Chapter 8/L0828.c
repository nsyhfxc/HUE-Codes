#include <stdio.h>
#include <string.h>

#define N 5

void input(char **p, int n) {
    int i;
    for (i = 0; i < n; i++) {
        gets(p[i]);
    }
}

void output(char **p, int n) {
    int i;
    for (i = 0; i < n; i++) {
        puts(p[i]);
    }
}

void sort(char **p, int n) {
    int i, j, k;
    char *t;
    for (i = 0; i < n - 1; i++) {
        k = i;
        for (j = i + 1; j < n; j++) {
            if (strcmp(p[k], p[j]) > 0) {
                k = j;
            }
        }
        if (k != i) {
            t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
    }
}

int main() {
    void input(char **p, int n);
    void output(char **p, int n);
    void sort(char **p, int n);

    char str[N][81];
    char *name[N];
    char **p;
    int i;

    for (i = 0; i < N; i++) {
        name[i] = str[i];
    }
    p = name;

    input(p, N);
    sort(p, N);
    output(p, N);

    return 0;
}