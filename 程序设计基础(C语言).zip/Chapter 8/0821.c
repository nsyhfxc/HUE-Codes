#include <stdio.h>
#define N 50
void input(int *p, int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d", &p[i]);
    }
}

void output(int **p, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%8d", *p[i]);
    }
    printf("\n");
}

void bubbleSort(int **p, int n) {
    int i, j;
    int *t;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (*p[j] < *p[j + 1]) {
                t = p[j];
                p[j] = p[j + 1];
                p[j + 1] = t;
            }
        }
    }
}

void seleSort(int **p, int n) {
    int i, j, k;
    int *t;
    for (i = 0; i < n - 1; i++) {
        k = i;
        for (j = i + 1; j < n; j++) {
            if (*p[j] > *p[k]) {
                k = j;
            }
        }
        if (k != i) {
            t = p[i];
            p[i] = p[k];
            p[k] = t;
        }
    }
}

int main()
{
    void input(int *p, int n);
    void output(int **p, int n);
    void bubbleSort(int **p,int n);
    void seleSort(int **p,int n);
    
    int a[N];
    int n,i;
    int *pa[N];
    
    //printf("Please input number n:");
    scanf("%d",&n);
     
    input(a,n);
    for(i=0; i<N; i++)
    {
        pa[i]=&a[i];    
    }    
    output(pa,n);
    bubbleSort(pa,n);
    //seleSort(pa,n);
        
    printf("Ordered numbers:\n");
    output(pa,n);
    
    return 0;
}