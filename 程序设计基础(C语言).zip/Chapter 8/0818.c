#include <stdio.h>

int main() {
    char *month_name[13] = {
        "Illegal month", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };
    int m;

    scanf("%d", &m);

    if (m >= 1 && m <= 12) {
        printf("It is %s.\n", month_name[m]);
    } else {
        printf("It is wrong.\n");
    }

    return 0;
}