#include <stdio.h>
#include <stdlib.h>

void check(int *p, int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (*(p + i) < 60) {
            printf("%d ", *(p + i));
        }
    }
    printf("\n");
}

int main() {
    int n = 5;
    int *p, i;

    p = (int *)malloc(n * sizeof(int));
    if (p == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    for (i = 0; i < n; i++) {
        scanf("%d", p + i);
    }

    check(p, n);

    free(p);
    return 0;
}