#include <stdio.h>

int main() {
    int n, i, j;
    scanf("%d", &n);
    int a[n][n];

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%6d", a[i][j]);
        }
        printf("\n");
    }
    printf("The result is:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            printf("%6d", a[j][i]);
        }
        printf("\n");
    }

    return 0;
}