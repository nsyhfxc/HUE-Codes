#include <stdio.h>
#include <string.h>

#define N 5

void input(char *name[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        gets(name[i]);
    }
}

void output(char *name[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        puts(name[i]);
    }
}

void sort(char *name[], int n) {
    int i, j, k;
    char *t;
    for (i = 0; i < n - 1; i++) {
        k = i;
        for (j = i + 1; j < n; j++) {
            if (strcmp(name[k], name[j]) > 0) {
                k = j;
            }
        }
        if (k != i) {
            t = name[i];
            name[i] = name[k];
            name[k] = t;
        }
    }
}

int main() {
    void input(char *name[], int n);
    void output(char *name[], int n);
    void sort(char *name[], int n);

    char str[N][81];
    char *name[N];
    int i;

    for (i = 0; i < N; i++) {
        name[i] = str[i];
    }

    input(name, N);
    sort(name, N);
    output(name, N);

    return 0;
}