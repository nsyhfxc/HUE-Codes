#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char s[1000];
    int a[100];
    int i, j, k, n, num, count;

    while (fgets(s, sizeof(s), stdin)) {
        n = strlen(s);
        count = 0;
        i = 0;
        while (i < n) {
            if (isdigit(s[i])) {
                num = 0;
                j = i;
                while (j < n && isdigit(s[j])) {
                    num = num * 10 + (s[j] - '0');
                    j++;
                }
                a[count++] = num;
                i = j;
            } else {
                i++;
            }
        }

        for (k = 0; k < count; k++) {
            printf("%8d", a[k]);
        }
        printf("\n");
    }

    return 0;
}