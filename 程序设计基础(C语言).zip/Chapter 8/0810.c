#include<stdio.h>
#define N 5
void input(int *p)
{
	int i;
	for(i=0;i<N*N;i++,p++) scanf("%d",p);
}

void output(int (*p)[N])
{
	int i,j;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			printf("%8d",*(*(p+i)+j));
		}
		printf("\n");
	}
}

void change(int (*p)[N])
{
	void moveMax(int (*p)[N],int mid);
	void moveMin1(int (*p)[N],int ii,int jj);
	void moveMin2(int (*p)[N],int ii,int jj);
	void moveMin3(int (*p)[N],int ii,int jj);
	void moveMin4(int (*p)[N],int ii,int jj);
	
	moveMax(p,N/2);
	moveMin1(p,0,0);
	moveMin2(p,0,N-1);
	moveMin3(p,N-1,0);
	moveMin4(p,N-1,N-1);
}

void moveMax(int (*p)[N],int mid)
{
	int max,mi,mj,t,i,j;
	max=p[0][0],mi=0,mj=0;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			if(max<p[i][j])
			{
				max=p[i][j];
				mi=i,mj=j;
			}
		}
	}
	if(mi!=mid||mj!=mid)
	{
		t=p[mid][mid];
		p[mid][mid]=p[mi][mj];
		p[mi][mj]=t;
	}
}

void moveMin1(int (*p)[N],int ii,int jj)
{
	int min,mi,mj,t,i,j;
	min=p[0][0],mi=0,mj=0;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			if(min>p[i][j])
			{
				min=p[i][j];
				mi=i,mj=j;
			}
		}
	}
	if(mi!=ii||mj!=jj)
	{
		t=p[ii][jj];
		p[ii][jj]=p[mi][mj];
		p[mi][mj]=t;
	}
}

void moveMin2(int (*p)[N],int ii,int jj)
{
	int min,mi,mj,t,i,j;
	min=p[0][1],mi=0,mj=1;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			if(i==0&&j==0) continue;
			if(min>p[i][j])
			{
				min=p[i][j];
				mi=i,mj=j;
			}
		}
	}
	if(mi!=ii||mj!=jj)
	{
		t=p[ii][jj];
		p[ii][jj]=p[mi][mj];
		p[mi][mj]=t;
	}
}

void moveMin3(int (*p)[N],int ii,int jj)
{
	int min,mi,mj,t,i,j;
	min=p[0][2],mi=0,mj=2;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			if(i==0&&j==0) continue;
			if(i==0&&j==N-1) continue;
			if(min>p[i][j])
			{
				min=p[i][j];
				mi=i,mj=j;
			}
		}
	}
	if(mi!=ii||mj!=jj)
	{
		t=p[ii][jj];
		p[ii][jj]=p[mi][mj];
		p[mi][mj]=t;
	}
}

void moveMin4(int (*p)[N],int ii,int jj)
{
	int min,mi,mj,t,i,j;
	min=p[0][3],mi=0,mj=3;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			if(i==0&&j==0) continue;
			if(i==0&&j==N-1) continue;
			if(i==N-1&&j==0) continue;
			if(min>p[i][j])
			{
				min=p[i][j];
				mi=i,mj=j;
			}
		}
	}
	if(mi!=ii||mj!=jj)
	{
		t=p[ii][jj];
		p[ii][jj]=p[mi][mj];
		p[mi][mj]=t;
	}
}