#include <stdio.h>

int main() {
    int a, b;
    int *max, *min;

    scanf("%d,%d", &a, &b);

    if (a > b) {
        max = &a;
        min = &b;
    } else {
        max = &b;
        min = &a;
    }

    printf("a=%d,b=%d,max=%d,min=%d\n", a, b, *max, *min);

    return 0;
}