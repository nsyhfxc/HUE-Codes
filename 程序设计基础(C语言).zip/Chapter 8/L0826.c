#include <stdio.h>

float *search(float (*p)[4], int n) {
    return NULL;
}

float *search2(float (*p)[4]) {
    int i;
    for (i = 0; i < 4; i++) {
        if (*(*p + i) < 60.0) {
            return *p;
        }
    }
    return NULL;
}

int main() {
    float score[3][4] = {{60, 70, 80, 90}, {56, 89, 67, 88}, {34, 78, 90, 66}};
    float *search(float (*p)[4], int n);
    float *search2(float (*p)[4]);
    float *p;
    int i, j;

    for (i = 0; i < 3; i++) {
        p = search2(score + i);
        if (p != NULL) {
            printf("No.%d score: ", i + 1);
            for (j = 0; j < 4; j++) {
                printf("%8.2f", *(p + j));
            }
            printf("\n");
        }
    }

    return 0;
}