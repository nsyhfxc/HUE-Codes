#include <stdio.h>

#define N 6

void inv(int *x, int n) {
    int *i, *j, t;
    i = x;
    j = x + n - 1;
    while (i < j) {
        t = *i;
        *i = *j;
        *j = t;
        i++;
        j--;
    }
}

int main() {
    int a[N];
    int i;

    for (i = 0; i < N; i++) {
        scanf("%d", &a[i]);
    }

    inv(a, N);

    for (i = 0; i < N; i++) {
        printf("%6d", a[i]);
    }
    printf("\n");

    return 0;
}