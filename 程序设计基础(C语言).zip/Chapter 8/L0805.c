#include <stdio.h>

void sort(int *p1, int *p2, int *p3) {
    int t;
    if (*p1 < *p2) {
        t = *p1;
        *p1 = *p2;
        *p2 = t;
    }
    if (*p1 < *p3) {
        t = *p1;
        *p1 = *p3;
        *p3 = t;
    }
    if (*p2 < *p3) {
        t = *p2;
        *p2 = *p3;
        *p3 = t;
    }
}

int main() {
    int a, b, c;

    scanf("%d %d %d", &a, &b, &c);

    sort(&a, &b, &c);

    printf("%d,%d,%d\n", a, b, c);

    return 0;
}