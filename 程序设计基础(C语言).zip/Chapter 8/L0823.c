#include <stdio.h>

int max(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

int min(int a, int b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}

int main() {
    int a, b, c;
    int (*p)(int, int);

    scanf("%d,%d", &a, &b);
    scanf("%d", &c);

    if (c == 1) {
        p = max;
        printf("max=%d\n", (*p)(a, b));
    } else if (c == 2) {
        p = min;
        printf("min=%d\n", (*p)(a, b));
    }

    return 0;
}