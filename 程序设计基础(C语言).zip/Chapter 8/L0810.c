#include <stdio.h>

#define N 10

void input(int *x, int n) {
    int i;
    for (i = 0; i < n; i++) {
        scanf("%d", x + i);
    }
}

void output(int *x, int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%5d", *(x + i));
    }
    printf("\n");
}

void sort(int *x, int n) {
    int i, j, t;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (*(x + j) < *(x + j + 1)) {
                t = *(x + j);
                *(x + j) = *(x + j + 1);
                *(x + j + 1) = t;
            }
        }
    }
}

int main() {
    int a[N];

    input(a, N);
    sort(a, N);
    output(a, N);

    return 0;
}