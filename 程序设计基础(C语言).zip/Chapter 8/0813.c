#include <stdio.h>
#include <math.h>

double integrate_sin(double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    int i;
    for (i = 0; i < n; i++) {
        sum += sin(a + i * h) * h;
    }
    return sum;
}

double integrate_cos(double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    int i;
    for (i = 0; i < n; i++) {
        sum += cos(a + i * h) * h;
    }
    return sum;
}

double integrate_exp(double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    int i;
    for (i = 0; i < n; i++) {
        sum += exp(a + i * h) * h;
    }
    return sum;
}

int main() {
    double a, b;
    int n = 1000;
    scanf("%lf,%lf", &a, &b);

    printf("%.2f,%.2f,%.2f\n", integrate_sin(a, b, n), integrate_cos(a, b, n), integrate_exp(a, b, n));

    return 0;
}