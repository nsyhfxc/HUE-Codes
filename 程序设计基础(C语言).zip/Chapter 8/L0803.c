#include <stdio.h>

void swap(int *p1, int *p2) {
    int t;
    if (*p1 < *p2) {
        t = *p1;
        *p1 = *p2;
        *p2 = t;
    }
}

int main() {
    int a, b;
    int *max, *min;

    scanf("%d,%d", &a, &b);

    max = &a;
    min = &b;

    swap(max, min);

    printf("max=%d,min=%d\n", *max, *min);

    return 0;
}