#include <stdio.h>

int main() {
  double num1, num2, sum;
  scanf("%lf %lf", &num1, &num2);
  sum = num1 + num2;
  printf("%.6f+%.6f=%.4f\n", num1, num2, sum);

  return 0;
}