#include <stdio.h>

int main() {
  int dividend, divisor, quotient, remainder;
  scanf("%d,%d", &dividend, &divisor);
  quotient = dividend / divisor;
  remainder = dividend % divisor;
  printf("%d,%d\n", quotient, remainder);
  return 0;
}