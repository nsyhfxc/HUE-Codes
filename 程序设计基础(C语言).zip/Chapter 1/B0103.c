#include <stdio.h>

int main() {
  double a, square;
  scanf("%lf", &a);
  square = a * a;
  printf("%.3f\n", square);
  return 0;
}