#include <stdio.h>
int main()
{
  printf("Work hard and improve daily.\n");
  printf("Study hard and make progress every day!\n");
  return 0;
}