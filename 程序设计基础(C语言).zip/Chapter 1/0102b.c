#include <stdio.h>
int main() {
  printf("\"Doing is better than saying?\", he asked.\n");
  return 0;
}