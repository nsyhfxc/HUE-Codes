#include <stdio.h>

int main() {
  int num1, num2, sum;
  scanf("%d", &num1);
  scanf("%d", &num2);

  sum = num1 + num2;

  printf("%d+", num1);
  if (num2 < 0) {
    printf("(%d)=%d\n", num2, sum);
  } else {
    printf("%d=%d\n", num2, sum);
  }

  return 0;
}