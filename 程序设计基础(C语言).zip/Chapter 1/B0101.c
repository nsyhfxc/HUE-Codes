#include <stdio.h>
int main() {
  printf("An idle youth, a needy age.\nA good medicine tastes bitter.\n");
  return 0;
}