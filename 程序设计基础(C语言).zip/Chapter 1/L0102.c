#include <stdio.h>

int main() {
  printf("sum is 66666\n");
  return 0;
}