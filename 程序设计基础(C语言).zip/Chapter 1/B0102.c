#include <stdio.h>

int main() {
  printf("\"C:\\windows\" is the windows system folder.\n");
  return 0;
}