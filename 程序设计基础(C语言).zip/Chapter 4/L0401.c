#include <stdio.h>
#include <math.h>

int main() {
    double a, b, c;
    double delta, x1, x2;
    if (scanf("%lf,%lf,%lf", &a, &b, &c) != 3) {
        return 1;
    }

    delta = b * b - 4 * a * c;

    if (delta < 0) {
        printf("No real roots.\n");
    } else {
        x1 = (-b + sqrt(delta)) / (2 * a);
        x2 = (-b - sqrt(delta)) / (2 * a);
        printf("x1=%.2f,x2=%.2f\n", x1, x2);
    }

    return 0;
}