#include <stdio.h>
#include <math.h>

int main() {
    double a, b, c;
    double delta, real, imag, x1, x2;

    scanf("%lf,%lf,%lf", &a, &b, &c);

    delta = b * b - 4 * a * c;

    if (delta > 0) {
        x1 = (-b + sqrt(delta)) / (2 * a);
        x2 = (-b - sqrt(delta)) / (2 * a);
        printf("x1=%.2f,x2=%.2f\n", x1, x2);
    } else if (delta == 0) {
        x1 = -b / (2 * a);
        printf("x1=x2=%.2f\n", x1);
    } else {
        real = -b / (2 * a);
        imag = sqrt(-delta) / (2 * a);
        printf("x1=%.2f+%.2fi,x2=%.2f-%.2fi\n", real, imag, real, imag);
    }

    return 0;
}