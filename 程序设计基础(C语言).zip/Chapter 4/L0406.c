#include <stdio.h>

int main() {
    char grade;
    scanf(" %c", &grade);

    switch (grade) {
        case 'A':
        case 'a':
            printf("Your score:85~100\n");
            break;
        case 'B':
        case 'b':
            printf("Your score:70~84\n");
            break;
        case 'C':
        case 'c':
            printf("Your score:60~69\n");
            break;
        case 'D':
        case 'd':
            printf("Your score:<60\n");
            break;
        default:
            printf("Invalid grade input.\n");
            break;
    }
    return 0;
}