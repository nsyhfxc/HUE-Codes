#include <stdio.h>

int main() {
    float a, b, c, temp;
    scanf("%f,%f,%f", &a, &b, &c);

    // 排序：从大到小
    if (a < b) { temp = a; a = b; b = temp; }
    if (a < c) { temp = a; a = c; c = temp; }
    if (b < c) { temp = b; b = c; c = temp; }

    printf("%.1f,%.1f,%.1f\n", a, b, c);
    return 0;
}