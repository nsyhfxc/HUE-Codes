#include <stdio.h>
#include <math.h>

int main() {
    float x, y, z;
    scanf("%f,%f", &x, &y);

    if (x > 0 && y > 0) {
        z = sqrtf(x + y);
    } else if (x > 0 && y <= 0) {
        z = sinf(x) + cosf(y);
    } else if (x <= 0 && y > 0) {
        z = expf(x - y);
    } else {
        z = fabsf(powf(x, y));
    }

    printf("%.2f\n", z);
    return 0;
}