#include <stdio.h>

int main() {
    double profit, bonus = 0.0;
    scanf("%lf", &profit);

    double remain = profit;

    if (remain > 100) {
        bonus += (remain - 100) * 0.01;
        remain = 100;
    }
    if (remain > 60) {
        bonus += (remain - 60) * 0.015;
        remain = 60;
    }
    if (remain > 40) {
        bonus += (remain - 40) * 0.03;
        remain = 40;
    }
    if (remain > 20) {
        bonus += (remain - 20) * 0.05;
        remain = 20;
    }
    if (remain > 10) {
        bonus += (remain - 10) * 0.075;
        remain = 10;
    }
    if (remain > 0) {
        bonus += remain * 0.10;
    }

    printf("profit=%.4f,bonus=%.4f\n", profit, bonus);
    return 0;
}