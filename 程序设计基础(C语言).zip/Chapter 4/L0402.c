#include <stdio.h>

int main() {
    float a, b, temp;
    scanf("%f,%f", &a, &b);
    if (a < b) {
        temp = a;
        a = b;
        b = temp;
    }
    printf("%.1f,%.1f\n", a, b);
    return 0;
}