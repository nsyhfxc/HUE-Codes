#include <stdio.h>

int main() {
    int num, digits[5], count = 0, temp, i;
    scanf("%d", &num);

    temp = num;

    while (temp > 0 && count < 5) {
        digits[count++] = temp % 10;
        temp /= 10;
    }

    if (num == 0) {
        count = 1;
        digits[0] = 0;
    }

    printf("num=%d,", count);

    printf("natural order:");
    for (i = count - 1; i >= 0; i--) {
        printf("%2d", digits[i]);
    }

    printf(",reverse order:");
    for (i = 0; i < count; i++) {
        printf("%2d", digits[i]);
    }
    printf("\n");

    return 0;
}