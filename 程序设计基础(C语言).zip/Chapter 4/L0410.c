#include <stdio.h>

int main() {
    double price_per_ton_km, weight, distance, discount = 0.0, freight;
    scanf("%lf,%lf,%lf", &price_per_ton_km, &weight, &distance);

    if (distance < 250)
        discount = 0.0;
    else if (distance < 500)
        discount = 0.02;
    else if (distance < 1000)
        discount = 0.05;
    else if (distance < 2000)
        discount = 0.08;
    else if (distance < 3000)
        discount = 0.10;
    else
        discount = 0.15;

    freight = price_per_ton_km * weight * distance * (1 - discount);
    printf("freight=%10.2f\n", freight);

    return 0;
}