#include <stdio.h>
int main() {
    int a, b, result;
    char op;
    scanf("%d,%d,%c", &a, &b, &op);

    switch(op) {
        case '+':
            result = a + b;
            printf("%d+%d=%d\n", a, b, result);
            break;
        case '-':
            result = a - b;
            printf("%d-%d=%d\n", a, b, result);
            break;
        case '*':
            result = a * b;
            printf("%d*%d=%d\n", a, b, result);
            break;
        case '/':
            if (b != 0) {
                result = a / b;
                printf("%d/%d=%d\n", a, b, result);
            } else {
                printf("\n");
            }
            break;
        default:
            break;
    }

    return 0;
}