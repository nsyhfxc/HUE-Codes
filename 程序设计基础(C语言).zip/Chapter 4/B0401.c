#include <stdio.h>
#include <math.h>

int main() {
    double x, y, z;
    scanf("%lf %lf", &x, &y);

    if (x > 2 && y >= 2) {
        z = 2 * exp(3 * x - y);
    } else if (x > 2 && y < 2) {
        z = cbrt(x + y * y);
    } else if (x <= 2 && y > 5) {
        z = pow(3 * x, y / 9.0);
    } else {
        z = x + fabs(y - 20);
    }

    printf("z=%.3f\n", z);
    return 0;
}