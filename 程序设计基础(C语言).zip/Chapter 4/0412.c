#include <stdio.h>
#include <math.h>

int main() {
    double x, y;
    double towers[4][2] = { {2,2}, {-2,2}, {-2,-2}, {2,-2} };
    double radius = 1.0;
    int i, inside = 0;
    scanf("%lf,%lf", &x, &y);

    for (i = 0; i < 4; i++) {
        double dx = x - towers[i][0];
        double dy = y - towers[i][1];
        if (dx*dx + dy*dy <= radius*radius) {
            inside = 1;
            break;
        }
    }

    if (inside)
        printf("h=10m\n");
    else
        printf("h=0m\n");

    return 0;
}