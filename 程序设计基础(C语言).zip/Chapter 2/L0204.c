#include <stdio.h>
int main() {
  char chars[5];
  int i;
  for (i = 0; i < 5; i++) {
    scanf(" %c", &chars[i]);
  }
  for (i = 4; i >= 0; i--) {
    printf("%c", chars[i]);
  }
  printf("\n");
  return 0;
}