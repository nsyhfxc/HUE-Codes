#include <stdio.h>
#include <math.h>

int main() {
  int n;
  double a_capability, b_capability, ratio;
  scanf("%d", &n);
  a_capability = pow(1.01, 365.0 * n);
  b_capability = pow(0.99, 365.0 * n);
  ratio = a_capability / b_capability;
  printf("%.3f\n", ratio);
  return 0;
}