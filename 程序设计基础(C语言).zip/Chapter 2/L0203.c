#include <stdio.h>

int main() {
  double num;
  scanf("%lf", &num);
  float num1 = (float)num;
  printf("a=%.6f\n", num1);
  return 0;
}