#include <stdio.h>

int main() {
  int total_heads, total_legs;
  int chickens, rabbits;
  scanf("%d %d", &total_heads, &total_legs);
  rabbits = (total_legs - 2 * total_heads) / 2;
  chickens = total_heads - rabbits;
  if (rabbits >= 0 && chickens >= 0 && (total_legs % 2 == 0)) {
    printf("chicken=%d,rabbits=%d\n", chickens, rabbits);
  } else {
    printf("无法计算出符合条件的鸡和兔的数量。\n");
  }

  return 0;
}