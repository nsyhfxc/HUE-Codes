#include <stdio.h>

int main() {
  double train_a_length = 150.0;
  double train_b_length = 200.0;
  double train_a_speed = 15.0;
  double train_b_speed;
  scanf("%lf",&train_b_speed);
  double total_distance = train_a_length + train_b_length;
  double relative_speed = train_a_speed + train_b_speed;
  double time = total_distance / relative_speed;

  printf("%.2f\n", time);

  return 0;
}