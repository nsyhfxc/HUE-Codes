#include <stdio.h>

int main() {
  int n;
  scanf("%d", &n);
  float Guo_Power = 1.0;
  float Wang_Power = 1.0;
  int Total_Days = n * 365;
  int i = 0;
  for (i = 0; i < Total_Days; i++) {
    Guo_Power *= 1.001;
  }
  for (i = 0; i < Total_Days; i++) {
    int Cycle = i % 5;
    if (Cycle < 3) {
      Wang_Power *= 1.002;
    } else {
      Wang_Power *= 0.999;
    }
  }
  printf("%.1f\n", Guo_Power);
  printf("%.1f\n", Wang_Power);
  return 0;
}