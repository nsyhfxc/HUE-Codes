#include <stdio.h>

int main() {
  int total_heads = 16;
  int total_legs = 40;
  int chickens, rabbits;
  for (rabbits = 0; rabbits <= total_heads; rabbits++) {
    chickens = total_heads - rabbits;
    if (2 * chickens + 4 * rabbits == total_legs) {
        printf("chicken=%d,rabbits=%d\n", chickens, rabbits);
        break;
    }
  }

  return 0;
}