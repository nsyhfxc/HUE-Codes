#include <stdio.h>
#include <string.h>

struct Student {
    int num;          // 学号
    char name[20];    // 姓名
    int cscore;       // C语言成绩
};

int main() {
    struct Student s[100];
    int count = 0;
    FILE *fp = fopen("1006R.txt", "rb");
    if (!fp) {
        printf("File open error!\n");
        return 1;
    }

    // 读取文件
    while (fread(&s[count], sizeof(struct Student), 1, fp) == 1) {
        count++;
    }
    fclose(fp);

    printf("num=%d\n", count);

    // 输入学号
    int search_num;
    scanf("%d", &search_num);

    // 查找学生
    int i = 0;
    int found = 0;
    for (i = 0; i < count; i++) {
        if (s[i].num == search_num) {
            printf("%d,%s,%d\n", s[i].num, s[i].name, s[i].cscore);
            found = 1;
            break;
        }
    }

    if (!found) printf("Not found!\n");

    return 0;
}
