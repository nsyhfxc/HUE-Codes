#include <stdio.h>
#include <stdlib.h>

void readFile(char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        printf("Cannot open file!\n");
        return;
    }
    char line[200];
    while (fgets(line, sizeof(line), fp))
        printf("%s", line);
    fclose(fp);
}

void appendFile(char *filename, char *t) {
    FILE *fp = fopen(filename, "a"); // 追加模式
    if (!fp) {
        printf("Cannot open file!\n");
        return;
    }
    fprintf(fp, "%s\n", t);
    fclose(fp);
}

int main() {
    char filename[20] = "1008R.txt";
    char t[120];
    readFile(filename); // 读取文件
    printf("Appeding...\n");
    gets(t);
    appendFile(filename, t); // 将t追加到文件末尾
    readFile(filename);
    return 0;
}
