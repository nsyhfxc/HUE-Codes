#include <stdio.h>

struct Student {
    int num;          // 学号
    char name[20];    // 姓名
    int cscore;       // C语言成绩
};

int main() {
    struct Student s;
    FILE *fp = fopen("1007R.txt", "rb");
    if (!fp) {
        printf("File open error!\n");
        return 1;
    }

    int n;
    scanf("%d", &n);

    // （1）第 n 个学生
    fseek(fp, (n - 1) * sizeof(struct Student), SEEK_SET);
    fread(&s, sizeof(struct Student), 1, fp);
    printf("n=%d:%d,%s,%d\n", n, s.num, s.name, s.cscore);

    // （2）第 n+2 个学生
    fseek(fp, (n + 1) * sizeof(struct Student), SEEK_SET);
    if (fread(&s, sizeof(struct Student), 1, fp) == 1)
        printf("n=%d:%d,%s,%d\n", n + 2, s.num, s.name, s.cscore);

    // （3）倒数第 n 个学生
    fseek(fp, 0, SEEK_END);
    long total = ftell(fp) / sizeof(struct Student);
    fseek(fp, (total - n) * sizeof(struct Student), SEEK_SET);
    fread(&s, sizeof(struct Student), 1, fp);
    printf("%d,%s,%d\n", s.num, s.name, s.cscore);

    fclose(fp);
    return 0;
}
