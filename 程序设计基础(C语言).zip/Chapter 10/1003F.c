#include <stdio.h>
#include <string.h>

#define N 5
#define LEN 100

int main() {
    char str[N][LEN], temp[LEN];
    FILE *fp;
    int i, j;
    for (i = 0; i < N; i++) {
        fgets(str[i], LEN, stdin); // 读入一行（包括回车）
        str[i][strcspn(str[i], "\n")] = '\0'; // 去掉回车符
    }

    // 排序（字母从大到小）
    for (i = 0; i < N - 1; i++) {
        for (j = i + 1; j < N; j++) {
            if (strcmp(str[i], str[j]) < 0) {
                strcpy(temp, str[i]);
                strcpy(str[i], str[j]);
                strcpy(str[j], temp);
            }
        }
    }

    // 写入文件
    fp = fopen("1003F.dat", "w");
    if (!fp) {
        return 1;
    }

    for (i = 0; i < N; i++) {
        fputs(str[i], fp);
        fputs("\n", fp); // 每个字符串后加回车
    }

    fclose(fp);
    return 0;
}
