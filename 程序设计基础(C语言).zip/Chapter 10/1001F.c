#include <stdio.h>

int main() {
    FILE *fp;
    char ch;
    fp = fopen("1001F.dat", "w");
    while ((ch = getchar()) != '#') {
        fputc(ch, fp);
    }
    fclose(fp);
    return 0;
}