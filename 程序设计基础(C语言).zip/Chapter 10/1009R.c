#include <stdio.h>
#include <string.h>

struct Student {
    int num;          // 学号
    char name[20];    // 姓名
    int cscore;       // C语言成绩
};

int findStu(char *filename, int stunum) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("File open error!\n");
        return 0;
    }
    struct Student s;
    while (fread(&s, sizeof(s), 1, fp) == 1) {
        if (s.num == stunum) {
            printf("%d,%s,%d\n", s.num, s.name, s.cscore);
            fclose(fp);
            return 1; // 找到
        }
    }
    fclose(fp);
    printf("Not found!\n");
    return 0; // 没找到
}

void findAndChangeScore(char *filename, int stunum, int score) {
    FILE *fp = fopen(filename, "r+b"); // 读写二进制模式
    if (!fp) {
        printf("File open error!\n");
        return;
    }
    struct Student s;
    while (fread(&s, sizeof(s), 1, fp) == 1) {
        if (s.num == stunum) {
            s.cscore = score;
            fseek(fp, -sizeof(s), SEEK_CUR); // 回到该记录开头
            fwrite(&s, sizeof(s), 1, fp);
            break;
        }
    }
    fclose(fp);
}

int main() {
    int stunum;
    int score;
    char filename[] = "1009R.txt";
    scanf("%d", &stunum);
    if (!findStu(filename, stunum)) return 0; // 找不到直接结束
    scanf("%d", &score);
    findAndChangeScore(filename, stunum, score);
    findStu(filename, stunum);
    return 0;
}
