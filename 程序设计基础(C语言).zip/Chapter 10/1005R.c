#include <stdio.h>

struct Student {
    char name[20];
    int num;
    int age;
    char addr[20];
};

int main() {
    struct Student s[3];
    FILE *fp = fopen("1005R.txt", "rb");
    if (!fp) return 1;
    int i = 0;
    for (i = 0; i < 3; i++)
        fscanf(fp, "%s %d %d %s", s[i].name, &s[i].num, &s[i].age, s[i].addr);
    
    fclose(fp);

    for (i = 0; i < 3; i++)
        printf("%20s%6d%6d%20s\n", s[i].name, s[i].num, s[i].age, s[i].addr);

    return 0;
}
