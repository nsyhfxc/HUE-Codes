#include <stdio.h>

int main() {
    FILE *fp;
    char str[81];
    fp = fopen("1004R.txt", "r");
    if (fp == NULL) {
        printf("Error opening file.\n");
        return 1;
    }
    while (fgets(str, 81, fp) != NULL) {
        printf("%s", str);
    }
    fclose(fp);
    return 0;
}