#include <stdio.h>
#include <string.h>
int i,j;
// 定义学生结构体
struct Student {
    int num;
    char name[20];
    float score;
};

int main() {
    struct Student students[5];

    for (i = 0; i < 5; i++) {
        scanf("%d %s %f", &students[i].num, students[i].name, &students[i].score);
    }

    // 使用选择法排序，按成绩从高到低
    for (i = 0; i < 4; i++) {
        int max_index = i;
        for (j = i + 1; j < 5; j++) {
            if (students[j].score > students[max_index].score) {
                max_index = j;
            }
        }
        // 交换
        if (max_index != i) {
            struct Student temp = students[i];
            students[i] = students[max_index];
            students[max_index] = temp;
        }
    }

    for (i = 0; i < 5; i++) {
        printf("%6d,%15s,%6.2f\n", students[i].num, students[i].name, students[i].score);
    }

    return 0;
}