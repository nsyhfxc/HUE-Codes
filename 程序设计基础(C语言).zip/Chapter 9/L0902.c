#include <stdio.h>

struct Student {
    long int num;
    char name[20];
    float score;
};

int main() {
    struct Student s1, s2;

    scanf("%ld %s %f", &s1.num, s1.name, &s1.score);
    scanf("%ld %s %f", &s2.num, s2.name, &s2.score);

    printf("The higher score is:\n");
    if (s1.score > s2.score) {
        printf("%ld %s %6.2f\n", s1.num, s1.name, s1.score);
    } else if (s2.score > s1.score) {
        printf("%ld %s %6.2f\n", s2.num, s2.name, s2.score);
    } else {
        printf("%ld %s %6.2f\n", s1.num, s1.name, s1.score);
        printf("%ld %s %6.2f\n", s2.num, s2.name, s2.score);
    }

    return 0;
}