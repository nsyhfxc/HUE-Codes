#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    char name[20];
    float score;
    struct Student *next;
};

struct Student *createList(int n) {
    struct Student *head = NULL;
    struct Student *p, *rear;
    int i;

    if (n <= 0) {
        return NULL;
    }

    rear = head = (struct Student *)malloc(sizeof(struct Student));
    if (head == NULL) {
        return NULL;
    }
    scanf("%d %s %f", &head->num, head->name, &head->score);
    head->next = NULL;

    for (i = 1; i < n; i++) {
        p = (struct Student *)malloc(sizeof(struct Student));
        if (p == NULL) {
            return head;
        }
        scanf("%d %s %f", &p->num, p->name, &p->score);
        p->next = NULL;
        rear->next = p;
        rear = p;
    }
    return head;
}

void showList(struct Student *head) {
    struct Student *p = head;
    int i = 1;
    if (p == NULL) {
        printf("Empty!\n");
        return;
    }
    while (p != NULL) {
        printf("%d:%8d%12s%6.1f\n", i, p->num, p->name, p->score);
        p = p->next;
        i++;
    }
}

int main()
{
    struct Student *h;
    int n;
    scanf("%d",&n);
    h=createList(n);
    showList(h);
    return 0;
}