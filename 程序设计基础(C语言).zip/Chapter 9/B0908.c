#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 定义学生结构体
struct Student {
    int id;
    char name[20];
    float score;
    struct Student *next;
};

// 函数声明
struct Student* createList(int n);
void showList(struct Student *head);

// 创建有序单链表
struct Student* createList(int n) {
    // 如果n为0，返回空链表
    if (n == 0) {
        return NULL;
    }

    struct Student *head = NULL;
    int i;
    for (i = 0; i < n; i++) {
        // 创建新节点
        struct Student *newNode = (struct Student *)malloc(sizeof(struct Student));
        if (newNode == NULL) {
            // 内存分配失败处理
            return NULL;
        }
        scanf("%d %s %f", &newNode->id, newNode->name, &newNode->score);
        newNode->next = NULL;

        // 有序插入
        // 如果链表为空，或者新节点的成绩大于头节点的成绩，则新节点作为头节点
        if (head == NULL || newNode->score > head->score) {
            newNode->next = head;
            head = newNode;
        } else {
            // 遍历链表找到插入位置
            struct Student *current = head;
            while (current->next != NULL && current->next->score >= newNode->score) {
                current = current->next;
            }
            // 插入新节点
            newNode->next = current->next;
            current->next = newNode;
        }
    }
    return head;
}

// 遍历并显示链表
void showList(struct Student *head) {
    // 如果链表为空
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }

    // 遍历链表并打印信息
    struct Student *current = head;
    int count = 1;
    while (current != NULL) {
        printf("%d:%8d%12s%6.1f\n", count, current->id, current->name, current->score);
        current = current->next;
        count++;
    }
}

// 主函数
int main() {
    struct Student *head;
    int n;

    scanf("%d", &n);
    head = createList(n);
    showList(head);

    return 0;
}