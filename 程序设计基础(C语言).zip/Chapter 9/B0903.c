#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    float score;
    struct Student *next;
};

// 有序链表创建（升序插入）
struct Student *creatSortedList() {
    struct Student *head = NULL, *p, *prev, *curr;
    int num;
    float score;

    while (1) {
        scanf("%d,%f", &num, &score);
        if (num == 0 && score == 0) break;

        p = (struct Student *)malloc(sizeof(struct Student));
        p->num = num;
        p->score = score;
        p->next = NULL;

        // 按学号升序插入
        if (head == NULL || num < head->num) {
            p->next = head;
            head = p;
        } else {
            prev = NULL;
            curr = head;
            while (curr != NULL && num > curr->num) {
                prev = curr;
                curr = curr->next;
            }
            prev->next = p;
            p->next = curr;
        }
    }
    return head;
}

// 无序链表创建（尾插）
struct Student *creat() {
    struct Student *head = NULL, *tail = NULL, *p;
    int num;
    float score;

    while (1) {
        scanf("%d,%f", &num, &score);
        if (num == 0 && score == 0) break;

        p = (struct Student *)malloc(sizeof(struct Student));
        p->num = num;
        p->score = score;
        p->next = NULL;

        if (head == NULL) {
            head = tail = p;
        } else {
            tail->next = p;
            tail = p;
        }
    }
    return head;
}

// 输出链表
void print(struct Student *head) {
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }
    printf("Scores are:\n");
    struct Student *p = head;
    while (p != NULL) {
        printf("num:%d,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

// 合并两个链表到升序 pt1
struct Student *combine(struct Student *p1, struct Student *p2) {
    struct Student *p, *prev, *curr;

    while (p2 != NULL) {
        // 取出 p2 的一个节点
        p = p2;
        p2 = p2->next;
        p->next = NULL;

        // 插入到 p1 中保持升序
        if (p1 == NULL || p->num < p1->num) {
            p->next = p1;
            p1 = p;
        } else {
            prev = NULL;
            curr = p1;
            while (curr != NULL && p->num > curr->num) {
                prev = curr;
                curr = curr->next;
            }
            prev->next = p;
            p->next = curr;
        }
    }
    return p1;
}

int main() {
    struct Student *creat();
    struct Student *creatSortedList();
    struct Student *combine(struct Student *p1, struct Student *p2);
    void print(struct Student *head);

    struct Student *pt1, *pt2;
    printf("Sorted List:\n");
    pt1 = creatSortedList();
    print(pt1);

    printf("\nList:\n");
    pt2 = creat();
    print(pt2);

    printf("\nCombining...\n");
    pt1 = combine(pt1, pt2);
    print(pt1);

    return 0;
}
