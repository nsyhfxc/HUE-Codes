#include <stdio.h>

// 定义学生结构体
struct Student {
    int num;
    char name[20];
    float score1, score2, score3;
    float average;
};

int main() {
    struct Student students[5];
    int i; // 循环变量
    int maxIndex = 0; // 记录平均成绩最高的学生的索引
    for (i = 0; i < 5; i++) {
        scanf("%d %s %f %f %f", &students[i].num, students[i].name, &students[i].score1, &students[i].score2, &students[i].score3);
        students[i].average = (students[i].score1 + students[i].score2 + students[i].score3) / 3.0;
    }

    // 找到平均成绩最高的学生
    for (i = 1; i < 5; i++) {
        if (students[i].average > students[maxIndex].average) {
            maxIndex = i;
        }
    }
    printf("The highest score:\n");
    printf("%d,%s,%.2f,%.2f,%.2f,%.2f\n",
           students[maxIndex].num,
           students[maxIndex].name,
           students[maxIndex].score1,
           students[maxIndex].score2,
           students[maxIndex].score3,
           students[maxIndex].average);

    return 0;
}