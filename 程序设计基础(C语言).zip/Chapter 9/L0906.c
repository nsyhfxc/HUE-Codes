#include <stdio.h>
int i;
// 定义学生结构体
struct Student {
    int num;
    char name[20];
    float score;
};

int main() {
    struct Student students[3];
    struct Student *p; // 定义一个指向结构体数组的指针

    for (i = 0; i < 3; i++) {
        scanf("%d %s %f", &students[i].num, students[i].name, &students[i].score);
    }

    p = students; // 指针p指向数组的第一个元素
    for (i = 0; i < 3; i++) {
        printf("%d,%s,%.2f\n", (p + i)->num, (p + i)->name, (p + i)->score);
    }

    return 0;
}