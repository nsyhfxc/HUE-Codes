#include <stdio.h>

int main() {
    char *color[5] = {"red", "yellow", "blue", "white", "black"};
    int i, j, k;
    int count = 0;

    for (i = 0; i < 5; i++) {
        for (j = 0; j < 5; j++) {
            if (i == j) {
                continue;
            }
            for (k = 0; k < 5; k++) {
                if (i == k || j == k) {
                    continue;
                }
                count++;
                printf("%-4d%-10s%-10s%-10s\n", count, color[i], color[j], color[k]);
            }
        }
    }
    return 0;
}