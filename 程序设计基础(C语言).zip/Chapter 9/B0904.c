#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    float score;
    struct Student *next;
};

// 创建无序链表（尾插）
struct Student *creat() {
    struct Student *head = NULL, *tail = NULL, *p;
    int num;
    float score;

    while (1) {
        scanf("%d,%f", &num, &score);
        if (num == 0 && score == 0) break;

        p = (struct Student *)malloc(sizeof(struct Student));
        p->num = num;
        p->score = score;
        p->next = NULL;

        if (head == NULL) {
            head = tail = p;
        } else {
            tail->next = p;
            tail = p;
        }
    }
    return head;
}

// 输出链表
void print(struct Student *head) {
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }
    printf("Scores are:\n");
    struct Student *p = head;
    while (p != NULL) {
        printf("num:%d,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

// 删除：从 p1 中删除 p2 中的学号
struct Student *delNode(struct Student *p1, struct Student *p2) {
    struct Student *head = p1;
    struct Student *q = p2;

    while (q != NULL) {
        int target = q->num;
        struct Student *p = head, *prev = NULL;
        int found = 0;

        while (p != NULL) {
            if (p->num == target) { // 找到要删除的结点
                if (prev == NULL) {
                    head = p->next; // 删除头结点
                } else {
                    prev->next = p->next;
                }
                free(p);
                printf("num:%d deleted!\n", target);
                found = 1;
                break; // 只删一次
            }
            prev = p;
            p = p->next;
        }

        if (!found) {
            printf("num:%d Not found!\n", target);
        }
        q = q->next;
    }
    return head;
}

int main() {
    struct Student *creat();
    struct Student *delNode(struct Student *p1, struct Student *p2);
    void print(struct Student *head);

    struct Student *pt1, *pt2;
    printf("List A:\n");
    pt1 = creat();
    print(pt1);

    printf("\nList B:\n");
    pt2 = creat();
    print(pt2);

    printf("\nDeleting...\n");
    pt1 = delNode(pt1, pt2);
    print(pt1);

    return 0;
}
