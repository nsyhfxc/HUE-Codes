#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    float score;
    struct Student *next;
};

struct Student *creat() {
    struct Student *head, *p1, *p2;
    head = NULL;
    int n = 0;
    p1 = p2 = (struct Student *)malloc(sizeof(struct Student));
    if (p1 == NULL) {
        return NULL;
    }
    scanf("%d,%f", &p1->num, &p1->score);
    while (p1->num != 0) {
        n++;
        if (n == 1) {
            head = p1;
        } else {
            p2->next = p1;
        }
        p2 = p1;
        p1 = (struct Student *)malloc(sizeof(struct Student));
        if (p1 == NULL) {
            return head;
        }
        scanf("%d,%f", &p1->num, &p1->score);
    }
    p2->next = NULL;
    free(p1);
    return head;
}

void print(struct Student *head) {
    struct Student *p;
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }
    printf("Scores are:\n");
    p = head;
    while (p != NULL) {
        printf("num:%d,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

void modify(struct Student *head) {
    struct Student *p;
    int n;
    float new_score;
    int found = 0;

    printf("Please input the number you want to modify:\n");
    scanf("%d", &n);
    p = head;
    while (p != NULL) {
        if (p->num == n) {
            printf("Please input the new score:\n");
            scanf("%f", &new_score);
            p->score = new_score;
            found = 1;
            break;
        }
        p = p->next;
    }
    if (!found) {
        printf("Not found!\n");
    }
}

int main() {
    struct Student *creat();
    void print(struct Student *head);
    void modify(struct Student *head);

    struct Student *pt;
    pt = creat();
    print(pt);
    if (pt != NULL) {
        modify(pt);
        print(pt);
    }

    return 0;
}