#include <stdio.h>

// 定义学生结构体，包含学号、分数和指向下一个节点的指针
struct Student {
    int num;
    float score;
    struct Student *next;
};

int main() {
    // 声明三个结构体变量a, b, c，以及头指针head和遍历指针p
    struct Student a, b, c, *head, *p;

    // 为a, b, c赋值
    a.num = 10101;
    a.score = 89.5;

    b.num = 10103;
    b.score = 90;

    c.num = 10107;
    c.score = 85;

    // 建立链表
    head = &a;       // 头指针指向第一个节点
    a.next = &b;     // 第一个节点指向第二个节点
    b.next = &c;     // 第二个节点指向第三个节点
    c.next = NULL;   // 第三个节点的next指针为空，表示链表结束

    // 遍历并输出链表
    p = head;        // 遍历指针p指向链表头
    do {
        printf("%d %5.1f\n", p->num, p->score);
        p = p->next;  // 移动到下一个节点
    } while (p != NULL); // 当p不为空时继续循环

    return 0;
}