#include <stdio.h>

// 定义学生结构体
struct Student {
    int num;
    char name[20];
    float score;
};

int main() {
    struct Student stu;
    struct Student *p; // 定义一个结构体指针

    p = &stu;

    scanf("%d %s %f", &p->num, p->name, &p->score);

    printf("%d,%s,%.2f\n", p->num, p->name, p->score);

    return 0;
}