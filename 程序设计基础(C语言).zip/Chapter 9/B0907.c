#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
    int num;
    char name[20];
    float score;
    struct Student *next;
};

struct Student *createList(int n) {
    struct Student *head = NULL;
    struct Student *p;
    int i;

    if (n <= 0) {
        return NULL;
    }

    for (i = 0; i < n; i++) {
        p = (struct Student *)malloc(sizeof(struct Student));
        if (p == NULL) {
            return head;
        }
        scanf("%d %s %f", &p->num, p->name, &p->score);
        p->next = head;
        head = p;
    }
    return head;
}

void showList(struct Student *head) {
    struct Student *p = head;
    int i = 1;
    if (p == NULL) {
        printf("Empty!\n");
        return;
    }
    while (p != NULL) {
        printf("%d:%8d%12s%6.1f\n", i, p->num, p->name, p->score);
        p = p->next;
        i++;
    }
}

struct Student *insertBeforNum(struct Student *head, int inum, struct Student *p) {
    struct Student *pre, *cur;
    pre = NULL;
    cur = head;

    while (cur != NULL && cur->num != inum) {
        pre = cur;
        cur = cur->next;
    }

    if (pre == NULL) {
        // Insert at the beginning or empty list
        if (cur == NULL) {
            head = p;
            p->next = NULL;
        } else {
            p->next = head;
            head = p;
        }
    } else {
        // Insert in the middle or end
        p->next = cur;
        pre->next = p;
    }

    return head;
}

int main() {
    struct Student *createList(int n);
    void showList(struct Student *head);
    struct Student *insertBeforNum(struct Student *head, int inum, struct Student *p);

    struct Student *head;
    struct Student *p;
    int n, inum;

    scanf("%d", &n);
    head = createList(n);
    showList(head);

    p = (struct Student *)malloc(sizeof(struct Student));
    if (p == NULL) {
        return 1;
    }
    printf("Please input the num,name,socre of new student:\n");
    scanf("%d %s %f", &p->num, p->name, &p->score);
    printf("Please input the NO. you want to insert before:\n");
    scanf("%d", &inum);
    head = insertBeforNum(head, inum, p);
    printf("After inserting...\n");
    showList(head);

    // Free the list (optional, but good practice)
    p = head;
    while (p != NULL) {
        struct Student *temp = p;
        p = p->next;
        free(temp);
    }

    return 0;
}