#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    char name[20];
    float score;
    struct Student *next;
};

struct Student *createList(int n) {
    struct Student *head = NULL;
    struct Student *p;
    int i;

    if (n <= 0) {
        return NULL;
    }

    for (i = 0; i < n; i++) {
        p = (struct Student *)malloc(sizeof(struct Student));
        if (p == NULL) {
            return head;
        }
        scanf("%d %s %f", &p->num, p->name, &p->score);
        p->next = head;
        head = p;
    }
    return head;
}

void showList(struct Student *head) {
    struct Student *p = head;
    int i = 1;
    if (p == NULL) {
        printf("Empty!\n");
        return;
    }
    while (p != NULL) {
        printf("%d:%8d%12s%6.1f\n", i, p->num, p->name, p->score);
        p = p->next;
        i++;
    }
}

int main() {
    struct Student *h;
    int n;
    scanf("%d", &n);
    h = createList(n);
    showList(h);
    return 0;
}