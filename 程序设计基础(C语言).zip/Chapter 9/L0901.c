#include <stdio.h>

struct Student {
    long int num;
    char name[20];
    char sex;
    char address[20];
};

int main() {
    struct Student student = {10101, "Li Lin", 'M', "123 Beijing Road"};

    printf("NO.:%ld\n", student.num);
    printf("name:%s\n", student.name);
    printf("sex:%c\n", student.sex);
    printf("address:%s\n", student.address);

    return 0;
}