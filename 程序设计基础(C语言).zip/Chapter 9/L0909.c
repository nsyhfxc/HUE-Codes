#include <stdio.h>
#include <stdlib.h>

// 定义学生结构体
struct Student {
    long num;
    float score;
    struct Student *next;
};

// 创建链表的函数
struct Student *creat() {
    struct Student *head, *p1, *p2;
    long num;
    float score;

    head = NULL;
    p1 = p2 = (struct Student *)malloc(sizeof(struct Student));
    scanf("%ld,%f", &num, &score);

    while (num != 0 || score != 0) {
        p1->num = num;
        p1->score = score;
        if (head == NULL) {
            head = p1;
        } else {
            p2->next = p1;
        }
        p2 = p1;
        p1 = (struct Student *)malloc(sizeof(struct Student));
        scanf("%ld,%f", &num, &score);
    }
    p2->next = NULL;
    free(p1); // 释放最后一个未使用的节点
    return head;
}

// 打印链表的函数
void print(struct Student *head) {
    struct Student *p;
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }

    p = head;
    printf("Scores are:\n");
    while (p != NULL) {
        printf("num:%ld,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

int main() {
    struct Student *pt;

    pt = creat();
    print(pt);

    return 0;
}