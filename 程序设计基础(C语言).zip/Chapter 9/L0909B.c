#include <stdio.h>
#include <stdlib.h>

// 定义学生结构体
struct Student {
    long num;
    float score;
    struct Student *next;
};

// 使用前插法创建链表的函数
struct Student *creat() {
    struct Student *head = NULL;
    struct Student *p;
    long num;
    float score;

    scanf("%ld,%f", &num, &score);
    while (num != 0 || score != 0) {
        p = (struct Student *)malloc(sizeof(struct Student));
        p->num = num;
        p->score = score;
        p->next = head;
        head = p;
        scanf("%ld,%f", &num, &score);
    }
    return head;
}

// 打印链表的函数
void print(struct Student *head) {
    struct Student *p;
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }

    p = head;
    printf("Scores are:\n");
    while (p != NULL) {
        printf("num:%ld,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

int main() {
    struct Student *pt;

    pt = creat();
    print(pt);

    return 0;
}