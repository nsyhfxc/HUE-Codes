#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    float score;
    struct Student *next;
};

// 创建链表
struct Student *creat() {
    struct Student *head = NULL, *tail = NULL, *p;
    int num;
    float score;

    while (1) {
        scanf("%d,%f", &num, &score);
        if (num == 0 && score == 0) break; // 输入 0,0 结束

        p = (struct Student *)malloc(sizeof(struct Student));
        p->num = num;
        p->score = score;
        p->next = NULL;

        if (head == NULL) {
            head = p;
            tail = p;
        } else {
            tail->next = p;
            tail = p;
        }
    }
    return head;
}

// 输出链表
void print(struct Student *head) {
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }
    printf("Scores are:\n");
    struct Student *p = head;
    while (p != NULL) {
        printf("num:%d,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

// 删除指定学号
struct Student *del(struct Student *head) {
    if (head == NULL) {
        printf("Empty! Not found!\n");
        return head;
    }

    printf("Please input the number you want to delete:\n");
    int num;
    scanf("%d", &num);

    struct Student *p = head, *prev = NULL;

    while (p != NULL && p->num != num) {
        prev = p;
        p = p->next;
    }

    if (p == NULL) {
        printf("Not found!\n");
        return head;
    }

    // 删除节点
    if (p == head) { // 删除头结点
        head = p->next;
    } else {
        prev->next = p->next;
    }
    free(p);

    printf("num:%d deleted!\n", num);
    return head;
}

int main() {
    struct Student *creat();
    void print(struct Student *head);
    struct Student *del(struct Student *head);

    struct Student *pt;
    pt = creat();
    print(pt);
    pt = del(pt);
    print(pt);

    return 0;
}
