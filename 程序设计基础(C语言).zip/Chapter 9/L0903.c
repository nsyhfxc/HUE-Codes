#include <stdio.h>
#include <string.h>

int main() {
    char name[20];
    int liCount = 0;
    int zhangCount = 0;
    int sunCount = 0;
    int i = 0;
    for (i = 0; i < 10; i++) {
        scanf("%s", name);
        if (strcmp(name, "Li") == 0) {
            liCount++;
        } else if (strcmp(name, "Zhang") == 0) {
            zhangCount++;
        } else{
            sunCount++;
        }
    }

    printf("\nResult:\n");
    printf("   Li:%d\n", liCount);
    printf("Zhang:%d\n", zhangCount);
    printf("  Sun:%d\n", sunCount);

    return 0;
}