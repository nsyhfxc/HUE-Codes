#include <stdio.h>
#include <stdlib.h>

struct Student {
    int num;
    float score;
    struct Student *next;
};

struct Student *creatSortedList() {
    struct Student *head, *p, *pre, *new_node;
    int num;
    float score;
    head = NULL;

    scanf("%d,%f", &num, &score);
    while (num != 0) {
        new_node = (struct Student *)malloc(sizeof(struct Student));
        if (new_node == NULL) {
            return head;
        }
        new_node->num = num;
        new_node->score = score;
        new_node->next = NULL;

        if (head == NULL) {
            head = new_node;
        } else {
            pre = NULL;
            p = head;
            while (p != NULL && p->num < new_node->num) {
                pre = p;
                p = p->next;
            }
            if (pre == NULL) {
                new_node->next = head;
                head = new_node;
            } else {
                new_node->next = p;
                pre->next = new_node;
            }
        }
        scanf("%d,%f", &num, &score);
    }
    return head;
}

void print(struct Student *head) {
    struct Student *p;
    if (head == NULL) {
        printf("Empty!\n");
        return;
    }
    printf("Scores are:\n");
    p = head;
    while (p != NULL) {
        printf("num:%d,score:%.2f\n", p->num, p->score);
        p = p->next;
    }
}

int main() {
    struct Student *creatSortedList();
    void print(struct Student *head);

    struct Student *pt;
    pt = creatSortedList();
    print(pt);

    return 0;
}