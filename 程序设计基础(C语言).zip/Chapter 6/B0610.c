#include <stdio.h>

int main() {
    char s1[100], s2[100];
    int i, j;

    gets(s1);

    j = 0;
    for (i = 0; s1[i] != '\0'; i++) {
        if ((s1[i] >= 'A' && s1[i] <= 'Z') || (s1[i] >= '0' && s1[i] <= '9')) {
            s2[j] = s1[i];
            j++;
        }
    }
    s2[j] = '\0';

    printf("%s\n", s2);

    return 0;
}