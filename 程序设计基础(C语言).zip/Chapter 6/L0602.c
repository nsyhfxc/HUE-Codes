#include <stdio.h>

int main() {
    int n;
    int a[40];
    int i;

    scanf("%d", &n);

    a[0] = 1;
    a[1] = 1;

    for (i = 2; i < n; i++) {
        a[i] = a[i - 1] + a[i - 2];
    }

    for (i = 0; i < n; i++) {
        printf("%12d", a[i]);
        if ((i + 1) % 5 == 0) {
            printf("\n");
        }
    }
    if (n % 5 != 0) {
        printf("\n");
    }

    return 0;
}