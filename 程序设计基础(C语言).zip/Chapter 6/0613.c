#include <stdio.h>

int main() {
    char s1[100], s2[50];
    int i, j;

    fgets(s1, sizeof(s1), stdin);
    fgets(s2, sizeof(s2), stdin);

    i = 0;
    while (s1[i] != '\n' && s1[i] != '\0') {
        i++;
    }

    j = 0;
    while (s2[j] != '\n' && s2[j] != '\0') {
        s1[i + j] = s2[j];
        j++;
    }
    s1[i + j] = '\0';

    printf("%s", s1);

    return 0;
}