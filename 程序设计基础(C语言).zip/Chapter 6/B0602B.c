#include <stdio.h>

int main() {
    int scores[10];
    int sum = 0;
    int i;
    double aver;

    for (i = 0; i < 10; i++) {
        scanf("%d", &scores[i]);
        sum += scores[i];
    }
    
    aver = (double)sum / 10;

    printf("sum=%d,aver=%.2lf\n", sum, aver);

    return 0;
}