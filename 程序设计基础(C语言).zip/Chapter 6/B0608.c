#include <stdio.h>

int main() {
    char s[12];
    int i, j;
    char temp;

    scanf("%s", s);

    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10 - i; j++) {
            if (s[j] < s[j + 1]) {
                temp = s[j];
                s[j] = s[j + 1];
                s[j + 1] = temp;
            }
        }
    }

    printf("%s\n", s);

    return 0;
}