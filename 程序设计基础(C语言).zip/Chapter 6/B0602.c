#include <stdio.h>

int main() {
    int a[6];
    int max, min;
    int ind1, ind2;
    int i;

    for (i = 0; i < 6; i++) {
        scanf("%d", &a[i]);
    }

    max = a[0];
    ind1 = 0;
    min = a[0];
    ind2 = 0;

    for (i = 1; i < 6; i++) {
        if (a[i] > max) {
            max = a[i];
            ind1 = i;
        }
        if (a[i] < min) {
            min = a[i];
            ind2 = i;
        }
    }

    printf("max=%d,ind1=%d;min=%d,ind2=%d\n", max, ind1, min, ind2);

    return 0;
}