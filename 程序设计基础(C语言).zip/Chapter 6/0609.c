#include <stdio.h>
#define N 15

int main() {
    int a[N] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 16, 19, 21};
    int x;
    int low = 0, high = N - 1, mid;

    scanf("%d", &x);

    while (low <= high) {
        mid = (low + high) / 2;
        if (a[mid] == x) {
            printf("num=%d\n", mid + 1);
            return 0;
        } else if (a[mid] < x) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    printf("No\n");
    return 0;
}