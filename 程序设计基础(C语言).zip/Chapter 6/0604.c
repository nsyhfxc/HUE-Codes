#include <stdio.h>

int main() {
    int a[6] = {1, 3, 5, 7, 9};
    int x;
    int i, j;

    scanf("%d", &x);

    for (i = 4; i >= 0; i--) {
        if (x < a[i]) {
            a[i+1] = a[i];
        } else {
            a[i+1] = x;
            break;
        }
    }
    if (i < 0) {
        a[0] = x;
    }
    
    for (j = 0; j < 6; j++) {
        printf("%5d", a[j]);
    }
    printf("\n");

    return 0;
}