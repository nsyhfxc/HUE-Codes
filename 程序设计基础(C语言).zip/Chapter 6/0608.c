#include <stdio.h>

int main() {
    int m[4][5];
    int i, j, k;
    int max_in_row, col_of_max;
    int found_saddle = 0;

    for (i = 0; i < 4; i++) {
        for (j = 0; j < 5; j++) {
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < 4; i++) {
        max_in_row = m[i][0];
        col_of_max = 0;
        for (j = 1; j < 5; j++) {
            if (m[i][j] > max_in_row) {
                max_in_row = m[i][j];
                col_of_max = j;
            }
        }
        
        found_saddle = 1;
        for (k = 0; k < 4; k++) {
            if (m[k][col_of_max] < max_in_row) {
                found_saddle = 0;
                break;
            }
        }
        
        if (found_saddle) {
            printf("a[%d][%d]=%d\n", i, col_of_max, max_in_row);
            return 0;
        }
    }

    printf("No\n");

    return 0;
}