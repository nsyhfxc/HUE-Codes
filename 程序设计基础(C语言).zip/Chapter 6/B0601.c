#include <stdio.h>
#include <math.h>

int main() {
    long long flower = 1;
    long long sum = 0;
    int i;

    for (i = 1; i <= 30; i++) {
        flower = pow(2, i - 1);
        printf("day=%d,flower=%lld\n", i, flower);
        sum += flower;
    }

    printf("sum=%lld\n", sum);

    return 0;
}