#include <stdio.h>

int main() {
    char s[100];
    
    // 使用 gets() 读取包含空格和汉字的字符串
    gets(s); 
    
    printf("%s\n", s);

    return 0;
}