#include <stdio.h>

int main() {
    int scores[4][5];
    double aver[4];
    int i, j;
    int index = 0;
    
    for (i = 0; i < 4; i++) {
        int sum = 0;
        for (j = 0; j < 5; j++) {
            scanf("%d", &scores[i][j]);
            sum += scores[i][j];
        }
        aver[i] = (double)sum / 5;
    }

    for (i = 1; i < 4; i++) {
        if (aver[i] > aver[index]) {
            index = i;
        }
    }

    printf("stu_order=%d\n", index);
    printf("max=%7.2f\n", aver[index]);

    return 0;
}