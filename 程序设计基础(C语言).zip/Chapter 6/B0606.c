#include <stdio.h>

int main() {
    double scores[210];
    int i, j;
    double temp;

    for (i = 0; i < 210; i++) {
        scanf("%lf", &scores[i]);
    }

    for (i = 0; i < 209; i++) {
        for (j = 0; j < 209 - i; j++) {
            if (scores[j] < scores[j + 1]) {
                temp = scores[j];
                scores[j] = scores[j + 1];
                scores[j + 1] = temp;
            }
        }
    }

    for (i = 0; i < 210; i++) {
        printf("%6.1lf", scores[i]);
        if ((i + 1) % 10 == 0) {
            printf("\n");
        }
    }
    
    return 0;
}