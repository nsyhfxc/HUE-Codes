#include <stdio.h>

int main() {
    int m[3][4];
    int max_val, max_row, max_col;
    int i, j;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            scanf("%d", &m[i][j]);
        }
    }

    max_val = m[0][0];
    max_row = 0;
    max_col = 0;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 4; j++) {
            if (m[i][j] > max_val) {
                max_val = m[i][j];
                max_row = i;
                max_col = j;
            }
        }
    }

    printf("max=%d,row=%d,col=%d\n", max_val, max_row, max_col);

    return 0;
}