#include <stdio.h>

int main() {
    int a[10];
    int i, j, min_index, temp;

    for (i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }

    for (i = 0; i < 9; i++) {
        min_index = i;
        for (j = i + 1; j < 10; j++) {
            if (a[j] < a[min_index]) {
                min_index = j;
            }
        }
        temp = a[i];
        a[i] = a[min_index];
        a[min_index] = temp;
    }

    for (i = 9; i >= 0; i--) {
        printf("%5d", a[i]);
    }
    printf("\n");

    return 0;
}