#include <stdio.h>

int main() {
    char s[100];
    int num = 0;
    int in_word = 0;
    int i;

    gets(s);
    
    for (i = 0; s[i] != '\0'; i++) {
        if (s[i] == ' ') {
            in_word = 0;
        } else if (in_word == 0) {
            in_word = 1;
            num++;
        }
    }
    
    printf("num=%d\n", num);
    
    return 0;
}