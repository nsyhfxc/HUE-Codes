#include <stdio.h>

int main() {
    char s[100];
    int len = 0;
    
    // 使用 gets() 读取包含空格的字符串，不安全但适用于本题
    gets(s); 
    
    while (s[len] != '\0') {
        len++;
    }
    
    printf("%d\n", len);

    return 0;
}