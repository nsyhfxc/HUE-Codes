#include <stdio.h>

int main() {
    char s1[100], s2[100];
    int i = 0;

    scanf("%s", s1);
    scanf("%s", s2);

    while (s1[i] != '\0' && s2[i] != '\0') {
        if (s1[i] > s2[i]) {
            printf("%d\n", s1[i] - s2[i]);
            return 0;
        } else if (s1[i] < s2[i]) {
            printf("%d\n", s1[i] - s2[i]);
            return 0;
        }
        i++;
    }

    if (s1[i] != '\0') {
        printf("%d\n", s1[i]);
    } else if (s2[i] != '\0') {
        printf("%d\n", -s2[i]);
    } else {
        printf("0\n");
    }

    return 0;
}