#include <stdio.h>

int main() {
    int n, sum = 0;
    scanf("%d", &n);

    int m[n][n];
    int i,j = 0;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &m[i][j]);
        }
    }

    for (i = 0; i < n; i++) {
        sum += m[i][i];
    }

    printf("sum=%d\n", sum);

    return 0;
}