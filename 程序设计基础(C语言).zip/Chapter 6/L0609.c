#include <stdio.h>
#include <string.h>

int main() {
    char s1[100], s2[100], s3[100], max_s[100];
    
    scanf("%s", s1);
    scanf("%s", s2);
    scanf("%s", s3);

    strcpy(max_s, s1);

    if (strcmp(s2, max_s) > 0) {
        strcpy(max_s, s2);
    }
    if (strcmp(s3, max_s) > 0) {
        strcpy(max_s, s3);
    }

    printf("%s\n", max_s);

    return 0;
}