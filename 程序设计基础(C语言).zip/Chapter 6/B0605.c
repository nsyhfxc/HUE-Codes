#include <stdio.h>
#include <string.h>

int main() {
    char s[100];
    char temp;
    int len, i;

    gets(s);
    len = strlen(s);

    for (i = 0; i < len / 2; i++) {
        temp = s[i];
        s[i] = s[len - 1 - i];
        s[len - 1 - i] = temp;
    }

    printf("%s\n", s);

    return 0;
}