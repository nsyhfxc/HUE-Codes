#include <stdio.h>
#include <string.h>

int main() {
    char s[5][20], temp[20];
    int i, j;

    for (i = 0; i < 5; i++) {
        scanf("%s", s[i]);
    }

    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4 - i; j++) {
            if (strcmp(s[j], s[j + 1]) > 0) {
                strcpy(temp, s[j]);
                strcpy(s[j], s[j + 1]);
                strcpy(s[j + 1], temp);
            }
        }
    }
    
    printf("After sorting:\n");
    for (i = 0; i < 5; i++) {
        printf("%s\n", s[i]);
    }

    return 0;
}