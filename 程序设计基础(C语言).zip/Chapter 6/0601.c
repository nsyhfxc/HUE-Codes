#include <stdio.h>
#include <stdbool.h>

int main() {
    bool is_prime[101];
    int i, j;

    for (i = 0; i <= 100; i++) {
        is_prime[i] = true;
    }
    is_prime[0] = is_prime[1] = false;

    for (i = 2; i * i <= 100; i++) {
        if (is_prime[i]) {
            for (j = i * i; j <= 100; j += i) {
                is_prime[j] = false;
            }
        }
    }

    for (i = 0; i <= 100; i++) {
        if (is_prime[i]) {
            printf("%5d", i);
        }
    }
    printf("\n");

    return 0;
}