for num in range(1, 1001):
  if num % 17 == 0:
    print(num, end=' ')