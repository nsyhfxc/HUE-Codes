mylist = {'Li':3,'Zhang':2,'Wang':4}
print(mylist)