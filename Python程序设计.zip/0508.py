def find_max(a, b):
  if a > b:
    return a
  else:
    return b

# 给定的函数调用部分
a = int(input())
b = int(input())
print(find_max(a, b))