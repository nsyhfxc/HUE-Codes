score = int(input("请输入学生分数:"))
if(score < 60):
    print("成绩等级为: C")
elif(score < 90):
    print("成绩等级为: B")
else:
    print("成绩等级为: A")