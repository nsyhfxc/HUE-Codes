def biggest(a, b, c):
  return max(a, b, c)

# 给定的函数调用部分
a = int(input("请输入整数 a: "))
b = int(input("请输入整数 b: "))
c = int(input("请输入整数 c: "))
print(biggest(a, b, c))