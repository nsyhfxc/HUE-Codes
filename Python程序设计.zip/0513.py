def change(a, b):
  return b, a

# 给定的函数调用部分
a = int(input("请输入第一个整数: "))
b = int(input("请输入第二个整数: "))
print(change(a, b))