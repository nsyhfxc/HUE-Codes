import math
a = eval(input("请输入第一个数:"))
b = eval(input("请输入第二个数:"))
print(f"最大数是: {max(a,b)}")