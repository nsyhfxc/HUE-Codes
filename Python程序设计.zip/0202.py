x = float(input("x:"))
y = float(input("y:"))
z = x + y
print(x,"+",y,"=",z)