for num in range(100, 901):
  if num % 7 == 0 and num % 13 == 0 and num % 2 != 0:
    print(num)