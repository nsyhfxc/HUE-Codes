sum_val = 0
n = 0
while sum_val <= 1000:
  n += 1
  sum_val += n

print(sum_val)
print(n)