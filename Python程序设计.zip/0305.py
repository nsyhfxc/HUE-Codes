a = float(input())
b = float(input())
c = (a ** 2 + b ** 2) ** 0.5
print("%.2f" %c)