n = int(input())
sum_of_odds = 0
for i in range(1, n + 1, 2):
  sum_of_odds += i
print(sum_of_odds)