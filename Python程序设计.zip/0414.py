n = int(input("请输入n:"))
sum_of_numbers = sum(range(1, n + 1))
print(sum_of_numbers)