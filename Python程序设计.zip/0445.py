remaining_peaches = 1
for _ in range(4):
  remaining_peaches = 2 * (remaining_peaches + 1)

print(remaining_peaches)