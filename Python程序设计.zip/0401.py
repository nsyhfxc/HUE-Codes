celsius = float(input("输入摄氏温度C:"))  # 获取用户输入的摄氏温度

fahrenheit = celsius * 9 / 5 + 32  # 计算华氏温度

print("华氏温度F:%.2f" % fahrenheit)  # 输出华氏温度，保留两位小数