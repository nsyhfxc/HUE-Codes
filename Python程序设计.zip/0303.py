x = float(input())
y = x ** 2 + 2 * x - 9
print("y= %.3f"%y)