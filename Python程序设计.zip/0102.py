a = int(input())
b = int(input())
c = a + b
print(a,"+",b,"=",c)