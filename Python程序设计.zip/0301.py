import math
r = float(input("r:"))
L  = math.pi * 2 * r
S  = math.pi * r ** 2
print("L:%.2f"%L)
print("S:%.2f"%S)