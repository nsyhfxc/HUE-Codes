sum_of_evens = 0
for i in range(2, 101, 2):
  sum_of_evens += i
print(sum_of_evens)