#include <bits/stdc++.h>
using namespace std;

#define MAXV 30 

// 邻接表存储结构
typedef struct ArcNode {
    int adjvex;              // 该弧所指向的顶点位置
    struct ArcNode *next;    // 指向下一条边
} ArcNode;

typedef struct VNode {
    char data;               // 顶点信息
    ArcNode *first;          // 边表头指针
} VNode, AdjList[MAXV];

typedef struct {
    AdjList vertices;
    int vexnum, arcnum;      // 顶点数和边数
} ALGraph;

// 查找顶点下标
int LocateVex(ALGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++)
        if (G.vertices[i].data == v) return i;
    return -1;
}

// 创建无向图（邻接表）
void CreateUDG(ALGraph &G) {
    cin >> G.vexnum >> G.arcnum;
    string vexs;
    cin >> vexs;
    for (int i = 0; i < G.vexnum; i++) {
        G.vertices[i].data = vexs[i];
        G.vertices[i].first = nullptr;
    }
    for (int i = 0; i < G.arcnum; i++) {
        string e; cin >> e;
        int v1 = LocateVex(G, e[0]);
        int v2 = LocateVex(G, e[1]);
        // 插入v1->v2
        ArcNode *p1 = new ArcNode{v2, G.vertices[v1].first};
        G.vertices[v1].first = p1;
        // 插入v2->v1
        ArcNode *p2 = new ArcNode{v1, G.vertices[v2].first};
        G.vertices[v2].first = p2;
    }
    // 邻接表排序（保证字母序）
    for (int i = 0; i < G.vexnum; i++) {
        vector<int> tmp;
        ArcNode *p = G.vertices[i].first;
        while (p) {
            tmp.push_back(p->adjvex);
            p = p->next;
        }
        sort(tmp.begin(), tmp.end(), [&](int a, int b){
            return G.vertices[a].data < G.vertices[b].data;
        });
        G.vertices[i].first = nullptr;
        for (int j = tmp.size()-1; j >= 0; j--) {
            ArcNode *np = new ArcNode{tmp[j], G.vertices[i].first};
            G.vertices[i].first = np;
        }
    }
}

// 非递归DFS
void dfs(ALGraph &G, char v) {
    vector<bool> visited(G.vexnum, false);
    stack<int> st;
    int start = LocateVex(G, v);
    st.push(start);
    while (!st.empty()) {
        int u = st.top(); st.pop();
        if (!visited[u]) {
            cout << G.vertices[u].data;
            visited[u] = true;
            // 邻接点逆序入栈，保证输出顺序正确
            vector<int> adj;
            for (ArcNode *p = G.vertices[u].first; p; p = p->next)
                if (!visited[p->adjvex]) adj.push_back(p->adjvex);
            for (int i = adj.size()-1; i >= 0; i--) st.push(adj[i]);
        }
    }
}

int main() {
    ALGraph G;
    CreateUDG(G); //采用邻接表创建无向图 
    char v;
    cin >> v;
    dfs(G, v); //以v为顶点深度优先遍历（非递归）
    return 0;
}
