#include <bits/stdc++.h>
using namespace std;

#define MAXV 20 

// 邻接表存储结构
typedef struct ArcNode {
    int adjvex;             // 该弧所指向的顶点位置
    struct ArcNode *next;   // 指向下一条弧的指针
} ArcNode;

typedef struct VNode {
    char data;              // 顶点信息
    ArcNode *first;         // 指向第一条依附该顶点的弧
} VNode, AdjList[MAXV];

typedef struct {
    AdjList vertices;
    int vexnum, arcnum;     // 顶点数和边数
} ALGraph;

int visited[MAXV]; // 访问标记数组

// 查找顶点下标
int LocateVex(ALGraph G, char v) {
    for (int i = 0; i < G.vexnum; i++)
        if (G.vertices[i].data == v) return i;
    return -1;
}

// 建立无向图
void CreateUDG(ALGraph &G) {
    cin >> G.vexnum >> G.arcnum;
    string vexs;
    cin >> vexs;
    for (int i = 0; i < G.vexnum; i++) {
        G.vertices[i].data = vexs[i];
        G.vertices[i].first = NULL;
    }

    for (int k = 0; k < G.arcnum; k++) {
        string edge;
        cin >> edge;
        char v1 = edge[0], v2 = edge[1];
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);

        // 插入 v1->v2
        ArcNode *p1 = new ArcNode;
        p1->adjvex = j;
        p1->next = G.vertices[i].first;
        G.vertices[i].first = p1;

        // 插入 v2->v1
        ArcNode *p2 = new ArcNode;
        p2->adjvex = i;
        p2->next = G.vertices[j].first;
        G.vertices[j].first = p2;
    }

    for (int i = 0; i < G.vexnum; i++) visited[i] = 0;
}

//广搜
void BFS(ALGraph G, int v) {
    queue<int> q;
    cout << G.vertices[v].data;
    visited[v] = 1;
    q.push(v);

    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (ArcNode *p = G.vertices[u].first; p; p = p->next) {
            if (!visited[p->adjvex]) {
                cout << G.vertices[p->adjvex].data;
                visited[p->adjvex] = 1;
                q.push(p->adjvex);
            }
        }
    }
}


int main()
{
    ALGraph G;
    CreateUDG(G); //采用邻接表创建无向图 
    BFS(G,0); //广度优先搜索遍历无向图 
    cout<<endl;
    for(int i=0;i<G.vexnum;i++) visited[i]=0;
    if(G.vexnum>1) BFS(G,1); 
    cout<<endl;
    return 0;
}