#include <bits/stdc++.h>
using namespace std;

#define MAXV 30
#define OK 1
#define ERROR 0

// 边结点
typedef struct ArcNode {
    int adjvex;
    int weight;
    struct ArcNode *next;
} ArcNode;

// 顶点结点
typedef struct VNode {
    char data;
    ArcNode *first;
} VNode, AdjList[MAXV];

// 图结构
typedef struct {
    AdjList vertices;
    int vexnum, arcnum;
} ALGraph;

int LocateVex(ALGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vertices[i].data == v) return i;
    }
    return -1;
}

// 建立有向网
void CreateUDG(ALGraph &G) {
    int m,n;
    cin >> m >> n; // 顶点数,边数
    G.vexnum = m;
    G.arcnum = n;
    string s;
    cin >> s; // 顶点名称
    for(int i=0;i<m;i++){
        G.vertices[i].data = s[i];
        G.vertices[i].first = NULL;
    }
    for(int i=0;i<n;i++){
        string e; int w;
        cin >> e >> w;
        int u = LocateVex(G,e[0]);
        int v = LocateVex(G,e[1]);
        ArcNode *p = new ArcNode;
        p->adjvex = v;
        p->weight = w;
        p->next = G.vertices[u].first;
        G.vertices[u].first = p;
    }
}

// 关键路径算法
int CriticalPath(ALGraph &G, int topo[]) {
    vector<int> indegree(G.vexnum,0);
    for(int i=0;i<G.vexnum;i++){
        for(ArcNode* p=G.vertices[i].first;p;p=p->next)
            indegree[p->adjvex]++;
    }

    // 拓扑排序
    stack<int> S;
    for(int i=0;i<G.vexnum;i++)
        if(indegree[i]==0) S.push(i);

    int count=0;
    vector<int> ve(G.vexnum,0);
    vector<int> topoOrder;

    while(!S.empty()){
        int v=S.top();S.pop();
        topoOrder.push_back(v);
        topo[count++]=v;
        for(ArcNode* p=G.vertices[v].first;p;p=p->next){
            if(--indegree[p->adjvex]==0)
                S.push(p->adjvex);
            if(ve[v]+p->weight > ve[p->adjvex])
                ve[p->adjvex] = ve[v]+p->weight;
        }
    }

    if(count<G.vexnum) return ERROR; // 有环

    vector<int> vl(G.vexnum, ve[topoOrder.back()]);
    for(int i=G.vexnum-1;i>=0;i--){
        int v=topoOrder[i];
        for(ArcNode* p=G.vertices[v].first;p;p=p->next){
            if(vl[p->adjvex]-p->weight < vl[v])
                vl[v] = vl[p->adjvex]-p->weight;
        }
    }

    // 输出关键路径上的弧
    for(int i=0;i<G.vexnum;i++){
        for(ArcNode* p=G.vertices[i].first;p;p=p->next){
            int ee = ve[i];
            int el = vl[p->adjvex]-p->weight;
            if(ee==el){
                cout<<G.vertices[i].data<<G.vertices[p->adjvex].data<<" ";
            }
        }
    }
    cout<<endl;
    return OK;
}

int main()
{
    ALGraph G;
    CreateUDG(G); //采用邻接表创建无向图
    int topo[MAXV]={0};

    //若有关键路径，输出路径上的所有弧（再输出一空格用于间隔）
    if(CriticalPath(G,topo)!=OK)  
           cout<<"Error!"<<endl;

    return 0;
}
