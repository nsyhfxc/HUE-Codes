#include <bits/stdc++.h>
using namespace std;

#define MAXV 100   // 最大顶点数

int visited[MAXV];  // 访问标记数组

typedef struct {
    char vexs[MAXV];       // 顶点表
    int arcs[MAXV][MAXV];  // 邻接矩阵
    int vexnum, arcnum;    // 顶点数、边数
} AMGraph;

// 查找顶点下标
int LocateVex(AMGraph G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vexs[i] == v) return i;
    }
    return -1;
}

// 建立无向图（邻接矩阵）
void CreateUDN(AMGraph &G) {
    cin >> G.vexnum >> G.arcnum;
    for (int i = 0; i < G.vexnum; i++) cin >> G.vexs[i];
    for (int i = 0; i < G.vexnum; i++) {
        for (int j = 0; j < G.vexnum; j++) {
            G.arcs[i][j] = 0;  // 初始化邻接矩阵
        }
    }
    for (int k = 0; k < G.arcnum; k++) {
        char v1, v2;
        int w;
        cin >> v1 >> v2 >> w;
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);
        G.arcs[i][j] = G.arcs[j][i] = w;
    }
}

// 广度优先搜索
void BFS(AMGraph G, int v) {
    queue<int> Q;
    cout << G.vexs[v];  // 访问初始顶点
    visited[v] = 1;
    Q.push(v);

    while (!Q.empty()) {
        int u = Q.front();
        Q.pop();
        for (int j = 0; j < G.vexnum; j++) {
            if (G.arcs[u][j] != 0 && !visited[j]) {
                cout << G.vexs[j];
                visited[j] = 1;
                Q.push(j);
            }
        }
    }
}

int main()
{
    AMGraph G;
    CreateUDN(G);  //创建无向图的邻接矩阵 
    BFS(G,0); //广度优先搜索遍历图 
    cout<<endl;
    for(int i=0;i<G.vexnum;i++) visited[i]=0;
    if(G.vexnum>1) BFS(G,1); 
    cout<<endl;
    return 0;
}
