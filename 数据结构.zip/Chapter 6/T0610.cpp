#include <bits/stdc++.h>
using namespace std;

const int MAXV = 100; // 最大顶点数

struct ArcNode {
    int adjvex;           // 邻接点下标
    ArcNode *next;        // 下一个邻接点
};

struct VNode {
    char data;            // 顶点存储的数据
    ArcNode *first;       // 邻接表头指针
};

struct ALGraph {
    VNode vertices[MAXV]; // 顶点数组
    int vexnum, arcnum;   // 顶点数、边数
};

// 查找顶点下标
int LocateVex(ALGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vertices[i].data == v) return i;
    }
    return -1;
}

// 采用邻接表创建无向图
void CreateUDG(ALGraph &G) {
    int n, m;
    cin >> n >> m; // 输入顶点数、边数
    G.vexnum = n;
    G.arcnum = m;

    // 读入顶点
    string s; 
    cin >> s;
    for (int i = 0; i < n; i++) {
        G.vertices[i].data = s[i];
        G.vertices[i].first = nullptr;
    }

    // 读入边
    for (int i = 0; i < m; i++) {
        string e; 
        cin >> e;
        char v1 = e[0], v2 = e[1];
        int i1 = LocateVex(G, v1);
        int i2 = LocateVex(G, v2);

        // 建立 v1->v2
        ArcNode *p1 = new ArcNode;
        p1->adjvex = i2;
        p1->next = G.vertices[i1].first;
        G.vertices[i1].first = p1;

        // 建立 v2->v1（无向图）
        ArcNode *p2 = new ArcNode;
        p2->adjvex = i1;
        p2->next = G.vertices[i2].first;
        G.vertices[i2].first = p2;
    }
}

bool visited[MAXV];
bool found = false;

// 深度优先搜索，判断是否存在长度为k的简单路径
void DFS(ALGraph &G, int u, int t, int k, int len) {
    if (found) return; // 提前结束
    if (len == k) {
        if (u == t) found = true;
        return;
    }
    ArcNode *p = G.vertices[u].first;
    while (p) {
        int v = p->adjvex;
        if (!visited[v]) {
            visited[v] = true;
            DFS(G, v, t, k, len + 1);
            visited[v] = false;
        }
        p = p->next;
    }
}

bool PathLenk(ALGraph &G, char v, char w, int k) {
    int s = LocateVex(G, v);
    int t = LocateVex(G, w);
    memset(visited, false, sizeof(visited));
    found = false;
    visited[s] = true;
    DFS(G, s, t, k, 0);
    return found;
}

int main() {
    ALGraph G;
    CreateUDG(G); // 采用邻接表创建无向图 
    int k;
    char v, w;
    cin >> v >> w >> k;
    if (PathLenk(G, v, w, k)) 
        cout << "Have path." << endl;
    else 
        cout << "No path." << endl;
    return 0;
}
