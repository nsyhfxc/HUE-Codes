#include <bits/stdc++.h>
using namespace std;

#define MaxVertexNum 100
#define INF 1e9

typedef struct {
    char vexs[MaxVertexNum];        // 顶点
    int arcs[MaxVertexNum][MaxVertexNum]; // 邻接矩阵
    int vexnum, arcnum;             // 顶点数、边数
} AMGraph;

// 查找顶点位置
int LocateVex(AMGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vexs[i] == v) return i;
    }
    return -1;
}

// 创建无向网
void CreateUDN(AMGraph &G, int vnum, int anum) {
    G.vexnum = vnum;
    G.arcnum = anum;
    string vexstr;
    cin >> vexstr;
    for (int i = 0; i < vnum; i++) {
        G.vexs[i] = vexstr[i];
    }
    // 初始化邻接矩阵
    for (int i = 0; i < vnum; i++) {
        for (int j = 0; j < vnum; j++) {
            if (i == j) G.arcs[i][j] = 0;
            else G.arcs[i][j] = INF;
        }
    }
    // 输入边
    for (int i = 0; i < anum; i++) {
        string e; int w;
        cin >> e >> w;
        int a = LocateVex(G, e[0]);
        int b = LocateVex(G, e[1]);
        G.arcs[a][b] = G.arcs[b][a] = w;
    }
}

// 求最短路径距离最大的顶点
char ShortestPathMax(AMGraph &G, int v) {
    int n = G.vexnum;
    vector<int> dist(n, INF);
    vector<bool> vis(n, false);
    dist[v] = 0;

    // Dijkstra
    for (int i = 0; i < n; i++) {
        int u = -1, mind = INF;
        for (int j = 0; j < n; j++) {
            if (!vis[j] && dist[j] < mind) {
                mind = dist[j];
                u = j;
            }
        }
        if (u == -1) break;
        vis[u] = true;
        for (int k = 0; k < n; k++) {
            if (!vis[k] && G.arcs[u][k] < INF) {
                if (dist[u] + G.arcs[u][k] < dist[k]) {
                    dist[k] = dist[u] + G.arcs[u][k];
                }
            }
        }
    }

    // 找最远顶点，若相等取输入顺序靠前的
    int maxd = -1, idx = n;
    for (int i = 0; i < n; i++) {
        if (i != v) {
            if (dist[i] > maxd) {
                maxd = dist[i];
                idx = i;
            } else if (dist[i] == maxd && i < idx) {
                idx = i;
            }
        }
    }
    return G.vexs[idx];
}

int main()
{
    int vnum, anum; //顶点数与边数
    cin >> vnum >> anum;
    AMGraph G;
    CreateUDN(G, vnum, anum);  //创建无向图的邻接矩阵(至少两个顶点) 
    cout << ShortestPathMax(G, 0) << endl; //距离顶点v的最短路径长度最大的一个顶点 
    return 0;
}
