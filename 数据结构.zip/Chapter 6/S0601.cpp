#include <bits/stdc++.h>
using namespace std;

#define MAXV 20         // 最大顶点数
#define INF 1e9         // 表示两点不连通

int visited[MAXV];      // 访问标记数组

// 图的邻接矩阵存储结构
typedef struct {
    int vexnum, arcnum;          // 顶点数、边数
    char vexs[MAXV];             // 顶点信息
    int arcs[MAXV][MAXV];        // 邻接矩阵
} AMGraph;

// 查找顶点在数组中的下标
int LocateVex(AMGraph G, char v) {
    for(int i=0; i<G.vexnum; i++) {
        if(G.vexs[i] == v) return i;
    }
    return -1;
}

// 创建无向图（邻接矩阵）
void CreateUDN(AMGraph &G) {
    cin >> G.vexnum >> G.arcnum;  // 输入顶点数、边数
    string str;
    cin >> str;                   // 输入顶点序列
    for(int i=0; i<G.vexnum; i++) G.vexs[i] = str[i];

    // 初始化邻接矩阵
    for(int i=0; i<G.vexnum; i++) {
        for(int j=0; j<G.vexnum; j++) {
            if(i == j) G.arcs[i][j] = 0;
            else G.arcs[i][j] = INF;
        }
    }

    // 输入边的信息
    for(int k=0; k<G.arcnum; k++) {
        char u, v; int w;
        cin >> u >> v >> w;
        int i = LocateVex(G, u);
        int j = LocateVex(G, v);
        G.arcs[i][j] = w;
        G.arcs[j][i] = w;  // 无向图对称
    }
}

// 深度优先搜索（邻接矩阵）
void DFS_AM(AMGraph G, int v) {
    cout << G.vexs[v];   // 输出当前访问的顶点
    visited[v] = 1;
    for(int j=0; j<G.vexnum; j++) {
        if(G.arcs[v][j] != INF && !visited[j] && v!=j) {
            DFS_AM(G, j);
        }
    }
}

int main(){
    AMGraph G;
    CreateUDN(G);  // 创建无向图的邻接矩阵 
    DFS_AM(G,0);   // 从第一个顶点开始DFS
    cout<<endl;

    for(int i=0;i<G.vexnum;i++) visited[i]=0;

    if(G.vexnum>1) DFS_AM(G,1);  // 从第二个顶点开始DFS
    cout<<endl;
    return 0;
}
