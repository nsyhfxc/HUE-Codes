#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

// 图的邻接矩阵存储结构
struct AMGraph {
    int vexnum, arcnum;          // 顶点数、弧数
    vector<char> vexs;           // 顶点表
    vector<vector<int>> arcs;    // 邻接矩阵
};

// 创建有向图邻接矩阵
void CreateUDN(AMGraph &G, int vnum, int anum) {
    G.vexnum = vnum;
    G.arcnum = anum;
    G.vexs.resize(vnum);
    for (int i = 0; i < vnum; i++) cin >> G.vexs[i];

    G.arcs.assign(vnum, vector<int>(vnum, INF));
    for (int i = 0; i < vnum; i++) G.arcs[i][i] = 0;

    for (int i = 0; i < anum; i++) {
        string s; int w;
        cin >> s >> w;
        int u = -1, v = -1;
        for (int j = 0; j < vnum; j++) {
            if (G.vexs[j] == s[0]) u = j;
            if (G.vexs[j] == s[1]) v = j;
        }
        G.arcs[u][v] = w; // 有向图
    }
}

// 迪杰斯特拉算法（带路径）
void ShortestPath_DIJ(AMGraph &G, int start) {
    int n = G.vexnum;
    vector<int> dist(n, INF);       // 距离
    vector<bool> vis(n, false);     // 是否已确定最短路径
    vector<int> pre(n, -1);         // 前驱数组，记录路径

    dist[start] = 0;

    for (int i = 0; i < n; i++) {
        int u = -1, MIN = INF;
        for (int j = 0; j < n; j++) {
            if (!vis[j] && dist[j] < MIN) {
                u = j;
                MIN = dist[j];
            }
        }
        if (u == -1) break;
        vis[u] = true;

        for (int v = 0; v < n; v++) {
            if (!vis[v] && G.arcs[u][v] < INF) {
                if (dist[u] + G.arcs[u][v] < dist[v]) {
                    dist[v] = dist[u] + G.arcs[u][v];
                    pre[v] = u;
                }
            }
        }
    }

    // 输出
    for (int i = 0; i < n; i++) {
        if (i == start) {
            cout << G.vexs[start] << G.vexs[i] << ":0\n";
            continue;
        }
        if (dist[i] == INF) {
            cout << G.vexs[start] << G.vexs[i] << ":-1\n";
            continue;
        }
        // 还原路径
        vector<int> path;
        for (int v = i; v != -1; v = pre[v]) path.push_back(v);
        reverse(path.begin(), path.end());

        for (int idx : path) cout << G.vexs[idx];
        cout << ":" << dist[i] << "\n";
    }
}

int main() {
    int vnum, anum; //顶点数与边数
    cin >> vnum >> anum;
    AMGraph G;
    CreateUDN(G, vnum, anum);  //创建有向图的邻接矩阵
    ShortestPath_DIJ(G, 0);    // 从第0个顶点(A)开始
    return 0;
}
