#include <bits/stdc++.h>
using namespace std;

const int MAXV = 100; // 最大顶点数

struct ArcNode {
    int adjvex; // 邻接点下标
    ArcNode *next;
};

struct VNode {
    char data;      // 顶点信息
    ArcNode *first; // 邻接表头指针
};

struct ALGraph {
    int vexnum, arcnum; // 顶点数和边数
    VNode vertices[MAXV];
};

// 查找顶点在邻接表中的下标
int LocateVex(ALGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vertices[i].data == v) return i;
    }
    return -1;
}

// 创建有向图（邻接表存储）
void CreateUDG(ALGraph &G) {
    int n, e;
    cin >> n >> e;
    G.vexnum = n;
    G.arcnum = e;

    string vexs;
    cin >> vexs;
    for (int i = 0; i < n; i++) {
        G.vertices[i].data = vexs[i];
        G.vertices[i].first = nullptr;
    }

    for (int k = 0; k < e; k++) {
        string edge;
        cin >> edge;
        char v1 = edge[0], v2 = edge[1];
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);
        ArcNode *p = new ArcNode;
        p->adjvex = j;
        p->next = G.vertices[i].first;
        G.vertices[i].first = p;
    }
}

bool visited[MAXV];

// 深度优先搜索判断路径是否存在
bool DFS(ALGraph &G, int v, int w) {
    if (v == w) return true; // 找到目标
    visited[v] = true;
    for (ArcNode *p = G.vertices[v].first; p; p = p->next) {
        if (!visited[p->adjvex]) {
            if (DFS(G, p->adjvex, w)) return true;
        }
    }
    return false;
}

// 判断是否有从 v 到 w 的路径
bool PathDFS(ALGraph &G, char v, char w) {
    int i = LocateVex(G, v);
    int j = LocateVex(G, w);
    memset(visited, 0, sizeof(visited));
    return DFS(G, i, j);
}

int main() {
    ALGraph G;
    CreateUDG(G); //采用邻接表创建有向图
    char v, w;
    cin >> v >> w;
    if (PathDFS(G, v, w))
        cout << "Have path." << endl;
    else
        cout << "No path." << endl;
    return 0;
}
