#include <bits/stdc++.h>
using namespace std;

const int MAXV = 100; // 最大顶点数
const int INF = 1e9;

struct Edge {
    int u, v; // 顶点编号
    int w;    // 权值
    string name; // 用于输出的边名，如 "AB"
};

struct AMGraph {
    int vexnum, arcnum; // 顶点数、边数
    char vexs[MAXV];    // 顶点名
    int arcs[MAXV][MAXV]; // 邻接矩阵
};

// 并查集
int parent[MAXV];
int find(int x) {
    if (parent[x] != x) parent[x] = find(parent[x]);
    return parent[x];
}
void unite(int x, int y) {
    parent[find(x)] = find(y);
}

// 创建邻接矩阵
void CreateUDN(AMGraph &G, int vnum, int anum, Edge edge[]) {
    G.vexnum = vnum;
    G.arcnum = anum;

    // 输入顶点名
    for (int i = 0; i < vnum; i++) cin >> G.vexs[i];

    // 初始化邻接矩阵
    for (int i = 0; i < vnum; i++)
        for (int j = 0; j < vnum; j++)
            G.arcs[i][j] = (i == j ? 0 : INF);

    // 输入边
    for (int i = 0; i < anum; i++) {
        string s;
        int w;
        cin >> s >> w;
        char a = s[0], b = s[1];
        int u = -1, v = -1;
        for (int j = 0; j < vnum; j++) {
            if (G.vexs[j] == a) u = j;
            if (G.vexs[j] == b) v = j;
        }
        edge[i].u = u;
        edge[i].v = v;
        edge[i].w = w;
        edge[i].name = s;
        G.arcs[u][v] = G.arcs[v][u] = w;
    }
}

// 按权值排序
void sort(Edge edge[], int anum) {
    std::sort(edge, edge + anum, [](Edge a, Edge b) {
        return a.w < b.w;
    });
}

// Kruskal 算法
void MiniSpanTree_Kruskal(AMGraph &G, Edge edge[]) {
    // 初始化并查集
    for (int i = 0; i < G.vexnum; i++) parent[i] = i;

    int count = 0;
    for (int i = 0; i < G.arcnum; i++) {
        int u = edge[i].u;
        int v = edge[i].v;
        if (find(u) != find(v)) {
            unite(u, v);
            cout << edge[i].name << " ";
            count++;
            if (count == G.vexnum - 1) break;
        }
    }
}

int main()
{
    int vnum,anum; //顶点数与边数
    cin>>vnum>>anum;
    Edge edge[anum]; 
    AMGraph G;
    CreateUDN(G,vnum,anum,edge);  //创建无向图的邻接矩阵(至少两个顶点) 
    sort(edge,anum); //按边上权值从小到大排序
    //print(edge,anum); 
    MiniSpanTree_Kruskal(G,edge);  //克鲁斯卡尔算法 最小生成树 
   
    return 0;
}