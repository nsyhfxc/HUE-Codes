#include <bits/stdc++.h> 
using namespace std;

#define MAXV 20 

// 邻接表存储结构
typedef struct ArcNode {
    int adjvex;             // 该弧所指向的顶点位置
    struct ArcNode *next;   // 指向下一条弧的指针
} ArcNode;

typedef struct VNode {
    char data;              // 顶点信息
    ArcNode *first;         // 指向第一条依附该顶点的弧
} VNode, AdjList[MAXV];

typedef struct {
    AdjList vertices;
    int vexnum, arcnum;     // 顶点数和边数
} ALGraph;

int visited[MAXV]; // 访问标记数组

// 查找顶点下标
int LocateVex(ALGraph G, char v) {
    for (int i = 0; i < G.vexnum; i++)
        if (G.vertices[i].data == v) return i;
    return -1;
}

// 建立无向图
void CreateUDG(ALGraph &G) {
    cin >> G.vexnum >> G.arcnum;
    string vexs;
    cin >> vexs;
    for (int i = 0; i < G.vexnum; i++) {
        G.vertices[i].data = vexs[i];
        G.vertices[i].first = NULL;
    }

    for (int k = 0; k < G.arcnum; k++) {
        string edge;
        cin >> edge;
        char v1 = edge[0], v2 = edge[1];
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);

        // 插入 v1->v2
        ArcNode *p1 = new ArcNode;
        p1->adjvex = j;
        p1->next = G.vertices[i].first;
        G.vertices[i].first = p1;

        // 插入 v2->v1
        ArcNode *p2 = new ArcNode;
        p2->adjvex = i;
        p2->next = G.vertices[j].first;
        G.vertices[j].first = p2;
    }

    for (int i = 0; i < G.vexnum; i++) visited[i] = 0;
}

// 深度优先搜索
void DFS(ALGraph G, int v) {
    cout << G.vertices[v].data;
    visited[v] = 1;
    for (ArcNode *p = G.vertices[v].first; p; p = p->next) {
        if (!visited[p->adjvex]) {
            DFS(G, p->adjvex);
        }
    }
}

void DFS_AL(ALGraph G, int start) {
    DFS(G, start);
}

// 删除边 (无向图：要删两次)
void DeleteArc(ALGraph &G, char v, char w) {
    int i = LocateVex(G, v);
    int j = LocateVex(G, w);
    if (i == -1 || j == -1) return;

    // 删除 i -> j
    ArcNode *p = G.vertices[i].first, *pre = NULL;
    while (p) {
        if (p->adjvex == j) {
            if (pre) pre->next = p->next;
            else G.vertices[i].first = p->next;
            delete p;
            break;
        }
        pre = p;
        p = p->next;
    }

    // 删除 j -> i
    p = G.vertices[j].first; pre = NULL;
    while (p) {
        if (p->adjvex == i) {
            if (pre) pre->next = p->next;
            else G.vertices[j].first = p->next;
            delete p;
            break;
        }
        pre = p;
        p = p->next;
    }
}

int main()
{
    ALGraph G;
    CreateUDG(G); //采用邻接表创建无向图 
    DFS_AL(G,0); cout<<endl;//深度优先搜索遍历无向图 
    char v,w; cin>>v>>w;
    DeleteArc(G,v,w); //删除顶点(v,w)组成的边 
    for(int i=0;i<G.vexnum;i++) visited[i]=0; 
    DFS_AL(G,0); cout<<endl;//深度优先搜索遍历无向图 
    
    return 0;
}