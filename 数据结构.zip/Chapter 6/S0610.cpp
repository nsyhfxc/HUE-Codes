#include <bits/stdc++.h>
using namespace std;

#define MAXV 30
#define OK 1
#define ERROR 0

// 边结点
typedef struct ArcNode {
    int adjvex;
    struct ArcNode *next;
} ArcNode;

// 顶点结点
typedef struct VNode {
    char data;
    ArcNode *first;
} VNode, AdjList[MAXV];

// 图结构
typedef struct {
    AdjList vertices;
    int vexnum, arcnum;
} ALGraph;

int LocateVex(ALGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vertices[i].data == v) return i;
    }
    return -1;
}

// 建立有向图
void CreateUDG(ALGraph &G) {
    int m,n;
    cin >> m >> n; // 顶点数,边数
    G.vexnum = m;
    G.arcnum = n;
    string s;
    cin >> s; // 顶点名称
    for(int i=0;i<m;i++){
        G.vertices[i].data = s[i];
        G.vertices[i].first = NULL;
    }
    for(int i=0;i<n;i++){
        string e;
        cin >> e;
        int u = LocateVex(G,e[0]);
        int v = LocateVex(G,e[1]);
        ArcNode *p = new ArcNode;
        p->adjvex = v;
        p->next = G.vertices[u].first;
        G.vertices[u].first = p;
    }
}

// 拓扑排序，返回 OK 表示无环，ERROR 表示有环
int TopologicalSort(ALGraph &G, int topo[]) {
    vector<int> indegree(G.vexnum,0);
    for(int i=0;i<G.vexnum;i++){
        for(ArcNode* p=G.vertices[i].first;p;p=p->next)
            indegree[p->adjvex]++;
    }

    queue<int> Q;
    for(int i=0;i<G.vexnum;i++)
        if(indegree[i]==0) Q.push(i);

    int count=0;
    while(!Q.empty()){
        int v=Q.front();Q.pop();
        topo[count++]=v;
        for(ArcNode* p=G.vertices[v].first;p;p=p->next){
            if(--indegree[p->adjvex]==0)
                Q.push(p->adjvex);
        }
    }

    if(count<G.vexnum) return ERROR; // 有环
    return OK;
}

int main()
{
    ALGraph G;
    CreateUDG(G); //采用邻接表创建有向图 
    int topo[G.vexnum];
    if(TopologicalSort(G,topo)==OK)
    {
        for(int i=0;i<G.vexnum;i++)
        {
            cout<<G.vertices[topo[i]].data;
        }
        cout<<endl;
    }
    else
    {
        cout<<"Have loop."<<endl;
    }
    return 0;
}
