#include <bits/stdc++.h>
using namespace std;

const int MAXV = 100;
const int INF = 1e9;

// 邻接矩阵存储图
struct AMGraph {
    int vexnum, arcnum;              // 顶点数和边数
    vector<char> vexs;               // 顶点集
    int arcs[MAXV][MAXV];            // 邻接矩阵
    int path[MAXV][MAXV];            // 记录最短路径前驱
};

// 创建有向图（邻接矩阵）
void CreateUDN(AMGraph &G, int vnum, int anum) {
    G.vexnum = vnum;
    G.arcnum = anum;
    G.vexs.resize(vnum);

    for (int i = 0; i < vnum; i++)
        for (int j = 0; j < vnum; j++)
            G.arcs[i][j] = (i == j ? 0 : INF);

    string vexstr;
    cin >> vexstr;
    for (int i = 0; i < vnum; i++) G.vexs[i] = vexstr[i];

    for (int k = 0; k < anum; k++) {
        string e;
        int w;
        cin >> e >> w;
        int i = find(G.vexs.begin(), G.vexs.end(), e[0]) - G.vexs.begin();
        int j = find(G.vexs.begin(), G.vexs.end(), e[1]) - G.vexs.begin();
        G.arcs[i][j] = w; // 有向图，只存 i→j
    }
}

// 递归打印路径
void PrintPath(AMGraph &G, int i, int j, vector<int> &pathVec) {
    if (i == j) {
        pathVec.push_back(i);
        return;
    }
    if (G.path[i][j] == -1) { // 没有中间点，直接 i→j
        pathVec.push_back(i);
        pathVec.push_back(j);
    } else {
        int k = G.path[i][j];
        vector<int> left, right;
        PrintPath(G, i, k, left);
        PrintPath(G, k, j, right);
        pathVec.insert(pathVec.end(), left.begin(), left.end()-1);
        pathVec.insert(pathVec.end(), right.begin(), right.end());
    }
}

// Floyd 算法
void ShortestPath_Floyd(AMGraph &G) {
    int n = G.vexnum;
    int dist[MAXV][MAXV];

    // 初始化
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dist[i][j] = G.arcs[i][j];
            G.path[i][j] = -1; // -1 表示没有中间顶点
        }
    }

    // 三重循环
    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (dist[i][k] < INF && dist[k][j] < INF && dist[i][j] > dist[i][k] + dist[k][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                    G.path[i][j] = k; // 记录中间点
                }
            }
        }
    }


    for (int s = 0; s < n; s++) {
    cout << "Start:" << G.vexs[s] << "\n";
            for (int t = 0; t < n; t++) {
                // 起点=终点
                if (s == t) {
                    cout << G.vexs[s] << G.vexs[s] << ":" << 0 << "\n";
                    continue;
                }
                // 不可达情况
                if (dist[s][t] >= INF) {
                    cout << G.vexs[s] << G.vexs[t] << ":-1\n";
                    continue;
                }
                // 可达，打印路径
                vector<int> pathVec;
                PrintPath(G, s, t, pathVec);
                for (int id : pathVec) cout << G.vexs[id];
                cout << ":" << dist[s][t] << "\n";
            }
    }

}

int main() {
    int vnum, anum; // 顶点数与边数
    cin >> vnum >> anum;
    AMGraph G;
    CreateUDN(G, vnum, anum);  // 创建有向图的邻接矩阵
    ShortestPath_Floyd(G);

    return 0;
}
