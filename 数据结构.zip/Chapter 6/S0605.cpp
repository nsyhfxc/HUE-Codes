#include <bits/stdc++.h>
using namespace std;

#define MAXV 100
#define INF 1e9

typedef struct {
    char vexs[MAXV];              // 顶点表
    int arcs[MAXV][MAXV];         // 邻接矩阵
    int vexnum, arcnum;           // 顶点数、边数
} AMGraph;

// 找顶点下标
int LocateVex(AMGraph &G, char v) {
    for (int i = 0; i < G.vexnum; i++) {
        if (G.vexs[i] == v) return i;
    }
    return -1;
}

// 创建无向网
void CreateUDN(AMGraph &G) {
    cin >> G.vexnum >> G.arcnum;
    string s;
    cin >> s;
    for (int i = 0; i < G.vexnum; i++) G.vexs[i] = s[i];

    // 初始化邻接矩阵
    for (int i = 0; i < G.vexnum; i++)
        for (int j = 0; j < G.vexnum; j++)
            G.arcs[i][j] = (i == j ? 0 : INF);

    // 输入边
    for (int k = 0; k < G.arcnum; k++) {
        string e;
        int w;
        cin >> e >> w;
        int i = LocateVex(G, e[0]);
        int j = LocateVex(G, e[1]);
        G.arcs[i][j] = G.arcs[j][i] = w;
    }
}

// 普里姆算法输出最小生成树
void MiniSpanTree_Prim(AMGraph &G, char u) {
    int k = LocateVex(G, u);
    int n = G.vexnum;

    vector<int> lowcost(n), adjvex(n), vis(n, 0);

    for (int j = 0; j < n; j++) {
        if (j != k) {
            lowcost[j] = G.arcs[k][j];
            adjvex[j] = k;
        }
    }
    lowcost[k] = 0; // 加入生成树
    vis[k] = 1;

    for (int i = 1; i < n; i++) {
        int mincost = INF, v = -1;
        for (int j = 0; j < n; j++) {
            if (!vis[j] && lowcost[j] < mincost) {
                mincost = lowcost[j];
                v = j;
            }
        }

        if (v == -1) return;

        cout << G.vexs[adjvex[v]] << G.vexs[v] << " ";

        vis[v] = 1;
        lowcost[v] = 0;

        for (int j = 0; j < n; j++) {
            if (!vis[j] && G.arcs[v][j] < lowcost[j]) {
                lowcost[j] = G.arcs[v][j];
                adjvex[j] = v;
            }
        }
    }
}

int main() {
    AMGraph G;
    CreateUDN(G);  // 创建无向图的邻接矩阵(至少两个顶点)
    MiniSpanTree_Prim(G, G.vexs[0]); // 从第1个顶点出发
    cout << endl;
    MiniSpanTree_Prim(G, G.vexs[1]); // 从第2个顶点出发
    return 0;
}
