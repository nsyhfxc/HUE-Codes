#include <bits/stdc++.h>
using namespace std;

#define MaxVertexNum 100

typedef struct {
    char vexs[MaxVertexNum];         // 顶点表
    int arcs[MaxVertexNum][MaxVertexNum]; // 邻接矩阵
    int vexnum, arcnum;              // 当前顶点数和边数
} AMGraph;

int visited[MaxVertexNum]; // 访问标记数组

// 查找顶点位置
int LocateVex(AMGraph &G, char v) {
    for(int i = 0; i < G.vexnum; i++) {
        if(G.vexs[i] == v) return i;
    }
    return -1;
}

// 创建无向图（邻接矩阵）
void CreateUDN(AMGraph &G) {
    int n, m;
    cin >> n >> m;      // 顶点数、边数
    G.vexnum = n; 
    G.arcnum = m;

    string str;
    cin >> str;         // 输入顶点序列
    for(int i = 0; i < n; i++) G.vexs[i] = str[i];

    // 初始化邻接矩阵
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            G.arcs[i][j] = 0;

    // 输入边
    for(int k = 0; k < m; k++) {
        string e; cin >> e;  // 如 "AB"
        char v1 = e[0], v2 = e[1];
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);
        G.arcs[i][j] = G.arcs[j][i] = 1; // 无向图
    }
}

// 深度优先遍历
void DFS_AM(AMGraph &G, int v) {
    cout << G.vexs[v];
    visited[v] = 1;
    for(int w = 0; w < G.vexnum; w++) {
        if(G.arcs[v][w] && !visited[w])
            DFS_AM(G, w);
    }
}

// 插入顶点
void InsertVex(AMGraph &G, char v) {
    G.vexs[G.vexnum] = v;
    for(int i = 0; i <= G.vexnum; i++) {
        G.arcs[i][G.vexnum] = 0;
        G.arcs[G.vexnum][i] = 0;
    }
    G.vexnum++;
}

// 插入边
void InsertArc(AMGraph &G, char v, char w) {
    int i = LocateVex(G, v);
    int j = LocateVex(G, w);
    if(i != -1 && j != -1) {
        G.arcs[i][j] = G.arcs[j][i] = 1;
        G.arcnum++;
    }
}

// 删除边
void DeleteArc(AMGraph &G, char v, char w) {
    int i = LocateVex(G, v);
    int j = LocateVex(G, w);
    if(i != -1 && j != -1 && G.arcs[i][j] == 1) {
        G.arcs[i][j] = G.arcs[j][i] = 0;
        G.arcnum--;
    }
}

int main()
{
    AMGraph G;
    CreateUDN(G);  //创建无向图的邻接矩阵 
    DFS_AM(G,0); cout<<endl;//深度优先搜索遍历图 

    char v,w; 
    cin >> v >> w;  
    DeleteArc(G,v,w); // 删除边 (v,w)

    for(int i=0;i<G.vexnum; i++) visited[i]=0; // visited数组置为初始状态 
    DFS_AM(G,0); //深度优先搜索遍历 
    return 0;
}
