#include<bits/stdc++.h>
using namespace std;
#define MAX_VEX 100
#define INFINITY 2147483647

typedef struct {
    char vexs[MAX_VEX];                // 顶点表
    int arcs[MAX_VEX][MAX_VEX];      // 邻接矩阵
    int vnum, anum;                  // 图的当前顶点数和弧数
} AMGraph;

// 定位顶点在顶点表中的位置（下标）
int LocateVex(const AMGraph& G, char v) {
    for (int i = 0; i < G.vnum; ++i) {
        if (G.vexs[i] == v) {
            return i;
        }
    }
    return -1; // 未找到
}

// 创建无向图的邻接矩阵
void CreateUDN(AMGraph& G, int vnum, int anum) {
    G.vnum = vnum;
    G.anum = anum;

    // 输入顶点信息
    for (int i = 0; i < G.vnum; ++i) {
        cin >> G.vexs[i];
    }

    // 初始化邻接矩阵
    for (int i = 0; i < G.vnum; ++i) {
        for (int j = 0; j < G.vnum; ++j) {
            if (i == j) {
                G.arcs[i][j] = 0;
            } else {
                G.arcs[i][j] = INFINITY;
            }
        }
    }

    // 输入边的信息
    for (int k = 0; k < G.anum; ++k) {
        char v1_char, v2_char;
        int weight;
        cin >> v1_char >> v2_char >> weight;

        int i = LocateVex(G, v1_char);
        int j = LocateVex(G, v2_char);

        if (i != -1 && j != -1) {
            G.arcs[i][j] = weight;
            G.arcs[j][i] = G.arcs[i][j]; // 因为是无向图
        }
    }
}

char ShortestPathMax(const AMGraph& G, int v_idx) {
    vector<int> dist(G.vnum);      // 存储从v_idx到各顶点的最短路径长度
    vector<bool> S(G.vnum, false); // 集合S，记录已找到最短路径的顶点

    // 1. 初始化
    for (int i = 0; i < G.vnum; ++i) {
        dist[i] = G.arcs[v_idx][i];
    }
    S[v_idx] = true; // 将源点加入集合S
    dist[v_idx] = 0;

    // 2. 执行Dijkstra算法主循环
    for (int i = 1; i < G.vnum; ++i) {
        int min_dist = INFINITY;
        int u = v_idx;

        // 找到当前未访问顶点中距离最近的顶点u
        for (int j = 0; j < G.vnum; ++j) {
            if (!S[j] && dist[j] < min_dist) {
                min_dist = dist[j];
                u = j;
            }
        }

        // 将u加入S
        S[u] = true;

        // 更新u的邻接点的距离
        for (int j = 0; j < G.vnum; ++j) {
            if (!S[j] && G.arcs[u][j] < INFINITY) {
                if (dist[u] + G.arcs[u][j] < dist[j]) {
                    dist[j] = dist[u] + G.arcs[u][j];
                }
            }
        }
    }

    // 3. 寻找最远顶点
    int max_dist = -1;
    int max_idx = -1;
    for (int i = 0; i < G.vnum; ++i) {
        // 确保不会选择自身，并且路径可达
        if (dist[i] > max_dist && dist[i] != INFINITY) {
            max_dist = dist[i];
            max_idx = i;
        }
    }
    
    if (max_idx == -1) {
        return -1; 
    }
    
    return G.vexs[max_idx];
}

int main()
{
    int vnum, anum; //顶点数与边数
    cin >> vnum >> anum;
    AMGraph G;
    CreateUDN(G, vnum, anum);  //创建无向图的邻接矩阵(至少两个顶点) 
    cout << ShortestPathMax(G, 0) << endl; //距离顶点v(索引为0)的最短路径长度最大的一个顶点 
    return 0;
}