#include <bits/stdc++.h>
using namespace std;

#define MaxVertexNum 100

typedef struct {
    char vexs[MaxVertexNum];         // 顶点表
    int arcs[MaxVertexNum][MaxVertexNum]; // 邻接矩阵
    int vexnum, arcnum;              // 当前顶点数和边数
} AMGraph;

int visited[MaxVertexNum]; // 访问标记数组

// 查找顶点位置
int LocateVex(AMGraph &G, char v) {
    for(int i = 0; i < G.vexnum; i++) {
        if(G.vexs[i] == v) return i;
    }
    return -1;
}

// 创建无向图（邻接矩阵）
void CreateUDN(AMGraph &G) {
    int n, m;
    cin >> n >> m;      // 顶点数、边数
    G.vexnum = n; 
    G.arcnum = m;

    string str;
    cin >> str;         // 输入顶点序列
    for(int i = 0; i < n; i++) G.vexs[i] = str[i];

    // 初始化邻接矩阵
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            G.arcs[i][j] = 0;

    // 输入边
    for(int k = 0; k < m; k++) {
        string e; cin >> e;  // 如 "AB"
        char v1 = e[0], v2 = e[1];
        int i = LocateVex(G, v1);
        int j = LocateVex(G, v2);
        G.arcs[i][j] = G.arcs[j][i] = 1; // 无向图
    }
}

// 深度优先遍历
void DFS_AM(AMGraph &G, int v) {
    cout << G.vexs[v];
    visited[v] = 1;
    for(int w = 0; w < G.vexnum; w++) {
        if(G.arcs[v][w] && !visited[w])
            DFS_AM(G, w);
    }
}

// 删除顶点
void DeleteVex(AMGraph &G, char v) {
    int k = LocateVex(G, v);
    if(k == -1) return;

    // 删除顶点 v
    for(int i = k; i < G.vexnum - 1; i++) {
        G.vexs[i] = G.vexs[i+1];
    }

    // 删除邻接矩阵中的第 k 行
    for(int i = k; i < G.vexnum - 1; i++) {
        for(int j = 0; j < G.vexnum; j++) {
            G.arcs[i][j] = G.arcs[i+1][j];
        }
    }

    // 删除邻接矩阵中的第 k 列
    for(int j = k; j < G.vexnum - 1; j++) {
        for(int i = 0; i < G.vexnum - 1; i++) {
            G.arcs[i][j] = G.arcs[i][j+1];
        }
    }

    G.vexnum--;
}

int main()
{
    AMGraph G;
    CreateUDN(G);  //创建无向图的邻接矩阵 
    DFS_AM(G,0); cout<<endl;//深度优先搜索遍历图 

    char v; cin >> v;  
    DeleteVex(G,v); // 删除值为 v 的顶点 

    for(int i=0;i<G.vexnum; i++) visited[i]=0; //visited数组置为初始状态 
    DFS_AM(G,0); //深度优先搜索遍历 
    return 0;
}
