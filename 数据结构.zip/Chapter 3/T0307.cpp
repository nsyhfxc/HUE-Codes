#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXQSIZE 3
typedef int Status;
typedef float QElemType;

typedef struct{
    QElemType *base;
    int front,rear,tag;  // tag=0表示空，tag=1表示满
}SqQueue;

// 初始化队列
Status InitQueue(SqQueue &Q){
    Q.base = new QElemType[MAXQSIZE];
    if(!Q.base) exit(OVERFLOW);
    Q.front = Q.rear = 0;
    Q.tag = 0;
    return OK;
}

// 入队
Status EnQueue(SqQueue &Q, QElemType e){
    if(Q.front==Q.rear && Q.tag==1)  // 满
        return ERROR;
    Q.base[Q.rear] = e;
    Q.rear = (Q.rear+1) % MAXQSIZE;
    if(Q.rear == Q.front) Q.tag = 1;  // 若插入后队尾追上队头，则满
    else Q.tag = 0;                   // 否则不是满
    return OK;
}

// 出队
Status DeQueue(SqQueue &Q, QElemType &e){
    if(Q.front==Q.rear && Q.tag==0)  // 空
        return ERROR;
    e = Q.base[Q.front];
    Q.front = (Q.front+1) % MAXQSIZE;
    if(Q.front == Q.rear) Q.tag = 0;  // 若删除后队头追上队尾，则空
    else Q.tag = 1;                   // 否则不是空
    return OK;
}

int main()
{
    SqQueue Q;
    InitQueue(Q); 
    int i,n;
    float f;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>f;
        if(EnQueue(Q,f)==ERROR) cout<<"Full!"<<endl;
        else cout<<"EnQueue:"<<f<<endl;
    }
    
    for(i=0;i<n;i++)
    {
        if(DeQueue(Q,f)==ERROR) cout<<"Empty!"<<endl;
        else cout<<"DeQueue:"<<f<<endl;
    }
    return 0;
}
