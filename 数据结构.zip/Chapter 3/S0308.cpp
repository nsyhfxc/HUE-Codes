#include <bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
typedef string SElemType;

// 链栈结点定义
typedef struct StackNode {
    SElemType data;
    struct StackNode *next;
} StackNode, *LinkStack;

// 初始化栈
Status InitStack(LinkStack &S) {
    S = nullptr;  // 空栈
    return OK;
}

// 入栈
Status Push(LinkStack &S, SElemType e) {
    StackNode *p = new StackNode;
    if (!p) return ERROR;
    p->data = e;
    p->next = S;
    S = p;
    return OK;
}

// 判空
bool StackEmpty(LinkStack S) {
    return S == nullptr;
}

// 出栈（返回栈顶元素并删除）
Status Pop(LinkStack &S, SElemType &e) {
    if (!S) return ERROR;
    StackNode *p = S;
    e = p->data;
    S = S->next;
    delete p;
    return OK;
}

// 十进制 n 转换为 m 进制
void conversion(int n, int m) {
    LinkStack S;
    InitStack(S);

    string digits = "0123456789abcdefghijklmnopqrstuvwxyz";

    // 除 m 取余，入栈
    while (n > 0) {
        int r = n % m;
        Push(S, string(1, digits[r]));
        n /= m;
    }

    // 出栈并输出
    SElemType e;
    while (!StackEmpty(S)) {
        Pop(S, e);
        cout << e;
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    conversion(n, m); // 十进制 n 转换为 m 进制 
    cout << endl;
    return 0;
}
