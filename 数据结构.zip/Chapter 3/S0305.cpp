#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXQSIZE 5   // 队列的最大容量

typedef int Status;
typedef float QElemType;

typedef struct{
    QElemType *base;  // 存储空间基址
    int front;        // 队头指针
    int rear;         // 队尾指针
}SqQueue;

// 初始化循环队列
Status InitQueue(SqQueue &Q) {
    Q.base = new QElemType[MAXQSIZE];
    if (!Q.base) exit(OVERFLOW);
    Q.front = Q.rear = 0;  // 队列为空
    return OK;
}

// 队列长度
int QueueLength(SqQueue Q) {
    return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE;
}

// 入队
Status EnQueue(SqQueue &Q, QElemType e) {
    if ((Q.rear + 1) % MAXQSIZE == Q.front) return ERROR; // 队满
    Q.base[Q.rear] = e;
    Q.rear = (Q.rear + 1) % MAXQSIZE;
    return OK;
}

// 出队
Status DeQueue(SqQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    e = Q.base[Q.front];
    Q.front = (Q.front + 1) % MAXQSIZE;
    return OK;
}

// 取队头元素
QElemType GetHead(SqQueue Q) {
    if (Q.front != Q.rear) return Q.base[Q.front];
    return ERROR; // 队空时返回ERROR处理
}

int main() {
    SqQueue sq;
    float s;
    InitQueue(sq); // 初始化循环队列

    for (int i = 0; i < 5; i++) {
        cin >> s;
        if (EnQueue(sq, s)) cout << "EnQueue success:" << s << endl; 
        else cout << "Queue Full!" << endl;
    }

    DeQueue(sq, s); // 出队 
    cout << "Dequeue:" << s << endl;

    cin >> s;
    if (EnQueue(sq, s)) cout << "EnQueue success:" << s << endl;
    else cout << "Queue Full!" << endl;

    while (QueueLength(sq) > 0) {
        cout << GetHead(sq) << endl;
        DeQueue(sq, s);
    }

    return 0;
}
