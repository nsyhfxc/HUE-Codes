#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXQSIZE 5
typedef int Status;
typedef float QElemType;

typedef struct QNode{
    QElemType data;
    struct QNode *next;
}QNode,*QueuePtr;

typedef struct{
    QueuePtr rear;   // 指向队尾结点
}LQ,*LinkQueue;

// 初始化队列（带头结点的循环链表，rear指向头结点）
Status InitQueue(LinkQueue Q){
    Q->rear = new QNode;
    if(!Q->rear) exit(OVERFLOW);
    Q->rear->next = Q->rear; // 循环指向自己
    return OK;
}

// 判断队列是否为空
Status EmptyQueue(LinkQueue Q){
    return (Q->rear->next == Q->rear);  // rear->next == rear 表示只有头结点
}

// 入队（在rear后插入新结点，并更新rear）
Status EnQueue(LinkQueue Q, QElemType e){
    QueuePtr p = new QNode;
    if(!p) exit(OVERFLOW);
    p->data = e;

    // 插入到队尾（头结点的后继是队头）
    p->next = Q->rear->next;  // 新结点的next指向头结点
    Q->rear->next = p;        // 原队尾的next指向新结点
    Q->rear = p;              // 更新rear
    return OK;
}

// 出队（删除头结点之后的第一个元素，即队头）
Status DeQueue(LinkQueue Q, QElemType &e){
    if(EmptyQueue(Q)) return ERROR;

    QueuePtr head = Q->rear->next; // 头结点
    QueuePtr p = head->next;       // 第一个元素
    e = p->data;
    head->next = p->next;          // 删除p
    if(p == Q->rear)               // 如果队列中只有一个元素，出队后rear回到头结点
        Q->rear = head;
    delete p;
    return OK;
}

int main()
{
    LinkQueue Q = new LQ;
    InitQueue(Q); //队尾指针指向头结点，头结点的next指向自己 
    if(EmptyQueue(Q)) cout<<"Empty!"<<endl;
    else cout<<"Not Empty!"<<endl;
    int n,i;
    float f;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>f;
        EnQueue(Q,f); //入队，将f作为新的队尾元素插入 
    }
    while(!EmptyQueue(Q))
    {
        DeQueue(Q,f);
        cout<<"DeQueue:"<<f<<endl; //将头元素出队 
    }

    return 0;
}
