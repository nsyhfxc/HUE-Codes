#include <bits/stdc++.h>
using namespace std;

typedef int SElemType;

// 链栈结点
typedef struct StackNode {
    SElemType data;
    struct StackNode *next;
} StackNode, *LinkStack;

// 初始化栈
void InitStack(LinkStack &S) {
    S = nullptr; // 空栈
}

// 入栈
void Push(LinkStack &S, SElemType e) {
    StackNode *p = new StackNode;
    p->data = e;
    p->next = S;
    S = p;
}

// 出栈
bool Pop(LinkStack &S, SElemType &e) {
    if (!S) return false; // 栈空
    StackNode *p = S;
    e = p->data;
    S = S->next;
    delete p;
    return true;
}

// 判断栈空
bool StackEmpty(LinkStack S) {
    return S == nullptr;
}

// 十进制转八进制
void conversion(int n) {
    LinkStack S;
    InitStack(S);

    // 除8取余，压栈
    while (n) {
        Push(S, n % 8);
        n /= 8;
    }

    // 依次出栈，输出八进制
    int e;
    while (!StackEmpty(S)) {
        Pop(S, e);
        cout << e;
    }
}

int main() {
    int n;
    cin >> n;
    conversion(n); // 十进制n转换为八进制 
    cout << endl;
    return 0;
}
