#include <bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXSIZE 100
typedef int Status;
typedef int SElemType;

// 顺序栈定义
typedef struct {
    SElemType *base;
    SElemType *top;
    int stacksize;
} SqStack;

// 初始化顺序栈
Status InitStack(SqStack &S) {
    S.base = new SElemType[MAXSIZE];
    if (!S.base) exit(OVERFLOW);
    S.top = S.base;
    S.stacksize = MAXSIZE;
    return OK;
}

// 入栈
Status Push(SqStack &S, SElemType e) {
    if (S.top - S.base >= S.stacksize) return ERROR; // 栈满
    *S.top++ = e;
    return OK;
}

// 出栈
Status Pop(SqStack &S) {
    if (S.top == S.base) return ERROR; // 栈空
    --S.top;
    return OK;
}

// 获取栈顶元素
SElemType GetTop(SqStack &S) {
    if (S.top == S.base) return ERROR; // 栈空
    return *(S.top - 1);
}

int main() {
    SqStack sint;
    InitStack(sint);

    int s;
    for (int i = 0; i < 4; i++) {
        cin >> s;
        Push(sint, s);
    }

    for (int i = 0; i < 4; i++) {
        int e = GetTop(sint);
        Pop(sint);
        cout << e << endl;
    }
    return 0;
}
