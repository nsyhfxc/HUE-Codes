#include <bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXSIZE 5   // 设置一个小的容量方便测试
typedef int Status;
typedef int SElemType;   // 改为 int 类型

// 顺序栈定义
typedef struct {
    SElemType *base;
    SElemType *top;
    int stacksize;
} SqStack;

// 初始化顺序栈
Status InitStack(SqStack &S) {
    S.base = new SElemType[MAXSIZE];
    if (!S.base) exit(OVERFLOW);
    S.top = S.base;
    S.stacksize = MAXSIZE;
    return OK;
}

// 入栈
Status Push(SqStack &S, SElemType e) {
    if (S.top - S.base >= S.stacksize) return ERROR; // 栈满
    *S.top++ = e;
    return OK;
}

// 出栈（返回栈顶元素）
Status Pop(SqStack &S, SElemType &e) {
    if (S.top == S.base) return ERROR; // 栈空
    --S.top;
    e = *S.top;
    return OK;
}

// 获取栈顶元素
SElemType GetTop(SqStack &S) {
    if (S.top == S.base) return ERROR; // 栈空
    return *(S.top - 1);
}

// 判空
Status StackEmpty(SqStack S) {
    return S.top == S.base;
}

// 处理输入逻辑
void InOut(SqStack &S, int x) {
    if (x != -1) {
        if (Push(S, x) == ERROR) {
            cout << "Full! Push Error!" << endl;
        } else {
            cout << "Push:" << x << endl;
        }
    } else {
        int y;
        if (Pop(S, y) == ERROR) {
            cout << "Empty! Pop Error!" << endl;
        } else {
            cout << "x=-1,Pop:" << y << endl;
        }
    }
}

int main()
{
    SqStack s;
    InitStack(s);
    int i,n=8,x;
    for(i=0;i<n;i++)
    {
        cin >> x;
        InOut(s,x);
    }
    while(!StackEmpty(s))
    { 
        int y;
        Pop(s,y);
        cout << y << " ";
    }
    cout << endl;
    
    return 0;
}
