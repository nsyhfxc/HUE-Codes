#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
typedef int Status;
typedef float QElemType;

// 队列结点
typedef struct QNode {
    QElemType data;
    struct QNode *next;
} QNode, *QueuePtr;

// 链队
typedef struct {
    QueuePtr front;  // 队头指针
    QueuePtr rear;   // 队尾指针
} LinkQueue;

// 初始化队列
Status InitQueue(LinkQueue &Q) {
    Q.front = Q.rear = new QNode; // 建立头结点
    if (!Q.front) exit(OVERFLOW);
    Q.front->next = nullptr;
    return OK;
}

// 入队
Status EnQueue(LinkQueue &Q, QElemType e) {
    QueuePtr p = new QNode;
    if (!p) exit(OVERFLOW);
    p->data = e;
    p->next = nullptr;
    Q.rear->next = p;
    Q.rear = p;
    return OK;
}

// 出队
Status DeQueue(LinkQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    QueuePtr p = Q.front->next;
    e = p->data;
    Q.front->next = p->next;
    if (Q.rear == p) Q.rear = Q.front; // 若删除的是最后一个结点
    delete p;
    return OK;
}

// 取队头元素
QElemType GetHead(LinkQueue Q) {
    if (Q.front != Q.rear) return Q.front->next->data;
    return ERROR; // 队空时返回 -1
}

int main() {
    LinkQueue lq;
    InitQueue(lq); // 初始化链队 

    QElemType s;
    int i;
    for (i = 0; i < 5; i++) {
        cin >> s;
        EnQueue(lq, s); // 入队 
    }

    cout << GetHead(lq) << endl; // 取队头元素 

    DeQueue(lq, s); // 出队 
    cout << "Dequeue:" << s << endl;

    for (i = 0; i < 5; i++) {
        if (DeQueue(lq, s)) cout << "Dequeue:" << s << endl;
        else cout << "Queue empty!" << endl;
    }

    return 0;
}
