#include <bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
typedef string SElemType;

// 链栈结点定义
typedef struct StackNode {
    SElemType data;
    struct StackNode *next;
} StackNode, *LinkStack;

// 初始化栈
Status InitStack(LinkStack &S) {
    S = nullptr;  // 空栈
    return OK;
}

// 入栈
Status Push(LinkStack &S, SElemType e) {
    StackNode *p = new StackNode;
    if (!p) return ERROR;
    p->data = e;
    p->next = S;
    S = p;
    return OK;
}

// 判空
bool StackEmpty(LinkStack S) {
    return S == nullptr;
}

// 取栈顶元素
SElemType GetTop(LinkStack S) {
    if (S) return S->data;
    return "";  // 空栈时返回空字符串
}

// 出栈
Status Pop(LinkStack &S) {
    if (!S) return ERROR;
    StackNode *p = S;
    S = S->next;
    delete p;
    return OK;
}

int main() {
    LinkStack Ls;
    InitStack(Ls); // 初始化链栈 

    int n;
    string s;
    cin >> n;
    cin.ignore(); // 读取整数后，清理换行符

    for (int i = 0; i < n; i++) {
        getline(cin, s); // 逐行读取字符串
        Push(Ls, s);     // 入栈
    }

    while (!StackEmpty(Ls)) {
        cout << GetTop(Ls) << endl; // 取栈顶元素 
        Pop(Ls);     // 出栈 
    }
    return 0;
}
