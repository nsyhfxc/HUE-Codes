#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXQSIZE 10   // 队列的最大容量（注意这里比5大一点，否则演示时可能装不下）

typedef int Status;
typedef float QElemType;

typedef struct{
    QElemType *base;  // 存储空间基址
    int front;        // 队头指针
    int rear;         // 队尾指针
}SqQueue;

// 初始化循环队列
Status InitQueue(SqQueue &Q) {
    Q.base = new QElemType[MAXQSIZE];
    if (!Q.base) exit(OVERFLOW);
    Q.front = Q.rear = 0;  // 队列为空
    return OK;
}

// 队列长度
int QueueLength(SqQueue Q) {
    return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE;
}

// 入队（从队尾插入）
Status EnQueue(SqQueue &Q, QElemType e) {
    if ((Q.rear + 1) % MAXQSIZE == Q.front) return ERROR; // 队满
    Q.base[Q.rear] = e;
    Q.rear = (Q.rear + 1) % MAXQSIZE;
    return OK;
}

// 出队（从队头删除）
Status DeQueue(SqQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    e = Q.base[Q.front];
    Q.front = (Q.front + 1) % MAXQSIZE;
    return OK;
}

// 从队头插入
Status EnQueueFront(SqQueue &Q, QElemType e) {
    if ((Q.rear + 1) % MAXQSIZE == Q.front) return ERROR; // 队满
    Q.front = (Q.front - 1 + MAXQSIZE) % MAXQSIZE; // 队头前移
    Q.base[Q.front] = e;
    return OK;
}

// 从队尾删除
Status DeQueueRear(SqQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    Q.rear = (Q.rear - 1 + MAXQSIZE) % MAXQSIZE; // 队尾前移
    e = Q.base[Q.rear];
    return OK;
}

// 遍历队列
void ShowQueue(SqQueue Q) {
    int i = Q.front;
    while (i != Q.rear) {
        cout << Q.base[i] << endl;
        i = (i + 1) % MAXQSIZE;
    }
}

int main()
{
    SqQueue sq;
    float s;
    InitQueue(sq); //初始化循环队列
    int n;
    cin >> n;
    for(int i=0; i<n; i++)
    {
        cin >> s;
        if(i % 2 == 0) EnQueue(sq, s);     // 偶数位置：从队尾插入
        else EnQueueFront(sq, s);          // 奇数位置：从队头插入
    }
    
    ShowQueue(sq); // 遍历队列 
    
    if(DeQueue(sq, s)) cout << "Dequeue:" << s << endl;
    if(DeQueueRear(sq, s)) cout << "DequeueRear:" << s << endl;
    
    ShowQueue(sq);
    
    return 0;
}
