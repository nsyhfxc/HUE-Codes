#include <bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
typedef char SElemType;  // 单个字符即可

// 链栈结点定义
typedef struct StackNode {
    SElemType data;
    struct StackNode *next;
} StackNode, *LinkStack;

// 初始化栈
Status InitStack(LinkStack &S) {
    S = nullptr;
    return OK;
}

// 入栈
Status Push(LinkStack &S, SElemType e) {
    StackNode *p = new StackNode;
    if (!p) return ERROR;
    p->data = e;
    p->next = S;
    S = p;
    return OK;
}

// 判空
bool StackEmpty(LinkStack S) {
    return S == nullptr;
}

// 取栈顶元素
SElemType GetTop(LinkStack S) {
    if (S) return S->data;
    return '\0';  // 空栈返回空字符
}

// 出栈
Status Pop(LinkStack &S) {
    if (!S) return ERROR;
    StackNode *p = S;
    S = S->next;
    delete p;
    return OK;
}

// 判断回文
bool IsPalindrome(const string &str) {
    LinkStack S;
    InitStack(S);
    
    int n = str.size();
    int mid = n / 2;
    
    // 前半部分入栈
    for (int i = 0; i < mid; i++) {
        if(str[i] != ' ') Push(S, str[i]);
    }

    // 后半部分开始比较
    int start = (n % 2 == 0) ? mid : mid + 1;  // 奇数长度跳过中间字符
    for (int i = start; i < n; i++) {
        if(str[i] == ' ') continue; // 忽略空格
        if(StackEmpty(S) || str[i] != GetTop(S)) return false;
        Pop(S);
    }
    return true;
}

int main() {
    string s;
    getline(cin, s);
    if(IsPalindrome(s)) cout << "True" << endl;
    else cout << "False" << endl;
}
