#include <bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;
typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;

// 初始化链表
Status InitList(LinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = NULL;
    return OK;
}

// 创建链表：前插法，直到读入 0 为止
Status CreateList_H(LinkList &L) {
    L = new LNode;
    L->next = NULL;
    ElemType e;
    while (cin >> e) {
        if (e == "0") break;
        LinkList s = new LNode;
        s->data = e;
        s->next = L->next;
        L->next = s;
    }
    return OK;
}

// 递归求最大值
int GetMax(LinkList f) {
    if (f == NULL) return INT_MIN;
    int current = stoi(f->data);
    int max_rest = GetMax(f->next);
    return max(current, max_rest);
}

// 递归求长度
int GetLength(LinkList f) {
    if (f == NULL) return 0;
    return 1 + GetLength(f->next);
}

// 辅助函数：递归求和
double GetSum(LinkList f) {
    if (f == NULL) return 0;
    return stoi(f->data) + GetSum(f->next);
}

// 平均值 = 总和 / 个数
double GetAverage(LinkList f, int n) {
    if (n == 0) return 0;
    double sum = GetSum(f);
    return sum / n;
}

int main()
{
    LinkList lk;
    InitList(lk);
    CreateList_H(lk); //前插法创建链表，遇到数据0时结束，0不插入链表 
    LinkList f=lk->next;
    cout<<"max="<<GetMax(f)<<endl; 
    int n=GetLength(f);
    cout<<"length="<<n<<endl;
    cout<<"average="<<GetAverage(f,n)<<endl;
    
    return 0;
}