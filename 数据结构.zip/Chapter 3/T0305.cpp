#include <bits/stdc++.h>
using namespace std;

bool Judge(char IOstr[]) {
    stack<char> st;
    for(int i = 0; IOstr[i] != '\0'; i++) {
        char c = IOstr[i];
        if(c == 'I' || c == 'i') {
            st.push('X');
        } else if(c == 'O' || c == 'o') {
            if(st.empty()) return false;
            st.pop();
        } else {
            return false;
        }
    }
    return st.empty();
}

int main() {
    char IOstr[81];
    cin >> IOstr;
    if(Judge(IOstr)) cout << "True" << endl;
    else cout << "False" << endl;
    return 0;
}
