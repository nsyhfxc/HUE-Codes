#include<bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXQSIZE 5

typedef int Status;
typedef float QElemType;

// 循环队列结构
typedef struct{
    QElemType *base;  
    int front;        
    int rear;         
}SqQueue;

// 初始化循环队列
Status InitQueue(SqQueue &Q) {
    Q.base = new QElemType[MAXQSIZE];
    if (!Q.base) exit(OVERFLOW);
    Q.front = Q.rear = 0;  
    return OK;
}

// 队列长度
int QueueLength(SqQueue Q) {
    return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE;
}

// 入队
Status EnQueue(SqQueue &Q, QElemType e) {
    if ((Q.rear + 1) % MAXQSIZE == Q.front) return ERROR; // 队满
    Q.base[Q.rear] = e;
    Q.rear = (Q.rear + 1) % MAXQSIZE;
    return OK;
}

// 出队
Status DeQueue(SqQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    e = Q.base[Q.front];
    Q.front = (Q.front + 1) % MAXQSIZE;
    return OK;
}

// 取队头元素
QElemType GetHead(SqQueue Q) {
    if (Q.front != Q.rear) return Q.base[Q.front];
    return ERROR; 
}

// 舞伴结构体
struct Person {
    string name;
    char sex;
};

// 舞伴匹配函数
void DancePartner(Person *p, int n) {
    queue<string> men;
    queue<string> women;
    
    for(int i=0;i<n;i++){
        if(p[i].sex == 'M') men.push(p[i].name);
        else women.push(p[i].name);
    }

    cout << "The dancing partners are:" << endl;
    while(!men.empty() && !women.empty()) {
        cout << women.front() << " " << men.front() << endl;
        women.pop();
        men.pop();
    }

    if(!men.empty()) {
        cout << "The first man to get a partner is:" << men.front() << endl;
    } else if(!women.empty()) {
        cout << "The first woman to get a partner is:" << women.front() << endl;
    }
}

int main() {
    int n;
    cin >> n;
    Person *p = new Person[n];
    for(int i=0;i<n; i++) {
        cin >> p[i].name >> p[i].sex;
    }
    DancePartner(p,n);
    delete[] p;
    return 0;
}
