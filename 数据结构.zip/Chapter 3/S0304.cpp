#include <bits/stdc++.h>
using namespace std;

typedef struct{
    int n;      // 当前要移动的盘子数量
    char A, B, C; // 三个柱子：A -> C，借助 B
    int state;  // 递归状态：0=未处理，1=左递归完成，等待中间移动，2=右递归
}Frame;

int main() {
    int n;
    cin >> n;

    stack<Frame> st;
    st.push({n, 'A', 'B', 'C', 0});  // 初始问题：n个盘子从A到C

    long long cnt = 0; // 统计移动次数

    while (!st.empty()) {
        Frame &f = st.top();
        if (f.n == 1) {  // 递归最小子问题：直接移动
            cout << f.A << "-->" << f.C << endl;
            cnt++;
            st.pop();
        } 
        else if (f.state == 0) {  
            // 先处理左递归：把 n-1 个盘子从 A 移到 B
            f.state = 1;
            st.push({f.n - 1, f.A, f.C, f.B, 0});
        } 
        else if (f.state == 1) {  
            // 中间步骤：把第 n 个盘子从 A 移到 C
            cout << f.A << "-->" << f.C << endl;
            cnt++;
            f.state = 2;
            // 再处理右递归：把 n-1 个盘子从 B 移到 C
            st.push({f.n - 1, f.B, f.A, f.C, 0});
        } 
        else {  
            st.pop();  // 左右递归都处理完，返回上一层
        }
    }

    cout << cnt << endl; // 输出总次数
    return 0;
}
