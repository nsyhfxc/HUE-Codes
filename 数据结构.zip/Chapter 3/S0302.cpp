#include <bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
#define MAXSIZE 100
typedef int Status;
typedef float SElemType;   // 改为 float 类型，方便存储小数

// 顺序栈定义
typedef struct {
    SElemType *base;
    SElemType *top;
    int stacksize;
} SqStack;

// 初始化顺序栈
Status InitStack(SqStack &S) {
    S.base = new SElemType[MAXSIZE];
    if (!S.base) exit(OVERFLOW);
    S.top = S.base;
    S.stacksize = MAXSIZE;
    return OK;
}

// 入栈
Status Push(SqStack &S, SElemType e) {
    if (S.top - S.base >= S.stacksize) return ERROR; // 栈满
    *S.top++ = e;
    return OK;
}

// 出栈
Status Pop(SqStack &S) {
    if (S.top == S.base) return ERROR; // 栈空
    --S.top;
    return OK;
}

// 获取栈顶元素
SElemType GetTop(SqStack &S) {
    if (S.top == S.base) return ERROR; // 栈空
    return *(S.top - 1);
}

// 判空
Status StackEmpty(SqStack S) {
    return S.top == S.base;
}

// 求栈长度
int StackLength(SqStack S) {
    return S.top - S.base;
}

// 遍历栈（从栈底到栈顶）
void StackTraverse(SqStack S) {
    SElemType *p = S.base;
    while (p < S.top) {
        cout << *p << endl;
        p++;
    }
}

// 清空栈
Status ClearStack(SqStack &S) {
    S.top = S.base;
    return OK;
}

// 销毁栈
Status DestroyStack(SqStack &S) {
    if (S.base) {
        delete[] S.base;
        S.base = S.top = nullptr;
        S.stacksize = 0;
    }
    return OK;
}

int main()
{
    SqStack sint;
    InitStack(sint);
    
    int n;
    float s;
    cin >> n;
    for(int i = 0; i < n; i++)
    {
        cin >> s;
        Push(sint, s);
    }
    if(!StackEmpty(sint))
    {
        cout << "There are " << StackLength(sint) << " numbers in the stack:" << endl;
        StackTraverse(sint); // 从栈底到栈顶遍历
    }
    cout << "ClearStack()" << endl;
    ClearStack(sint);
    cout << StackLength(sint) << endl;
    DestroyStack(sint);
    return 0;
}
