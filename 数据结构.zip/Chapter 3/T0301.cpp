#include <bits/stdc++.h>
using namespace std;

typedef int SElemType;

typedef struct {
    SElemType *V; // 数组空间
    int m;        // 数组大小
    int top[2];   // 两个栈的栈顶指针，top[0]为左栈，top[1]为右栈
} DblStack;

// 初始化双栈
void InitDblStack(DblStack &S, int size) {
    S.m = size;
    S.V = new SElemType[size];
    S.top[0] = -1;     // 左栈空
    S.top[1] = size;   // 右栈空
}

// 判断双栈是否满
bool IsFull(DblStack &S) {
    return S.top[0] + 1 == S.top[1];
}

// 判断栈是否空
bool IsEmpty(DblStack &S, int stackNo) {
    if(stackNo == 0) return S.top[0] == -1;
    else return S.top[1] == S.m;
}

// 进栈
bool DblPush(DblStack &S, int stackNo, SElemType e) {
    if(IsFull(S)) return false; // 栈满
    if(stackNo == 0) {
        S.top[0]++;
        S.V[S.top[0]] = e;
    } else {
        S.top[1]--;
        S.V[S.top[1]] = e;
    }
    return true;
}

// 出栈
bool DblPop(DblStack &S, int stackNo, SElemType &e) {
    if(IsEmpty(S, stackNo)) return false;
    if(stackNo == 0) {
        e = S.V[S.top[0]];
        S.top[0]--;
    } else {
        e = S.V[S.top[1]];
        S.top[1]++;
    }
    return true;
}

// 测试main函数，按题目要求
int main() {
    DblStack dbs;
    InitDblStack(dbs, 7); // 初始化数组大小为7
    SElemType s;
    int i;
    
    // 左栈输入4个元素
    for(i=0;i<4;i++) {
        cin >> s;
        if(DblPush(dbs,0,s)) cout << "Insert success!" << endl;
        else cout << "Insert error!" << endl;
    }
    
    // 右栈输入4个元素
    for(i=0;i<4;i++) {
        cin >> s;
        if(DblPush(dbs,1,s)) cout << "Insert success!" << endl;
        else cout << "Insert error!" << endl;
    }
    
    if(IsFull(dbs)) cout << "Full!" << endl;
    
    cout << "Pop stack1:" << endl;
    while(!IsEmpty(dbs,0)) {
        DblPop(dbs,0,s);
        cout << s << endl;
    }
    
    cout << "Pop stack2:" << endl;
    while(!IsEmpty(dbs,1)) {
        DblPop(dbs,1,s);
        cout << s << endl;
    }
    
    return 0;
}
