#include <bits/stdc++.h>
using namespace std;

// 运算函数
int applyOp(int a, int b, char op) {
    switch(op) {
        case '+': return a+b;
        case '-': return a-b;
        case '*': return a*b;
        case '/': return a/b; // 假设不会出现除0
    }
    return 0;
}

// 判断运算符优先级
int precedence(char op) {
    if(op=='+' || op=='-') return 1;
    if(op=='*' || op=='/') return 2;
    return 0;
}

// 表达式求值函数
int EvalueateExpression(string expr) {
    stack<int> values;     // 数字栈
    stack<char> ops;       // 运算符栈

    for(int i=0; i<expr.size(); i++) {
        char c = expr[i];

        if(c==' ' || c=='#') continue; // 跳过空格和#

        if(isdigit(c)) {
            values.push(c-'0'); // 将字符转为整数
        }
        else if(c=='(') {
            ops.push(c);
        }
        else if(c==')') {
            while(!ops.empty() && ops.top()!='(') {
                int b = values.top(); values.pop();
                int a = values.top(); values.pop();
                char op = ops.top(); ops.pop();
                values.push(applyOp(a,b,op));
            }
            if(!ops.empty()) ops.pop(); // 弹出 '('
        }
        else { // 遇到运算符
            while(!ops.empty() && precedence(ops.top()) >= precedence(c)) {
                int b = values.top(); values.pop();
                int a = values.top(); values.pop();
                char op = ops.top(); ops.pop();
                values.push(applyOp(a,b,op));
            }
            ops.push(c);
        }
    }

    // 处理剩余运算符
    while(!ops.empty()) {
        int b = values.top(); values.pop();
        int a = values.top(); values.pop();
        char op = ops.top(); ops.pop();
        values.push(applyOp(a,b,op));
    }

    return values.top() + '0';
}

int main()
{
    string str;
    getline(cin,str);
    cout<<EvalueateExpression(str)-'0'<<endl; //计算表达式的值 
    return 0;
}