#include <bits/stdc++.h>
#include <cstdlib> // atof
using namespace std;

#define OK 1
#define ERROR 0
typedef int Status;
typedef double SElemType; // 用 double 存浮点

// 链栈结点定义
typedef struct StackNode {
    SElemType data;
    struct StackNode *next;
} StackNode, *LinkStack;

// 初始化栈
Status InitStack(LinkStack &S) {
    S = nullptr;
    return OK;
}

// 入栈
Status Push(LinkStack &S, SElemType e) {
    StackNode *p = new StackNode;
    if (!p) return ERROR;
    p->data = e;
    p->next = S;
    S = p;
    return OK;
}

// 判空
bool StackEmpty(LinkStack S) { return S == nullptr; }

// 取栈顶
SElemType GetTop(LinkStack S) { return S ? S->data : 0.0; }

// 出栈（带出参）
Status Pop(LinkStack &S, SElemType &e) {
    if (!S) return ERROR;
    StackNode *p = S;
    e = p->data;
    S = S->next;
    delete p;
    return OK;
}

// 后缀表达式求值
double Postfix(string str) {
    // 预处理：把每个 $ 两侧加空格，避免 "+$" 这种被当成一个 token
    string pre;
    pre.reserve(str.size() * 2);
    for (char c : str) {
        if (c == '$') { pre += ' '; pre += '$'; pre += ' '; }
        else pre += c;
    }

    LinkStack S;
    InitStack(S);

    stringstream ss(pre);
    string token;
    while (ss >> token) {
        if (token == "$") break;

        if (token == "+" || token == "-" || token == "*" || token == "/") {
            double b, a;
            Pop(S, b); // 右操作数
            Pop(S, a); // 左操作数
            double res = 0.0;
            if (token == "+") res = a + b;
            else if (token == "-") res = a - b;
            else if (token == "*") res = a * b;
            else if (token == "/") res = a / b;
            Push(S, res);
        } else {
            // 数字
            Push(S, atof(token.c_str()));
        }
    }
    return GetTop(S);
}

int main() {
    string str;
    getline(cin, str);
    cout << Postfix(str) << endl;
    return 0;
}
