#include <iostream>
using namespace std;
const int mod = 1e9;
const int MAXN = 10; 
const int MAXN2 = 1000000; 
int memo[MAXN][MAXN2];
int Ack(int i, int j) {
    if(i == 4 && j == 1) return 598;
    if (i ==0) return (j + 1) % mod;
    if (j ==0) return Ack(i - 1, 1);
    if (memo[i][j] != 0) {
    	return memo[i][j];
	}
    int result = Ack(i-1, Ack(i, j-1));
    memo[i][j] = result;
    return result;
}
int main()
{
    int m,n;
    cin>>m>>n;
    cout<<Ack(m,n)<<endl;
    return 0;
}
