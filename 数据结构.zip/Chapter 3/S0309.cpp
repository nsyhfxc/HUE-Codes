#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2
typedef int Status;
typedef char QElemType;

typedef struct QNode {
    QElemType data;
    struct QNode *next;
} QNode, *QueuePtr;


typedef struct {
    QueuePtr front;  // 队头
    QueuePtr rear;   // 队尾
} LinkQueue;

// 初始化队列
Status InitQueue(LinkQueue &Q) {
    Q.front = Q.rear = new QNode;
    if (!Q.front) exit(OVERFLOW);
    Q.front->next = nullptr;
    return OK;
}

// 入队（队尾入队）
Status EnQueue(LinkQueue &Q, QElemType e) {
    QueuePtr p = new QNode;
    if (!p) exit(OVERFLOW);
    p->data = e;
    p->next = nullptr;
    Q.rear->next = p;
    Q.rear = p;
    return OK;
}

// 出队（队尾出队，模拟栈pop）
Status DeQueue(LinkQueue &Q, QElemType &e) {
    if (Q.front == Q.rear) return ERROR; // 队空
    QueuePtr p = Q.front;
    // 找到最后一个结点和它的前驱
    while (p->next != Q.rear) p = p->next;
    e = Q.rear->data;
    delete Q.rear;
    Q.rear = p;
    Q.rear->next = nullptr;
    return OK;
}

// 取队尾元素（栈顶）
QElemType GetTop(LinkQueue Q) {
    if (Q.front != Q.rear) return Q.rear->data;
    return 0; // 空栈返回0
}

// 检查匹配
bool Matching(string str) {
    LinkQueue Q;
    InitQueue(Q);
    for(char ch : str) {
        if(ch=='(' || ch=='[' || ch=='{') {
            EnQueue(Q,ch);
        } else if(ch==')' || ch==']' || ch=='}') {
            if(Q.front == Q.rear) return false; // 栈空，右括号多
            char top = GetTop(Q);
            if((ch==')' && top=='(') || 
               (ch==']' && top=='[') || 
               (ch=='}' && top=='{')) {
                char tmp;
                DeQueue(Q,tmp); // 出栈
            } else {
                return false; // 不匹配
            }
        }
    }
    return Q.front == Q.rear; // 栈空则匹配
}

int main()
{
    string str;
    getline(cin,str);
    if(Matching(str)) cout<<"True"<<endl;
    else cout<<"False"<<endl;
    return 0;
}
