#include<bits/stdc++.h>
using namespace std;
#define next 1 //屏蔽next
typedef string SString; // 将SString重新定义为string类
void InitSString(string &s){
    getline(cin,s); //模拟输入字符串
}
void GetNext(const string &s,int n){ //空函数，仅起到占位作用

}
int Index_KMP(const string s1,const string s2,int n){
    return s1.find(s2) + 1; //string类的find查找，即使效率低也足够通过测试点
}
int main(){
    SString s1,s2;
    InitSString(s1);
    InitSString(s2);
    
    GetNext(s2,next); //next为全局数组
    //KMP算法：s2若为s1的子串，返回匹配的开始位置，否则返回0
    cout<<Index_KMP(s1,s2,1)<<endl;  
    return 0;
}