#include <iostream>
using namespace std;
#define MAXLEN 255
typedef struct {
    char ch[MAXLEN + 1];
    int length;
} SString;
void InitSString(SString &s) {
    char c;
    s.length = 0;
    while ((c = cin.get()) != '\n' && c != EOF) {
        if (s.length < MAXLEN) {
            s.ch[++s.length] = c;
        }
    }
}

int Index_BF(SString S, SString T, int pos) {
    int i = pos, j = 1;
    while (i <= S.length && j <= T.length) {
        if (S.ch[i] == T.ch[j]) {
            i++;
            j++;
        } else {
            i = i - j + 2;
            j = 1;
        }
    }
    if (j > T.length) return i - T.length;
    else return 0;
}

int main() {
    SString s1, s2;
    InitSString(s1);
    InitSString(s2);
    cout << Index_BF(s1, s2, 1) << endl;
    return 0;
}
