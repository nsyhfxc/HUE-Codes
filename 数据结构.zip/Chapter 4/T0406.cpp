#include<bits/stdc++.h>
using namespace std;

void input(int a[], int n) {
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
}

void output(int a[], int n) {
    for (int i = 0; i < n; i++) {
        cout << setw(5) << a[i];
    }
    cout << endl;
}

void Partition(int a[], int n) {
    int left = 0, right = n - 1;//双指针
    while (left < right) {
        // 左找负
        while (left < right && a[left] > 0) left++;
        // 右找正
        while (left < right && a[right] < 0) right--;
        // 交换
        if (left < right) {
            swap(a[left], a[right]);
        }
    }
}

int main() {
    int n;
    cin >> n;
    int a[n];
    input(a, n);        // 输入数组元素
    Partition(a, n);    // 调整正数在左，负数在右
    output(a, n);       // 格式化输出
    return 0;
}
