#include<bits/stdc++.h>
using namespace std;
#define MAXLEN 255
typedef struct {
    char ch[MAXLEN + 1];
    int length;
} SString;

int nextval[MAXLEN + 1];
void InitSString(SString &s) {
    string str;
    cin >> str;
    s.length = str.length();
    for (int i = 1; i <= s.length; i++) {
        s.ch[i] = str[i - 1];
    }
}

void get_nextval(SString t, int nextval[]) {
    int i = 1, j = 0;
    nextval[1] = 0;
    while (i < t.length) {
        if (j == 0 || t.ch[i] == t.ch[j]) {
            i++;
            j++;
            if (t.ch[i] != t.ch[j]) {
                nextval[i] = j;
            } else {
                nextval[i] = nextval[j];
            }
        } else {
            j = nextval[j];
        }
    }
}
int Index_KMP(SString s, SString t, int pos) {
    int i = pos, j = 1;
    while (i <= s.length && j <= t.length) {
        if (j == 0 || s.ch[i] == t.ch[j]) {
            i++;
            j++;
        } else {
            j = nextval[j];
        }
    }
    if (j > t.length) {
        return i - t.length; // 匹配成功，返回起始位置
    } else {
        return 0; // 匹配失败
    }
}

int main() {
    SString s1, s2;
    InitSString(s1);
    InitSString(s2);

    get_nextval(s2, nextval); // nextval为全局数组
    cout << Index_KMP(s1, s2, 1) << endl;
    return 0;
}
