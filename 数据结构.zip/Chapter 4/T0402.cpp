#include <iostream>
using namespace std;

void ReversePrint() {
    char c;
    cin >> noskipws >> c;
    if (c == '#') {
        return;
    }
    ReversePrint();
    cout << c;
}

int main() {
    ReversePrint();
    return 0;
}
