#include <iostream>
using namespace std;

int len(char *s)
{
    int i = 0;
    while (s[i] != '\0')
        i++;
    return i;
}

void Insert(char *s, char *t, int pos)
{
    int ls = len(s);
    int lt = len(t);

    for (int i = ls - 1; i >= pos - 1; i--)
    {
        s[i + lt] = s[i];
    }

    for (int j = 0; j < lt; j++)
    {
        s[pos - 1 + j] = t[j];
    }
    
    s[ls + lt] = '\0';
}

int main()
{
    char s[255];
    char t[200];
    int pos;
    cin >> s;
    cin >> t;
    do
    {
        cin >> pos;
    } while (pos < 1 || pos > len(s));
    Insert(s, t, pos);
    cout << s << endl;
    return 0;
}
