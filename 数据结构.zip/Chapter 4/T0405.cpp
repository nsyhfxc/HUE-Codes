#include <iostream>
#include <unordered_set>
using namespace std;

// 输入函数
void input(int **a, int m, int n)
{
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cin>>a[i][j];
        }
    }
}

// 判断函数
bool IsEqual(int **a, int m, int n)
{
    unordered_set<int> s;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(s.count(a[i][j])) // 已经出现过，说明有重复
                return false;
            s.insert(a[i][j]);
        }
    }
    return true; // 没有重复
}

int main()
{
    int m,n,i,j;
    cin>>m>>n;
    
    int **a=new int *[m];
    for(i=0;i<m;i++)
    {
        a[i]=new int[n];
    }
    input(a,m,n);
    
    if(IsEqual((int **)a,m,n)) cout<<"Yes"<<endl; //没有重复元素 
    else cout<<"No"<<endl; //有重复元素 
    return 0;
}
