#include<bits/stdc++.h>
using namespace std;

void count(const string &str) {
    vector<int>num(36,0);
    for (char ch : str) {
        if (isdigit(ch)) {
            num[ch - '0']++;
        } else if (isalpha(ch) && (toupper(ch))) {
            num[10 + (ch - 'A')]++;
        }
    }

    // 输出数字
    for (int i = 0; i < 10; i++) {
        cout << "num[" << i << "]=" << num[i] << endl;
    }
    // 输出字母
    for (int i = 0; i < 26; i++) {
        cout << "num[" << char('A' + i) << "]=" << num[10 + i] << endl;
    }
}

int main()
{
    string str;
    getline(cin, str);
    count(str);
    return 0;
}
