#include<bits/stdc++.h>
using namespace std;
#define MAX_LEN 255 

typedef struct {
    char ch[MAX_LEN + 1]; 
} SString;

void InitSString(SString &S);
void CheckVirus(SString Virus[], SString Person[], int num);
void PrintSString(const SString &S);
int Index(const SString &text, const SString &pattern);
void RotateSString(SString &S);
void InitSString(SString &S) {
    string temp;
    cin >> temp;

    S.ch[0] = temp.length();

    for (int i = 0; i < temp.length(); ++i) {
        S.ch[i + 1] = temp[i];
    }
}
void PrintSString(const SString &S) {
    for (int i = 1; i <= S.ch[0]; ++i) {
        cout << S.ch[i];
    }
}

int Index(const SString &text, const SString &pattern) {
    int n = text.ch[0];
    int m = pattern.ch[0];

    // 如果模式串比主串长，则不可能匹配
    if (n < m) return 0;

    // 遍历主串中所有可能的起始点
    for (int i = 1; i <= n - m + 1; ++i) {
        bool match = true;
        // 比较从当前起始点开始的子串是否与模式串完全相同
        for (int j = 1; j <= m; ++j) {
            if (text.ch[i + j - 1] != pattern.ch[j]) {
                match = false;
                break;
            }
        }
        if (match) {
            return i; // 找到匹配，返回起始位置
        }
    }
    return 0; // 未找到匹配
}

void RotateSString(SString &S) {
    int len = S.ch[0];
    if (len <= 1) {
        return; // 长度为0或1的字符串无需旋转
    }
    char first_char = S.ch[1];
    // 将所有字符向前移动一位
    for (int i = 1; i < len; ++i) {
        S.ch[i] = S.ch[i + 1];
    }
    S.ch[len] = first_char;
}

void CheckVirus(SString Virus[], SString Person[], int num) {
    for (int i = 0; i < num; ++i) {
        bool infected = false;
        int v_len = Virus[i].ch[0];

        SString rotated_virus = Virus[i];
        for (int j = 0; j < v_len; ++j) {
            if (Index(Person[i], rotated_virus) != 0) {
                infected = true;
                break;
            }
            RotateSString(rotated_virus);
        }
        PrintSString(Virus[i]);
        cout << ",";
        PrintSString(Person[i]);
        cout << "," << (infected ? "Yes" : "No") << endl;
    }
}
int main()
{
    
    int num=3;
    SString Virus[num],Person[num]; 
    for(int i=0; i<num; i++)
    {
        InitSString(Virus[i]); //初始化病毒DNA,字符串的存储下标从1开始 
        InitSString(Person[i]); //初始化人的DNA,字符串的存储下标从1开始 
    }
    CheckVirus(Virus,Person,num); //病毒感染检测 
    
    return 0;
}