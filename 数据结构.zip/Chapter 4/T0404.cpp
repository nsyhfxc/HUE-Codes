#include<bits/stdc++.h>
#include <cctype>
using namespace std;

void format(const char* s1, char* s2, char* s3, int n) {
    int s1_start = 0;
    while (isspace(s1[s1_start])) {
        s1_start++;
    }

    int s2_len = 0;
    for (int i = s1_start; i < s1_start + n && s1[i] != '\0'; ++i) {
        s2[s2_len++] = s1[i];
    }
    s2[s2_len] = '\0';

    if (s2_len > 0 && isspace(s2[s2_len - 1])) {
        int s3_start = s1_start + n;
        while (isspace(s1[s3_start])) {
            s3_start++;
        }
        if (s1[s3_start] != '\0') {
            s2[s2_len - 1] = s1[s3_start];
            s3_start++;
        }
        
        // 将剩余的字符放入 s3
        int s3_len = 0;
        for (int i = s3_start; s1[i] != '\0'; ++i) {
            s3[s3_len++] = s1[i];
        }
        s3[s3_len] = '\0';
    } else {
        // 将剩余的字符放入 s3
        int s3_len = 0;
        for (int i = s1_start + n; s1[i] != '\0'; ++i) {
            s3[s3_len++] = s1[i];
        }
        s3[s3_len] = '\0';
    }
}

int main()
{
    char s1[255],s2[255],s3[255];
    int n;
    cin.getline(s1,255,'\n');
    cin>>n;
    format(s1,s2,s3,n);
    cout<<s2<<endl;
    cout<<s3<<endl;
    return 0;
}