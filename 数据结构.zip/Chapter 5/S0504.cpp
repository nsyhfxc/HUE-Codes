#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

// 线索二叉树结点
typedef struct BiThrNode {
    TElemType data;
    struct BiThrNode *lchild, *rchild;
    int ltag, rtag;   // 0=孩子，1=线索
} BiThrNode, *BiThrTree;

BiThrTree pre = NULL; // 全局前驱指针

// 递归建立二叉树（先序输入）
void CreateBiThrTree(BiThrTree &T) {
    char ch;
    cin >> ch;
    if (ch == '#') {
        T = NULL;
    } else {
        T = new BiThrNode;
        T->data = ch;
        T->ltag = T->rtag = 0; // 默认是孩子
        CreateBiThrTree(T->lchild);
        CreateBiThrTree(T->rchild);
    }
}

// 中序线索化（递归）
void InThreading(BiThrTree T) {
    if (T) {
        InThreading(T->lchild);   // 线索化左子树

        if (!T->lchild) { // 没有左孩子
            T->ltag = 1;
            T->lchild = pre;
        }
        if (pre && !pre->rchild) { // 前驱没有右孩子
            pre->rtag = 1;
            pre->rchild = T;
        }
        pre = T; // 更新前驱

        InThreading(T->rchild);   // 线索化右子树
    }
}

// 带头结点的中序线索化
void InOrderThreading(BiThrTree &Thrt, BiThrTree T) {
    Thrt = new BiThrNode;
    Thrt->ltag = 0;
    Thrt->rtag = 1;
    Thrt->rchild = Thrt; // 右指针回指自己（循环链表）
    if (!T) {
        Thrt->lchild = Thrt; // 空树
    } else {
        Thrt->lchild = T; // 头结点左孩子指向根
        pre = Thrt;
        InThreading(T);
        // 最后处理：pre 是最后一个结点        pre->rchild = Thrt;
        pre->rtag = 1;
        Thrt->rchild = pre;
    }
}

// 遍历中序线索二叉树（带头结点）
void InOrderTraverse_Thr(BiThrTree Thrt) {
    BiThrTree p = Thrt->lchild; // 从根结点开始
    while (p != Thrt) {
        // 找最左结点
        while (p->ltag == 0) p = p->lchild;
        cout << p->data; // 输出

        // 沿着后继线索走
        while (p->rtag == 1 && p->rchild != Thrt) {
            p = p->rchild;
            cout << p->data;
        }
        p = p->rchild; // 转向右子树
    }
}

int main() {
    BiThrTree T, Thrt;
    CreateBiThrTree(T);          // 先序输入建树
    InOrderThreading(Thrt, T);   // 带头结点的中序线索化
    InOrderTraverse_Thr(Thrt);   // 遍历中序线索二叉树
    cout << endl;
    return 0;
}
