#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 递归统计叶子结点个数
int LeafNode(BiTree T) {
    if (T == NULL) return 0; // 空树
    if (T->lchild == NULL && T->rchild == NULL) return 1; // 叶子结点
    return LeafNode(T->lchild) + LeafNode(T->rchild); // 递归统计
}

int main()
{
    BiTree T;
    CreateBiTree(T); // 先序遍历顺序创建二叉树 
    cout << LeafNode(T) << endl; // 统计二叉树的叶结点个数
    return 0;
}
