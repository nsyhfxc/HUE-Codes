#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch;
    if (ch == '#') {
        T = NULL;
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild);
        CreateBiTree(T->rchild);
    }
}

int Level(BiTree T) {
    if (!T) return 0;
    queue<BiTree> q;
    q.push(T);
    int degree1Count = 0;

    while (!q.empty()) {
        BiTree node = q.front();
        q.pop();

        // 输出结点值（层次遍历顺序）
        cout << node->data;

        // 统计度为1的结点
        if ((node->lchild && !node->rchild) || (!node->lchild && node->rchild))
            degree1Count++;

        // 将非空孩子入队
        if (node->lchild) q.push(node->lchild);
        if (node->rchild) q.push(node->rchild);
    }

    cout << endl; // 输出层次遍历结束换行
    return degree1Count;
}

int main()
{
    BiTree T;
    CreateBiTree(T);
    cout<<Level(T)<<endl; //层次遍历二叉树，并统计度为1的结点个数 
    return 0;
}