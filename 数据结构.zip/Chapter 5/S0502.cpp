#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 先序遍历
void PreOrderTraverse(BiTree T) {
    if (T != NULL) {
        cout << T->data;
        PreOrderTraverse(T->lchild);
        PreOrderTraverse(T->rchild);
    }
}

// 中序遍历
void InOrderTraverse(BiTree T) {
    if (T != NULL) {
        InOrderTraverse(T->lchild);
        cout << T->data;
        InOrderTraverse(T->rchild);
    }
}

// 后序遍历
void PostOrderTraverse(BiTree T) {
    if (T != NULL) {
        PostOrderTraverse(T->lchild);
        PostOrderTraverse(T->rchild);
        cout << T->data;
    }
}

// 复制二叉树
void Copy(BiTree T, BiTree &S) {
    if (T == NULL) {
        S = NULL;
    } else {
        S = new BiTNode;
        S->data = T->data;
        Copy(T->lchild, S->lchild);
        Copy(T->rchild, S->rchild);
    }
}

// 计算二叉树深度
int Depth(BiTree T) {
    if (T == NULL) return 0;
    return max(Depth(T->lchild), Depth(T->rchild)) + 1;
}

// 计算二叉树结点个数
int NodeCount(BiTree T) {
    if (T == NULL) return 0;
    return NodeCount(T->lchild) + NodeCount(T->rchild) + 1;
}

int main()
{
    BiTree T, S;
    CreateBiTree(T);//先序遍历顺序建立二叉链表 
    Copy(T, S);
    PostOrderTraverse(S); cout << endl; // 后序遍历
    cout << Depth(S) << endl;           // 计算二叉树深度
    cout << NodeCount(S) << endl;       // 计算二叉树中结点个数
    return 0;
}
