#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 中序遍历
void InOrderTraverse(BiTree T) {
    if (T != NULL) {
        InOrderTraverse(T->lchild);
        cout << T->data;
        InOrderTraverse(T->rchild);
    }
}

// 递归交换左右孩子
void ChangeLR(BiTree T) {
    if (T == NULL) return;
    // 交换左右孩子
    BiTree temp = T->lchild;
    T->lchild = T->rchild;
    T->rchild = temp;
    // 递归交换子树
    ChangeLR(T->lchild);
    ChangeLR(T->rchild);
}

int main()
{
    BiTree T;
    CreateBiTree(T); // 先序遍历顺序建立二叉链表 
    InOrderTraverse(T); cout << endl; // 中序遍历 
    ChangeLR(T);  // 交换结点的左孩子与右孩子 
    InOrderTraverse(T); cout << endl; // 中序遍历 
    return 0;
}
