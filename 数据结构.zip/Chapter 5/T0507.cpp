#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch;
    if (ch == '#') {
        T = NULL;
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild);
        CreateBiTree(T->rchild);
    }
}

//递归求最长路径
void LongestPathHelper(BiTree T, string path, string &res) {
    if (!T) return;
    path.push_back(T->data);

    // 如果是叶子节点，更新最长路径
    if (!T->lchild && !T->rchild) {
        if (path.size() > res.size()) {
            res = path;
        }
    }

    LongestPathHelper(T->lchild, path, res);
    LongestPathHelper(T->rchild, path, res);
}

// 返回二叉树第一条最长路径的节点值（字符串形式）
string LongestPath(BiTree T) {
    string res;
    LongestPathHelper(T, "", res);
    return res;
}


int main()
{
    BiTree T;
    CreateBiTree(T); //先序遍历顺序创建二叉树 
    cout<<LongestPath(T)<<endl; //二叉树最长路径 
    return 0;
}