#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

// 线索二叉树结点
typedef struct BiThrNode {
    TElemType data;
    struct BiThrNode *lchild, *rchild;
    int ltag, rtag;   // 0=指向孩子，1=指向线索
} BiThrNode, *BiThrTree;

BiThrTree pre = NULL; // 全局指针，指向当前访问结点的前驱

// 递归建立二叉树（先序）
void CreateBiThrTree(BiThrTree &T) {
    char ch;
    cin >> ch;
    if (ch == '#') {
        T = NULL;
    } else {
        T = new BiThrNode;
        T->data = ch;
        T->ltag = T->rtag = 0; // 默认是孩子指针
        CreateBiThrTree(T->lchild);
        CreateBiThrTree(T->rchild);
    }
}

// 中序线索化
void InThreading(BiThrTree T) {
    if (T) {
        InThreading(T->lchild);   // 线索化左子树

        // 左孩子为空 → 建立前驱线索
        if (!T->lchild) {
            T->ltag = 1;
            T->lchild = pre;
        }
        // 前驱结点右孩子为空 → 建立后继线索
        if (pre && !pre->rchild) {
            pre->rtag = 1;
            pre->rchild = T;
        }
        pre = T;  // 更新前驱结点

        InThreading(T->rchild);   // 线索化右子树
    }
}

// 遍历中序线索二叉树
void InOrderTraverse_Thr(BiThrTree T) {
    BiThrTree p = T;
    while (p) {
        // 找到最左下的结点
        while (p->ltag == 0 && p->lchild) {
            p = p->lchild;
        }
        cout << p->data; // 访问结点

        // 沿着后继线索走
        while (p->rtag == 1 && p->rchild) {
            p = p->rchild;
            cout << p->data;
        }
        // 转向右子树
        p = p->rchild;
    }
}

int main() {
    BiThrTree T;
    CreateBiThrTree(T);   // 先序输入构建二叉树
    InThreading(T);       // 不带头结点的中序线索化
    InOrderTraverse_Thr(T); // 遍历中序线索二叉树
    cout << endl;
    return 0;
}
