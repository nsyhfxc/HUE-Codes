#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 比较两棵二叉树是否相等
bool CmpTree(BiTree T1, BiTree T2) {
    if (T1 == NULL && T2 == NULL) return true; // 都为空
    if (T1 == NULL || T2 == NULL) return false; // 一空一非空
    if (T1->data != T2->data) return false; // 数据不相等
    return CmpTree(T1->lchild, T2->lchild) && CmpTree(T1->rchild, T2->rchild);
}

int main()
{
    BiTree T1, T2;
    CreateBiTree(T1); // 先序遍历顺序创建二叉树 
    CreateBiTree(T2);
    if (CmpTree(T1, T2)) cout << "True" << endl;
    else cout << "False" << endl;
    return 0;
}
