#include<bits/stdc++.h>
using namespace std;

typedef struct {
    int weight;   // 权值
    int parent;   // 双亲下标
    int lchild;   // 左孩子下标
    int rchild;   // 右孩子下标
} HTNode, *HuffmanTree;

// 在 HT[1..m] 中选择 parent=0 的两个最小的结点 s1 和 s2
void Select(HuffmanTree HT, int m, int &s1, int &s2) {
    int min1 = INT_MAX, min2 = INT_MAX;
    s1 = s2 = 0;
    for(int i=1; i<=m; i++) {
        if(HT[i].parent == 0) {
            if(HT[i].weight < min1) {
                min2 = min1; s2 = s1;
                min1 = HT[i].weight; s1 = i;
            } else if(HT[i].weight < min2) {
                min2 = HT[i].weight; s2 = i;
            }
        }
    }
}

// 构造哈夫曼树
void CreateHuffmanTree(HuffmanTree &HT, int n) {
    if(n <= 1) return;
    int m = 2*n - 1;
    HT = new HTNode[m+1]; // 0号单元未用

    // 初始化前 n 个结点
    for(int i=1; i<=n; i++) {
        cin >> HT[i].weight;
        HT[i].parent = HT[i].lchild = HT[i].rchild = 0;
    }
    // 初始化其余结点
    for(int i=n+1; i<=m; i++) {
        HT[i].weight = 0;
        HT[i].parent = HT[i].lchild = HT[i].rchild = 0;
    }

    // 构造哈夫曼树
    for(int i=n+1; i<=m; i++) {
        int s1, s2;
        Select(HT, i-1, s1, s2); // 在前 i-1 个结点中选择两个最小的
        HT[s1].parent = i;
        HT[s2].parent = i;
        HT[i].lchild = s1;
        HT[i].rchild = s2;
        HT[i].weight = HT[s1].weight + HT[s2].weight;

        cout << "HT[" << s1 << "]=" << HT[s1].weight << ","
             << "HT[" << s2 << "]=" << HT[s2].weight << endl;
    }
}

int main()
{
    HuffmanTree T;
    int n;
    cin >> n;
    CreateHuffmanTree(T, n); // 创建哈夫曼树 
    cout << T[2*n-1].weight << endl; // 哈夫曼树根结点权值 
    return 0;
}
