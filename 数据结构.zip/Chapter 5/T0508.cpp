#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 从叶子结点到根结点的路径输出
void AllPath(BiTree T) {
    if (!T) return;
    vector<TElemType> path;

    function<void(BiTree)> dfs = [&](BiTree node) {
        if (!node) return;
        path.push_back(node->data);
        if (!node->lchild && !node->rchild) {
            // 叶子结点，输出路径（从叶到根）
            for (int i = path.size() - 1; i >= 0; i--)
                cout << path[i];
            cout << endl;
        }
        dfs(node->lchild);
        dfs(node->rchild);
        path.pop_back();
    };

    dfs(T);
}


int main()
{
    BiTree T;
    CreateBiTree(T); //先序遍历顺序创建二叉树 
    AllPath(T); //输出二叉树中从每个叶子结点到根结点的路径 
    return 0;
}