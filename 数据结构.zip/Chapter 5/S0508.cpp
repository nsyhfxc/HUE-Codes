#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

// 二叉树结点定义
typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;



// 判断是否是运算符
bool IsOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// 运算符优先级
int Precede(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}


// 根据表达式字符串构建表达式树
void InitExpTree(BiTree &T) {
    stack<BiTree> exptr;   // 操作数栈（存放子树根）
    stack<char> optr;      // 运算符栈

    char c;
    while (cin >> c) {
        if (c == '#') break;  // 输入结束

        if (isdigit(c)) { // 数字直接建成叶子节点
            BiTree p = new BiTNode;
            p->data = c;
            p->lchild = p->rchild = NULL;
            exptr.push(p);
        } 
        else if (c == '(') {
            optr.push(c);
        } 
        else if (c == ')') {
            while (!optr.empty() && optr.top() != '(') {
                char op = optr.top(); optr.pop();

                BiTree p = new BiTNode;
                p->data = op;
                p->rchild = exptr.top(); exptr.pop();
                p->lchild = exptr.top(); exptr.pop();
                exptr.push(p);
            }
            optr.pop(); // 弹出 '('
        } 
        else if (IsOperator(c)) {
            while (!optr.empty() && Precede(optr.top()) >= Precede(c)) {
                char op = optr.top(); optr.pop();

                BiTree p = new BiTNode;
                p->data = op;
                p->rchild = exptr.top(); exptr.pop();
                p->lchild = exptr.top(); exptr.pop();
                exptr.push(p);
            }
            optr.push(c);
        }
    }

    // 处理剩余运算符
    while (!optr.empty()) {
        char op = optr.top(); optr.pop();

        BiTree p = new BiTNode;
        p->data = op;
        p->rchild = exptr.top(); exptr.pop();
        p->lchild = exptr.top(); exptr.pop();
        exptr.push(p);
    }

    T = exptr.top(); exptr.pop();
}


// 递归计算表达式树的值
int EvaluateExpTree(BiTree T) {
    if (!T) return 0;

    if (!IsOperator(T->data)) {
        return T->data - '0'; // 叶子结点是数字
    }

    int leftVal = EvaluateExpTree(T->lchild);
    int rightVal = EvaluateExpTree(T->rchild);

    switch (T->data) {
        case '+': return leftVal + rightVal;
        case '-': return leftVal - rightVal;
        case '*': return leftVal * rightVal;
        case '/': return leftVal / rightVal;
    }
    return 0;
}

void PreOrderTraverse(BiTree T) {
    if (T) {
        cout << T->data;
        PreOrderTraverse(T->lchild);
        PreOrderTraverse(T->rchild);
    }
}

int main()
{
    BiTree T;
    InitExpTree(T); //先序遍历顺序创建二叉树 
    //PreOrderTraverse(T); cout<<endl; //先序遍历 
    cout<<EvaluateExpTree(T)<<endl; //计算表达式的值 
    return 0;
}