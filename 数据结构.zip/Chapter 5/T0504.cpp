#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

// 二叉树结点定义
typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 按先序序列创建二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch;
    if (ch == '#') {
        T = NULL;
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild);
        CreateBiTree(T->rchild);
    }
}

// 双序遍历函数
void DoubleTraverse(BiTree T) {
    if (T) {
        cout << T->data;        // 第一次访问
        DoubleTraverse(T->lchild);
        cout << T->data;        // 第二次访问
        DoubleTraverse(T->rchild);
    }
}

int main()
{
    BiTree T;
    CreateBiTree(T); // 先序遍历顺序创建二叉树 
    DoubleTraverse(T); // 双序遍历 
    return 0;
}
