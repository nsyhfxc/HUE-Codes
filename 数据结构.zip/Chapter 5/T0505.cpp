#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 先序遍历
void PreOrderTraverse(BiTree T) {
    if (T != NULL) {
        cout << T->data;
        PreOrderTraverse(T->lchild);
        PreOrderTraverse(T->rchild);
    }
}

// 中序遍历
void InOrderTraverse(BiTree T) {
    if (T != NULL) {
        InOrderTraverse(T->lchild);
        cout << T->data;
        InOrderTraverse(T->rchild);
    }
}

// 后序遍历
void PostOrderTraverse(BiTree T) {
    if (T != NULL) {
        PostOrderTraverse(T->lchild);
        PostOrderTraverse(T->rchild);
        cout << T->data;
    }
}

// 计算二叉树最大宽度
int Width(BiTree T) {
    if (!T) return 0;
    queue<BiTree> q;
    q.push(T);
    int maxWidth = 0;
    while (!q.empty()) {
        int size = q.size(); // 当前层节点个数
        maxWidth = max(maxWidth, size);
        for (int i = 0; i < size; i++) {
            BiTree node = q.front(); q.pop();
            if (node->lchild) q.push(node->lchild);
            if (node->rchild) q.push(node->rchild);
        }
    }
    return maxWidth;
}

int main()
{
    BiTree T;
    CreateBiTree(T); //先序遍历顺序创建二叉树 
    cout<<Width(T)<<endl; //二叉树最大宽度 
    return 0;
}