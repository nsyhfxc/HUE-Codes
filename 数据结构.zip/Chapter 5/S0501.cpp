#include <bits/stdc++.h>
using namespace std;

typedef char TElemType;

typedef struct BiTNode {
    TElemType data;
    struct BiTNode *lchild, *rchild;
} BiTNode, *BiTree;

// 递归建立二叉树
void CreateBiTree(BiTree &T) {
    char ch;
    cin >> ch; // 输入一个字符
    if (ch == '#') {
        T = NULL; // 空结点
    } else {
        T = new BiTNode;
        T->data = ch;
        CreateBiTree(T->lchild); // 建立左子树
        CreateBiTree(T->rchild); // 建立右子树
    }
}

// 先序遍历
void PreOrderTraverse(BiTree T) {
    if (T != NULL) {
        cout << T->data;
        PreOrderTraverse(T->lchild);
        PreOrderTraverse(T->rchild);
    }
}

// 中序遍历
void InOrderTraverse(BiTree T) {
    if (T != NULL) {
        InOrderTraverse(T->lchild);
        cout << T->data;
        InOrderTraverse(T->rchild);
    }
}

// 后序遍历
void PostOrderTraverse(BiTree T) {
    if (T != NULL) {
        PostOrderTraverse(T->lchild);
        PostOrderTraverse(T->rchild);
        cout << T->data;
    }
}

int main() {
    BiTree T;
    CreateBiTree(T); // 先序遍历顺序建立二叉链表
    PreOrderTraverse(T); cout << endl; // 先序遍历
    InOrderTraverse(T); cout << endl; // 中序遍历
    PostOrderTraverse(T); cout << endl; // 后序遍历
    
    return 0;
}
