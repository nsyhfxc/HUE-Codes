#include <bits/stdc++.h>
using namespace std;

#define OK 1
#define ERROR 0
#define OVERFLOW -2
typedef int ElemType;
typedef int Status;

// 顺序线性表定义
#define MAXSIZE 100

typedef struct {
    ElemType *elem;
    int length; // 当前长度
} Sqlist;

// 初始化顺序表
Status InitList(Sqlist &L){
    L.elem = new ElemType[MAXSIZE];
    if(!L.elem){
        exit(OVERFLOW);
    }
    L.length = 0;
    return OK;
}

// 在顺序表第i个位置插入元素 (1-based)
Status ListInsert(Sqlist &L, int i, ElemType e){
    if(i < 1 || i > L.length + 1) return ERROR; // 插入位置非法
    if(L.length >= MAXSIZE) return ERROR; // 表满
    for(int j = L.length; j >= i; j--){
        L.elem[j] = L.elem[j-1]; // 后移
    }
    L.elem[i-1] = e;
    L.length++;
    return OK;
}

// 获取顺序表第i个元素 (1-based)
Status GetElem(Sqlist L, int i, ElemType &e){
    if(i < 1 || i > L.length) return ERROR;
    e = L.elem[i-1];
    return OK;
}

// 按值查找
int LocateElem(Sqlist L, ElemType e){
    for(int i = 0; i < L.length; i++){
        if(L.elem[i] == e) return i + 1; // 位置是1-based
    }
    return 0; // 未找到
}


int main()
{
    //线性表的的初始化、插入、取值
    Sqlist Lscore; //用来存储学生《数据结构》成绩
    InitList(Lscore); //初始化线性表 
    int i;
    ElemType s;
    for(i=1; i<=3; i++) //输入3个学生成绩，添加到线性表中 
    {
        cin>>s;
        ListInsert(Lscore,i,s); //线性表中添加数据 
    } 
    
    ElemType ls;
    cin>>ls; //输入要查找的成绩 
    //在线性表中查找，返回元素序号，若找不到返回0 
    int loc=LocateElem(Lscore,ls);
    if(loc==0) cout<<"Not found!"<<endl;
    else cout<<"Loc:"<<loc<<endl;
    
    return 0;
}