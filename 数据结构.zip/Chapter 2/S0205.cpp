#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;
typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;

Status InitList(LinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = NULL;
    return OK;
}

void CreateList_R(LinkList &L, int n) {
    LinkList r = L; // r 指向链表的最后一个节点（初始为头结点）
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e; // 读入数据
        LinkList p = new LNode;
        p->data = e;
        p->next = NULL;
        r->next = p; // 尾插
        r = p;       // r 移动到新尾
    }
}


void showList(LinkList L) {
    if (L->next == NULL) {
        cout << "empty!" << endl;
        return;
    }
    LinkList p = L->next;
    int i = 1;
    while (p) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}

int main()
{
    LinkList Lname;
    InitList(Lname); //初始化单链表 
    showList(Lname); //单链表遍历 
    CreateList_R(Lname,5); //后插法创建单链表 
    showList(Lname); //单链表遍历 
    return 0;
} 