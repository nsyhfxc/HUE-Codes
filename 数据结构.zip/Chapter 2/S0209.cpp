#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;
typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;

Status InitList(LinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = NULL;
    return OK;
}

void CreateList_R(LinkList &L, int n) {
    LinkList r = L; // r 指向链表的最后一个节点（初始为头结点）
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e; // 读入数据
        LinkList p = new LNode;
        p->data = e;
        p->next = NULL;
        r->next = p; // 尾插
        r = p;       // r 移动到新尾
    }
}

Status ListInsert(LinkList &L, int i, ElemType e) {
    LinkList p = L; // p 指向头结点
    int j = 0;
    // 找到第 i-1 个结点
    while (p != NULL && j < i - 1) {
        p = p->next;
        j++;
    }
    if (p == NULL) return ERROR; // i 不合法
    
    LinkList s = new LNode; // 创建新结点
    s->data = e;
    s->next = p->next; // 插入
    p->next = s;
    return OK;
}

Status ListDelete(LinkList &L, int i) {
    LinkList p = L; // p 指向头结点
    int j = 0;
    // 找到第 i-1 个结点
    while (p->next != NULL && j < i - 1) {
        p = p->next;
        j++;
    }
    // 如果 i 超界或无效
    if (p->next == NULL || j > i - 1) return ERROR;

    LinkList q = p->next;     // 要删除的结点
    p->next = q->next;        // 跨过 q
    delete q;                 // 释放空间
    return OK;
}


void showList(LinkList L) {
    if (L->next == NULL) {
        cout << "empty!" << endl;
        return;
    }
    LinkList p = L->next;
    int i = 1;
    while (p) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}


int main()
{
    LinkList Lname;
    InitList(Lname); //初始化单链表 
    CreateList_R(Lname,3); //后插法创建单链表 
    showList(Lname); //单链表遍历 
    int i;
    cin>>i;
    if(ListDelete(Lname,i)==OK) cout<<"Delete success!"<<endl;
    else cout<<"Error!"<<endl;
    showList(Lname); //单链表遍历
    return 0;
} 