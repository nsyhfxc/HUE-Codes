#include <iostream>
using namespace std;
#define OK 1
#define ERROR 0
typedef int Status;
typedef int ElemType;

typedef struct DuLNode {
    ElemType data;
    DuLNode *prior, *next;
} DuLNode, *DuLinkList;

// 初始化带头结点的双向链表
void InitDuLNode(DuLinkList &L) {
    L = new DuLNode;
    L->prior = L->next = nullptr;
}

// 前插法创建双向链表（n个元素）
void CreateDuL_H(DuLinkList &L, int n) {
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e;
        DuLNode *p = new DuLNode;
        p->data = e;

        // 前插：插到头结点之后
        p->next = L->next;
        if (L->next != nullptr)
            L->next->prior = p;
        p->prior = L;
        L->next = p;
    }
}


// 遍历双向链表
void show(DuLinkList L) {
    DuLNode *p = L->next;
    int i = 1;
    while (p != nullptr) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}

Status ListDelete_DuL(DuLinkList &L, int i) {
    if(i == 0){return ERROR;}
    
    DuLNode *p = L->next;
    int j = 1;

    // 寻找要删除的第 i 个节点
    while (p != nullptr && j < i) {
        p = p->next;
        j++;
    }

    // 如果 i 不在链表范围内，则返回错误
    if (p == nullptr) {
        return ERROR;
    }

    // 删除节点 p
    p->prior->next = p->next;
    if (p->next != nullptr) {
        p->next->prior = p->prior;
    }
    
    // 释放节点内存
    delete p;

    return OK;
}

int main()
{
    DuLinkList L;
    InitDuLNode(L); //初始化双向链表 
    CreateDuL_H(L,4); //前插法创建双向链表 
    show(L); //遍历双向链表 
    int i;
    cout<<"Please input the location you want to delete:"<<endl;
    cin>>i;
    if(ListDelete_DuL(L,i)==OK)
        cout<<"Delete success!"<<endl;
    else 
        cout<<"Delete Error!"<<endl;
    show(L);
    return 0;
}