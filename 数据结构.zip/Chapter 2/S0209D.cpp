#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;

typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *CLinkList;

// 初始化循环单链表
Status InitCList(CLinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = L; // 头结点指向自己，形成循环
    return OK;
}

void CreateCList_R(CLinkList &L, int n) {
    CLinkList r = L; // r指向当前链表的最后一个结点，初始为头结点
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e;
        CLinkList p = new LNode;
        p->data = e;
        // 插入到尾部
        p->next = L;   // 新结点的next指向头结点，保持循环
        r->next = p;   // 原尾结点的next指向新结点
        r = p;         // r更新为新的尾结点
    }
}

// 按值删除循环单链表结点
Status DeleteCListByData(CLinkList &L, ElemType e) {
    if (L->next == L) return ERROR; // 空表

    CLinkList prev = L;      // 前驱指针
    CLinkList p = L->next;   // 当前指针

    while (p != L) { // 遍历到回到头结点为止
        if (p->data == e) {
            prev->next = p->next; // 前驱跳过当前
            delete p;             // 释放结点
            return OK;
        }
        prev = p;
        p = p->next;
    }
    return ERROR; // 未找到
}


// 遍历循环单链表
void showCList(CLinkList L) {
    if (L->next == L) {
        cout << "empty!" << endl;
        return;
    }
    CLinkList p = L->next;
    int i = 1;
    while (p != L) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}
int main()
{
    CLinkList Lname;
    InitCList(Lname); //初始化循环单链表 
    CreateCList_R(Lname,5); //后插法创建循环单链表 
    showCList(Lname); //循环单链表遍历 
    ElemType s;
    cin>>s;
    if(DeleteCListByData(Lname,s)==OK)
    {
        cout<<"Delete success!"<<endl;
        showCList(Lname);
    }
    else
    {        cout<<"Error!"<<endl;    }
    return 0;
} 