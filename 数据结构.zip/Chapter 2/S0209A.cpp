#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;

typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *CLinkList;

// 初始化循环单链表
Status InitCList(CLinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = L; // 头结点指向自己，形成循环
    return OK;
}

// 前插法创建循环单链表
void CreateCList_H(CLinkList &L, int n) {
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e;
        CLinkList p = new LNode;
        p->data = e;
        // 插入到头结点后
        p->next = L->next;
        L->next = p;
    }
}

// 遍历循环单链表
void showCList(CLinkList L) {
    if (L->next == L) {
        cout << "empty!" << endl;
        return;
    }
    CLinkList p = L->next;
    int i = 1;
    while (p != L) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}

int main() {
    CLinkList Lname;
    InitCList(Lname); // 初始化循环单链表
    showCList(Lname); // 输出空表
    CreateCList_H(Lname, 5); // 前插法创建
    showCList(Lname); // 遍历
    return 0;
}
