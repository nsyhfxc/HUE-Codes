#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
#define OVERFLOW -2

typedef int Status;
typedef string ElemType;
typedef struct LNode {
    ElemType data;
    struct LNode *next;
} LNode, *LinkList;

Status InitList(LinkList &L) {
    L = new LNode;
    if (!L) return OVERFLOW;
    L->next = NULL;
    return OK;
}

void CreateList_R(LinkList &L, int n) {
    LinkList r = L; // r 指向链表的最后一个节点（初始为头结点）
    for (int i = 0; i < n; i++) {
        ElemType e;
        cin >> e; // 读入数据
        LinkList p = new LNode;
        p->data = e;
        p->next = NULL;
        r->next = p; // 尾插
        r = p;       // r 移动到新尾
    }
}


void showList(LinkList L) {
    if (L->next == NULL) {
        cout << "empty!" << endl;
        return;
    }
    LinkList p = L->next;
    int i = 1;
    while (p) {
        cout << i++ << ":" << p->data << endl;
        p = p->next;
    }
}

Status GetElem(LinkList L, int i, ElemType &e) {
    LinkList p = L->next; // p指向第一个有效节点
    int j = 1;            // 计数器，从1开始
    while (p && j < i) {  // 找到第i个结点
        p = p->next;
        j++;
    }
    if (!p || j > i) return ERROR; // i不合法
    e = p->data;  // 取出数据
    return OK;
}

int main()
{
    LinkList Lname;
    InitList(Lname); //初始化单链表 
    CreateList_R(Lname,3); //后插法创建单链表 
    showList(Lname); //单链表遍历 
    ElemType s;
    int i;
    cin>>i;
    if(GetElem(Lname,i,s)==OK)     cout<<s<<endl;
    else cout<<"Error!"<<endl;
    return 0;
} 