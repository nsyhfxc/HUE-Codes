#include<bits/stdc++.h>
using namespace std;

template<class T>
struct Node {
    T data;
    Node<T>* next;
    Node(const T& d, Node<T>* n = nullptr) : data(d), next(n) {}
};

template<class T>
class SingleList {
private:
    Node<T>* head;
    int length;
public:
    SingleList() : head(nullptr), length(0) {}

    ~SingleList() {
        Node<T>* p;
        while (head) {
            p = head;
            head = head->next;
            delete p;
        }
    }

    bool IsEmpty() const {
        return head == nullptr;
    }

    int Length() const {
        return length;
    }

    void Insert(const T& e) {
        Node<T>* newNode = new Node<T>(e);
        if (!head || e < head->data) {
            newNode->next = head;
            head = newNode;
        } else {
            Node<T>* p = head;
            while (p->next && p->next->data < e) {
                p = p->next;
            }
            newNode->next = p->next;
            p->next = newNode;
        }
        length++;
    }

    // 删除指定元素
    bool deleteByLoc(int pos) {
        if (pos < 1 || pos > length || !head) return false; // 越界或空表

        if (pos == 1) { // 删除头节点
            Node<T>* p = head;
            head = head->next;
            delete p;
            length--;
            return true;
        }

        Node<T>* p = head;
        for (int i = 1; i < pos - 1; i++) {
            p = p->next; // 移动到待删除节点的前一个节点
        }

        Node<T>* q = p->next;
        p->next = q->next;
        delete q;
        length--;
        return true;
    }

    void Output(ostream& out) const {
        Node<T>* p = head;
        while (p) {
            out << p->data << endl;
            p = p->next;
        }
        cout << endl;
    }
};
int main(){
    SingleList<int> score;
    int s;
    for(int i=0; i<3; i++)
    {
        cin>>s;
        score.Insert(s);
    }
    if(!score.IsEmpty())
    {
        cout<<"There are "<<score.Length()<<" scores:"<<endl;
        score.Output(cout);
    }
    int j;
    cout<<"Please input the location you want to delete:"<<endl; 
    cin>>j;
    if(score.deleteByLoc(j)) cout<<"Delete success!"<<endl;
    else cout<<"Delete error!"<<endl;
    if(!score.IsEmpty())
    {
        cout<<"There are "<<score.Length()<<" scores:"<<endl;
        score.Output(cout);
    }
    return 0;
}