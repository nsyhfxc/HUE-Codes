#include<bits/stdc++.h>
using namespace std;
#define OK 1
#define ERROR 0
typedef int Status;
class Sqlist {
private:
    int data[100];
    int length;
public:
    Sqlist(){
        length = 0;
    }
    void insert(int e) {
        if (length < 100) {
            data[length] = e;
            length++;
        }
    }
    Status deleteLoc(int loc) {
        if (loc < 1 || loc > length) return ERROR;
        for (int i = loc - 1; i < length - 1; i++) {
            data[i] = data[i + 1];
        }
        length--;
        return OK;
    }
    void show() {
        for (int i = 0; i < length; i++) {
            cout << i + 1 << ":" << data[i] << endl;
        }
    }
};
int main()
{
    Sqlist Lscore;
    for (int i = 1; i <= 3; i++){
        int s;
        cin >> s;
        Lscore.insert(s);
    }
    Lscore.show();
    int loc;
    cin >> loc;
    if (Lscore.deleteLoc(loc) == OK) cout << "delete success!" << endl;
    else cout << "Error!" << endl;
    Lscore.show();
    return 0;
}
