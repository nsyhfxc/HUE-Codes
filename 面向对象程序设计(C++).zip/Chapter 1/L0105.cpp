#include<bits/stdc++.h>
using namespace std;
int main()
{
    string name;
    cout << "Please enter your name and age:" << endl;
	getline(cin,name);
    int num;
    cin >> num;
    cout << "name:" << name << "," << "age=   " << num;
    return 0;
}