#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout << "Light Rain in Early Spring" << endl;
    cout << "The royal streets are moistend by a creamlike rain;" << endl;
    cout << "Green grass can be perceived afar but not nearby." << endl;
    cout << "It's the best time of a year late spring tries in vain" << endl;
    cout << "With its capital veiled in willows to outvie.";
    return 0;
}