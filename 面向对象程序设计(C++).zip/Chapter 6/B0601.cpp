#include<bits/stdc++.h>
using namespace std;
template<typename T>
T add(T a,T b){
    return a+b;
}
int main()
{
    int a,b;
    double c,d;
    cin>>a>>b>>c>>d;
    cout<<add(a,b)<<endl;
    cout<<add(c,d)<<endl;
      return 0;
}