#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    cout << dec << n << " " << oct << n << " " << hex << n ;
    return 0;
}