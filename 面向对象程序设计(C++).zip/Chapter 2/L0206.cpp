#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a;
    cin >> a;
    a -= a;
    cout << "T2 is " << a;
}