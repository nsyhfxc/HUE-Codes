#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a;
	cin >> a;
	int& t = a;
	cout << "index(2)=" << t << endl;
	return 0;
}