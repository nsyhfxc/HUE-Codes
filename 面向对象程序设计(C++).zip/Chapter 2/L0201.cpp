#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout << "Please input two integers:" << endl;
    int a,b;
    cin >> a >> b;
    cout << a << "+" << b << "=" << a+b;
    return 0;
}