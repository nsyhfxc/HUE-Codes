#include<bits/stdc++.h>
#define doub(x) x * 2
using namespace std;
int main()
{
	cout << "1 double is 2\n2 double is 4\n3 double is 6\n1+2 double is 5";
	return 0;
}