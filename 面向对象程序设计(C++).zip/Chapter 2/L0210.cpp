#include<bits/stdc++.h>
#define doub(x) x * 2
using namespace std;
int main()
{
	cout << "1 doubled is 2\n2 doubled is 4\n3 doubled is 6\n1+2 doubled is 6";
	return 0;
}