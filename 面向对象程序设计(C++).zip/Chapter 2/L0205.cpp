#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int const T2 = n + n;
    //int const T2 = T1 - T1;
    cout <<  "T2 " << "is " << T2; 
    return 0;
}