#include<bits/stdc++.h>
using namespace std;
int main()
{
    string name;
    cout << "Hello, your name:" << endl;
    getline(cin,name);
    cout << "My name is " << name ;
    return 0;
}