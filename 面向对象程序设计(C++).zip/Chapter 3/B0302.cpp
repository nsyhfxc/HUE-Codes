#include <iostream>
#include <vector>

using namespace std;

class Student {
private:
    int num;
    int age;
    float score;
    static float total_score;
    static int student_count;

public:
    // Ĭ�Ϲ��캯��
    Student() : num(0), age(0), score(0.0f) {
        student_count++;
    }

    Student(int n, int a, float s) : num(n), age(a), score(s) {
        // ע�⣺���� student_count �Ѿ���Ĭ�Ϲ��캯���е����ˣ���Ҫ����
        student_count--; // ����Ĭ�Ϲ��캯���еĵ���
        student_count++; // ������ȷ����
    }

    void total() {
        total_score += score;
    }

    static float average() {
        if (student_count == 0) {
            return 0;
        }
        return total_score / student_count;
    }
};

float Student::total_score = 0;
int Student::student_count = 0;

int main() {
    int n;
    cout << "Please input the number of students : ";
    cin >> n;

    Student *p = new Student[n];

    for (int i = 0; i < n; i++) {
        int num, age;
        float score;
        cin >> num >> age >> score;
        p[i] = Student(num, age, score);
        p[i].total();
    }

    cout << "The average score of " << n << " student is " << Student::average() << endl;

    if (p != NULL) delete p;

    return 0;
}
