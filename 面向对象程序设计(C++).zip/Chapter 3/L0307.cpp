#include <iostream>
#include <string>
using namespace std;

int main() {
    cout << "x=10 rx=10 pi=3.14";

    return 0;
}